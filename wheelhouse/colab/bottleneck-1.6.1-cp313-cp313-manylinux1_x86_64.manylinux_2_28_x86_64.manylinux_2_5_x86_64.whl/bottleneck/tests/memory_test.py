import gc
import sys
import tracemalloc

import numpy as np
import pytest

import bottleneck as bn

_original_nansum = bn.nansum
_retained = []


def _leaking_nansum(arr, axis=None):
    _retained.append(np.empty(1024))
    return _original_nansum(arr, axis=axis)


@pytest.mark.thread_unsafe
@pytest.mark.parametrize(
    "nansum",
    [
        pytest.param(_original_nansum, id="no-mock"),
        pytest.param(
            _leaking_nansum,
            id="retained-arrays",
            marks=pytest.mark.xfail(
                reason="the probe must detect arrays retained by a reducer",
                raises=AssertionError,
                strict=True,
            ),
        ),
    ],
)
def test_memory_leak(monkeypatch, nansum):
    _retained.clear()
    monkeypatch.setattr(bn, "nansum", nansum)

    arr = np.arange(1).reshape((1, 1))

    def hammer(rounds):
        for _ in range(rounds):
            for axis in [None, 0, 1]:
                bn.nansum(arr, axis=axis)
                bn.nanargmax(arr, axis=axis)
                bn.nanargmin(arr, axis=axis)
                bn.nanmedian(arr, axis=axis)
                bn.nansum(arr, axis=axis)
                bn.nanmean(arr, axis=axis)
                bn.nanmin(arr, axis=axis)
                bn.nanmax(arr, axis=axis)
                bn.nanvar(arr, axis=axis)

    # Warm up so one-time allocations (caches, lazy imports) settle before
    # tracemalloc starts measuring.
    hammer(50)
    gc.collect()
    tracemalloc.start()
    try:
        before = tracemalloc.take_snapshot()
        rounds = 1000
        hammer(rounds)
        gc.collect()
        after = tracemalloc.take_snapshot()
    finally:
        tracemalloc.stop()

    grew = sum(stat.size_diff for stat in after.compare_to(before, "filename"))
    # Measure retained allocations, not process-wide peak RSS (gh-597).
    # Allow the same per-round noise and free-threaded fixed overhead as the
    # error-path probe below, well below one leaked ndarray per round.
    assert grew < rounds * 16 + 16 * 1024


def test_refcount_leak():
    # see https://github.com/pydata/bottleneck/issues/521
    rs = np.random.RandomState(0)
    arr = np.asfortranarray(rs.rand(8, 8))
    start_rc = sys.getrefcount(arr)

    for _ in range(1000):
        bn.rankdata(arr)

    assert sys.getrefcount(arr) == start_rc


@pytest.mark.thread_unsafe
@pytest.mark.parametrize(
    "func, arr",
    [
        pytest.param(bn.nanmin, np.zeros((4, 0), dtype=np.float64), id="nanmin-empty"),
        pytest.param(bn.nanmax, np.zeros((4, 0), dtype=np.int64), id="nanmax-empty"),
        pytest.param(
            bn.nanargmin, np.zeros((4, 0), dtype=np.float64), id="nanargmin-empty"
        ),
        pytest.param(
            bn.nanargmax, np.zeros((4, 0), dtype=np.int64), id="nanargmax-empty"
        ),
        pytest.param(
            bn.nanargmin,
            np.full((4, 2), np.nan, dtype=np.float64),
            id="nanargmin-allnan",
        ),
        pytest.param(
            bn.nanargmax,
            np.full((4, 2), np.nan, dtype=np.float64),
            id="nanargmax-allnan",
        ),
    ],
)
def test_reducer_error_path_leak(func, arr):
    # The single-axis reducers build their output array before checking for an
    # empty reduction axis or an all-NaN slice, then raised without releasing
    # it, leaking one output array per call. A dtype-refcount probe catches this
    # on 3.10-3.12 but not on 3.13+, where the builtin dtype singletons are
    # immortal and their refcount no longer moves, so measure the net allocation
    # directly with tracemalloc instead.
    def hammer(rounds):
        for _ in range(rounds):
            with pytest.raises(ValueError):
                func(arr, axis=1)

    hammer(50)  # warm up any one-time caches before sampling
    gc.collect()

    tracemalloc.start()
    before = tracemalloc.take_snapshot()
    rounds = 400
    hammer(rounds)
    gc.collect()
    after = tracemalloc.take_snapshot()
    tracemalloc.stop()

    grew = sum(stat.size_diff for stat in after.compare_to(before, "filename"))
    # Each leaked output array is ~140 bytes, so the unfixed code grows by
    # rounds * ~140 bytes here; the fix keeps this near zero. The budget is
    # 16 bytes/call for allocator noise that scales with the loop, plus a
    # fixed 16 KiB because free-threaded builds retain ~7 KiB of
    # interpreter-internal allocations per tracemalloc window regardless of
    # call count (gh-574), which a purely per-call budget cannot absorb.
    assert grew < rounds * 16 + 16 * 1024
