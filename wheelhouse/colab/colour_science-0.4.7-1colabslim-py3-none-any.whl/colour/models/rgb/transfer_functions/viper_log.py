"""
Viper Log Encoding
==================

Define the *Viper Log* encoding.

-   :func:`colour.models.log_encoding_ViperLog`
-   :func:`colour.models.log_decoding_ViperLog`

References
----------
-   :cite:`SonyImageworks2012a` : Sony Imageworks. (2012). make.py. Retrieved
    November 27, 2014, from
    https://github.com/imageworks/OpenColorIO-Configs/blob/master/\
nuke-default/make.py
"""

from __future__ import annotations

import numpy as np

from colour.hints import (  # noqa: TC001
    Domain1,
    Range1,
)
from colour.utilities import as_float, from_range_1, to_domain_1

__author__ = "Colour Developers"
__copyright__ = "Copyright 2013 Colour Developers"
__license__ = "BSD-3-Clause - https://opensource.org/licenses/BSD-3-Clause"
__maintainer__ = "Colour Developers"
__email__ = "colour-developers@colour-science.org"
__status__ = "Production"

__all__ = [
    "log_encoding_ViperLog",
    "log_decoding_ViperLog",
]


def log_encoding_ViperLog(x: Domain1) -> Range1:
    """
    Apply the *Viper Log* log encoding opto-electronic transfer function (OETF).

    Parameters
    ----------
    x
        Linear data :math:`x`.

    Returns
    -------
    :class:`numpy.ndarray`
        Non-linear encoded data :math:`y`.

    Notes
    -----
    +------------+-----------------------+---------------+
    | **Domain** | **Scale - Reference** | **Scale - 1** |
    +============+=======================+===============+
    | ``x``      | 1                     | 1             |
    +------------+-----------------------+---------------+

    +------------+-----------------------+---------------+
    | **Range**  | **Scale - Reference** | **Scale - 1** |
    +============+=======================+===============+
    | ``y``      | 1                     | 1             |
    +------------+-----------------------+---------------+

    References
    ----------
    :cite:`SonyImageworks2012a`

    Examples
    --------
    >>> log_encoding_ViperLog(0.18)  # doctest: +ELLIPSIS
    0.6360080...
    """

    x = to_domain_1(x)

    y = (1023 + 500 * np.log10(x)) / 1023

    return as_float(from_range_1(y))


def log_decoding_ViperLog(y: Domain1) -> Range1:
    """
    Apply the *Viper Log* log decoding inverse opto-electronic transfer function (OETF).

    Parameters
    ----------
    y
        Non-linear encoded data :math:`y`.

    Returns
    -------
    :class:`numpy.ndarray`
        Linear data :math:`x`.

    Notes
    -----
    +------------+-----------------------+---------------+
    | **Domain** | **Scale - Reference** | **Scale - 1** |
    +============+=======================+===============+
    | ``y``      | 1                     | 1             |
    +------------+-----------------------+---------------+

    +------------+-----------------------+---------------+
    | **Range**  | **Scale - Reference** | **Scale - 1** |
    +============+=======================+===============+
    | ``x``      | 1                     | 1             |
    +------------+-----------------------+---------------+

    References
    ----------
    :cite:`SonyImageworks2012a`

    Examples
    --------
    >>> log_decoding_ViperLog(0.636008067010413)  # doctest: +ELLIPSIS
    0.1799999...
    """

    y = to_domain_1(y)

    x = 10 ** ((1023 * y - 1023) / 500)

    return as_float(from_range_1(x))
