# ########################################################################### #
#    Copyright (c) 2019-2020, California Institute of Technology.
#    All rights reserved.  Based on Government Sponsored Research under
#    contracts NNN12AA01C, NAS7-1407 and/or NAS7-03001.
#
#    Redistribution and use in source and binary forms, with or without
#    modification, are permitted provided that the following conditions
#    are met:
#      1. Redistributions of source code must retain the above copyright
#         notice, this list of conditions and the following disclaimer.
#      2. Redistributions in binary form must reproduce the above copyright
#         notice, this list of conditions and the following disclaimer in
#         the documentation and/or other materials provided with the
#         distribution.
#      3. Neither the name of the California Institute of
#         Technology (Caltech), its operating division the Jet Propulsion
#         Laboratory (JPL), the National Aeronautics and Space
#         Administration (NASA), nor the names of its contributors may be
#         used to endorse or promote products derived from this software
#         without specific prior written permission.
#
#    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE CALIFORNIA
#    INSTITUTE OF TECHNOLOGY BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
#    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
#    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
#    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
#    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# ########################################################################### #
#    EXOplanet Transit Interpretation Code (EXOTIC)
#    # NOTE: See companion file version.py for version info.
# ########################################################################### #
# IMPORTANT RUNTIME INFORMATION ABOUT DATA ACCESS AND STORAGE
#
# If the user presses enter to run the sample data, download sample data if
# needed and put it into a sample-data directory at the top level of the
# user's Gdrive. Count the .fits files (images) and .json files (inits files)
# in the directory entered by the user (or in the sample-data directory if the
# user pressed enter).  If there are at least 20 .fits files, assume this is a
# directory of images and display the first one in the series. If there is
# exactly one inits file in the directory, show the specified target and comp
# coords so that the user can check these against the displayed image.
# Otherwise, prompt for target / comp coords and make an inits file based on
# those (save this new inits file in the folder with the output files so that
# the student can consult it later).  Finally, run EXOTIC with the newly-made
# or pre-existing inits file, plus any other inits files in the directory.
#
#########################################################
from astropy.io import fits
from astropy.time import Time
# import bokeh.io
# from bokeh.io import output_notebook
from bokeh.plotting import figure, show
from bokeh.models import BoxZoomTool, ColorBar, FreehandDrawTool, HoverTool, LogColorMapper, \
  LogTicker, PanTool, ResetTool, WheelZoomTool
# import copy
from IPython.display import display, HTML
# from IPython.display import Image
# from ipywidgets import widgets, HBox
import json
import numpy as np
import os
import re
from skimage.transform import downscale_local_mean
# import subprocess

try:
  from .filters import MICROOBSERVATORY_COLOR_TELESCOPES, normalize_microobservatory_filter
except ImportError:
  from filters import MICROOBSERVATORY_COLOR_TELESCOPES, normalize_microobservatory_filter


def display_image(filename):
    #print(f"{filename}")
    hdu = fits.open(filename)

    extension = 0
    image_header = hdu[extension].header
    while image_header["NAXIS"] == 0:
      extension += 1
      image_header = hdu[extension].header

    dheader = dict(hdu[extension].header)
  
    data = hdu[extension].data
    megapixel_factor = (data.shape[0])*(data.shape[1])/1000000.0
    if megapixel_factor > 5:
      print(f"Downsampling image because it has {megapixel_factor} megapixels.")
      image_downscaled = downscale_local_mean(data, (2, 2)).astype(int)
      data = image_downscaled
    
    max_y = len(data)
    max_x = len(data[0])
    p_height = 500
    p_width = int((p_height/max_y) * max_x)

    # quick hot pixel/ cosmic ray mask
    # mask, cdata = detect_cosmics(
    #     data, psfmodel='gauss',
    #     psffwhm=4, psfsize=2*round(4)+1, # just a guess
    #     sepmed=False, sigclip = 4.25,
    #     niter=3, objlim=10, cleantype='idw', verbose=False
    # )

    # create a figure with text on mouse hover
    fig = figure(tooltips=[("x", "$x"), ("y", "$y"), ("value", "@image")], width=p_width, height=p_height,
        tools=[PanTool(),BoxZoomTool(),WheelZoomTool(),ResetTool(),HoverTool()])
    fig.x_range.range_padding = fig.y_range.range_padding = 0

    r = fig.multi_line('x', 'y', source={'x':[],'y':[]},color='white',line_width=3)
    fig.add_tools(FreehandDrawTool(renderers=[r]))

    # set up a colobar + data range
    color_mapper = LogColorMapper(palette="Cividis256", low=np.percentile(data, 55), high=np.percentile(data, 99))

    # must give a vector of image data for image parameter
    fig.image(
        image=[data],
          x=0, y=0, dw=hdu[extension].data.shape[1], dh=hdu[extension].data.shape[0],
          level="image", color_mapper=color_mapper
    )
    fig.grid.grid_line_width = 0.5

    color_bar = ColorBar(color_mapper=color_mapper, ticker=LogTicker(),
                         label_standoff=12, border_line_color=None, location=(0,0))

    fig.add_layout(color_bar, 'right')

    show(fig)

#########################################################

def floats_to_ints(l):
  while (True):
#    print (l)
    m = re.search(r"^(.*?)(\d+\.\d+)(.*?)$", l)
    if m:
      start, fl, end = m.group(1), float(m.group(2)), m.group(3)
      l = start+str("%.0f" % fl)+end
    else:
      return(l)
  
#########################################################

# Find a field in the image fits header or prompt the user to enter the corresponding
# value.

def check_dir(p):
  p = p.replace("\\", "/")

  if not(os.path.isdir(p)):
    print(f"Problem: the directory {p} doesn't seem to exist")
    print("on your Gdrive filesystem.")
    return("")
  return(p)

#########################################################

def add_sign(var):
  str_var = str(var)
  m=re.search(r"^[\+\-]", str_var)
  if m:
    return(str_var)
  if float(var) >= 0:
    return(str("+%.6f" % float(var)))
  else:
    return(str("-%.6f" % float(var)))

#########################################################

def get_val(hdr, ks):
  for key in ks:
    if key in hdr.keys():
      return hdr[key]
    if key.lower() in hdr.keys():
      return hdr[key.lower()]
    new_key = key[0]+key[1:len(key)].lower()  # first letter capitalized
    if new_key in hdr.keys():
      return hdr[new_key]
  return("")

#########################################################

def process_lat_long(val, key):
  text = str(val).strip()
  coordinate_type = str(key).strip().lower()
  valid_hemispheres = {
      "latitude": {"N", "S"},
      "longitude": {"E", "W"},
  }.get(coordinate_type)
  hemisphere = None
  trailing_hemisphere = re.search(r"([NSEW])\s*$", text)
  leading_hemisphere = re.match(r"\s*([NSEW])(?=\s|[+-]?\d)", text)
  hemisphere_match = trailing_hemisphere or leading_hemisphere
  if hemisphere_match:
    hemisphere = hemisphere_match.group(1)
    if valid_hemispheres is not None and hemisphere not in valid_hemispheres:
      print(f"Cannot match value {val}, which is meant to be {key}.")
      return None
    start, end = hemisphere_match.span(1)
    text = f"{text[:start]}{text[end:]}".strip()

  number_tokens = re.findall(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", text)
  if not 1 <= len(number_tokens) <= 3:
    print(f"Cannot match value {val}, which is meant to be {key}.")
    return None
  if (len(number_tokens) == 1 and hemisphere is None and
      "." not in number_tokens[0] and number_tokens[0][0] not in "+-"):
    print(f"Cannot match value {val}, which is meant to be {key}.")
    return None

  degrees = float(number_tokens[0])
  minutes = abs(float(number_tokens[1])) if len(number_tokens) >= 2 else 0.0
  seconds = abs(float(number_tokens[2])) if len(number_tokens) >= 3 else 0.0
  magnitude = abs(degrees) + minutes / 60.0 + seconds / 3600.0
  if hemisphere:
    sign = -1.0 if hemisphere in {"S", "W"} else 1.0
  else:
    sign = -1.0 if number_tokens[0].startswith("-") else 1.0
  return(add_sign(sign * magnitude))

#########################################################

# Convert a MicroObservatory timestamp (which is in local time) to UTC.

def convert_Mobs_to_utc(datestamp, latitude, longitude, height):

#  print(datestamp)
  t = Time(datestamp[0:21], format='isot', scale='utc')
  t -= 0.33

  return(str(t)[0:10])

#########################################################

def find (hdr, ks, obs):
  # Special stuff for MicroObservatory (MObs)
  mobs = {"FILTER": "CV", "LATITUDE": "+31.675467", "LONGITUD": "-110.951376", "HEIGHT": 1268}

  if "OBSERVAT" in hdr.keys() and hdr["OBSERVAT"] == 'Whipple Observatory':
    obs = "MObs"

  telescope = get_val(hdr, ["TELESCOP"])
  is_color_telescope = str(telescope).strip().casefold() in MICROOBSERVATORY_COLOR_TELESCOPES
  if ks[0] == "FILTER" and (obs == "MObs" or is_color_telescope):
    # Read the observation's filter, including alternate cards when the
    # primary card is blank. Ben and Donald use standard color codes;
    # a missing filter on either telescope defaults to Cousins R.
    for filter_key in ks:
      filter_value = get_val(hdr, [filter_key])
      if filter_value is not None and str(filter_value).strip():
        filter_value = normalize_microobservatory_filter(telescope, filter_value)
        return "CV" if str(filter_value).strip().casefold() == "clear" else filter_value
    if is_color_telescope:
      return "R"

  if obs == "MObs":
    mobs_val = get_val(mobs, ks)
    if (mobs_val != ""):
      return(mobs_val)

  val = get_val(hdr, ks)

  if ks[0] == "LATITUDE" and val != "":         # Because EXOTIC needs these with signs shown.
    return(process_lat_long(str(val), "latitude"))
  if ks[0] == "LONGITUD" and val != "":
    return(process_lat_long(str(val), "longitude"))

  if (val != ""):
    return(val)

  print(f"\nI cannot find a field with any of these names in your image header: \n{ks}.")
  print("Please enter the value (not the name of the header field, the actual value) that should")
  print("be used for the value associated with this field.\n")
  if ks[0] == "HEIGHT":
    print("The units of elevation are meters.")
  
  value = input("")

  return(value)

###############################################

def look_for_calibration(image_dir):
  darks_dir, flats_dir, biases_dir = "null", "null", "null"

  m = re.search(r"(.*?)(\d\d\d\d\-\d\d\-\d\d)\/images", image_dir)  # This handles the way I set up the MObs image paths for my seminar teams.
  if m:
    prefix, date = m.group(1), m.group(2)
    darks = prefix+date+"/darks"
    if os.path.isdir(darks):
      darks_dir = str("\""+darks+"\"")
      
  d_names = ["dark", "darks", "DARK", "DARKS", "Dark", "Darks"]  # Possible names for calibration image directories.
  f_names = ["flat", "flats", "FLAT", "FLATS", "Flat", "Flats"]
  b_names = ["bias", "biases", "BIAS", "BIASES", "Bias", "Biases"]

  for d in d_names:
    if os.path.isdir(os.path.join(image_dir, d)):
      darks_dir = str("\""+os.path.join(image_dir, d)+"\"")
      break

  for f in f_names:
    if os.path.isdir(os.path.join(image_dir, f)):
      flats_dir = str("\""+os.path.join(image_dir, f)+"\"")
      break

  for b in b_names:
    if os.path.isdir(os.path.join(image_dir, b)):
      biases_dir = str("\""+os.path.join(image_dir, b)+"\"")
      break

  return(darks_dir, flats_dir, biases_dir)

###############################################

# Writes a new inits file into the directory with the output plots.  This prompts
# for needed information that it cannot find in the fits header of the first image.

def pixel_binning_from_header(hdr, default="1x1"):
  """Return the "NxM" binning string from the frame's header, else the default.

  MicroObservatory frames are 2x2 binned and say so (XBINNING/YBINNING); other
  observatories' frames carry their own values, so read them rather than
  hardcoding one observatory's binning into the template.
  """
  for x_key, y_key in (("XBINNING", "YBINNING"), ("CCDXBIN", "CCDYBIN"), ("XBIN", "YBIN")):
    x_bin = hdr.get(x_key)
    if x_bin is None:
      continue
    y_bin = hdr.get(y_key, x_bin)
    try:
      x_bin, y_bin = int(float(x_bin)), int(float(y_bin))
    except (TypeError, ValueError):
      continue
    if x_bin > 0 and y_bin > 0:
      return f"{x_bin}x{y_bin}"
  binning = hdr.get("BINNING")
  if isinstance(binning, str) and re.fullmatch(r"\s*\d+\s*[xX]\s*\d+\s*", binning):
    return binning.strip().lower()
  return default


def make_inits_file(planetary_params, image_dir, output_dir, first_image, targ_coords, comp_coords, obs, aavso_obs_code, sec_obs_code, sample_data):
  inits_file_path = output_dir+"inits.json"
  hdul = fits.open(first_image)

  extension = 0
  hdr = fits.getheader(filename=first_image, ext=extension)
  while hdr['NAXIS'] == 0:
    extension += 1
    hdr = fits.getheader(filename=first_image, ext=extension)

  min, max = "null", "null"
  filter = find(hdr, ['FILTER', 'FILT'], obs)
  if filter == "w":
    filter = "PanSTARRS-w"
    min = "404"
    max = "846"
  if filter == "Clear":
    filter = "V"
  if filter == "ip":
    min = "690"
    max = "819"
  if filter == "EXO":
    filter = "CBB"
  if re.search(r"Green", filter, re.IGNORECASE):
    filter = "SG"
    
  date_obs = find(hdr,["DATE", "DATE_OBS", "DATE-OBS"], obs)
  date_obs = date_obs.replace("/", "_")
  longitude = find(hdr,['LONGITUD', 'LONG', 'LONGITUDE', 'SITELONG'],obs)
  latitude = find(hdr,['LATITUDE', 'LAT', 'SITELAT'],obs)
  height = float(find(hdr, ['HEIGHT', 'ELEVATION', 'ELE', 'EL', 'OBSGEO-H', 'ALT-OBS', 'SITEELEV'], obs))
  pixel_binning = pixel_binning_from_header(hdr)
  obs_notes = "N/A"

  mobs_data = False
  # For MObs, the date is local rather than UTC, so convert.
  if "OBSERVAT" in hdr.keys() and hdr["OBSERVAT"] == 'Whipple Observatory':
    date_obs = convert_Mobs_to_utc(date_obs, latitude, longitude, height)
    weather = hdr["WEATHER"] 
    temps = float(hdr["TELTEMP"]) - float(hdr["CAMTEMP"])
    obs_notes = str("First image seeing %s (0: poor, 100: excellent), Teltemp - Camtemp %.1f.  These observations were conducted with MicroObservatory, a robotic telescope network managed by the Harvard-Smithsonian Center for Astrophysics on behalf of NASA's Universe of Learning. This work is supported by NASA under award number NNX16AC65A to the Space Telescope Science Institute." % (weather, temps))
    sec_obs_code = "MOBS"  
    mobs_data = True
  
  if aavso_obs_code == "":
      aavso_obs_code = "N/A"
  if sec_obs_code == "":
      sec_obs_code = "N/A"

  obs_date = date_obs[0:10]
  (darks_dir, flats_dir, biases_dir) = look_for_calibration(image_dir)

  with open(inits_file_path, 'w') as inits_file:
    inits_file.write("""
{
  %s,
    "user_info": {
            "Directory with FITS files": "%s",
            "Directory to Save Plots": "%s",
            "Directory of Flats": %s,
            "Directory of Darks": %s,
            "Directory of Biases": %s,

            "AAVSO Observer Code (N/A if none)": "%s",
            "Secondary Observer Codes (N/A if none)": "%s",
            "Observatory Full Title": "",

            "Observation date": "%s",
            "Obs. Latitude": "%s",
            "Obs. Longitude": "%s",
            "Obs. Elevation (meters)": %d,
            "Camera Type (CCD or DSLR)": "CCD",
            "Pixel Binning": "%s",
            "Filter Name (aavso.org/filters)": "%s",
            "Observing Notes": "%s",

            "Plate Solution? (y/n)": "y",
            "Add Comparison Stars from AAVSO? (y/n)": "n",

            "Target Star X & Y Pixel": %s,
            "Comparison Star(s) X & Y Pixel": %s,
            "Comparison Star(s) RA & Dec": null,
            
            "Demosaic Format": null,
            "Demosaic Algorithm": "bilinear",
            "Demosaic Output": null
    },    
    "optional_info": {
            "Pixel Scale (Ex: 5.21 arcsecs/pixel)": null,
            "Filter Minimum Wavelength (nm)": %s,
            "Filter Maximum Wavelength (nm)": %s,
            "Calculate Limb Darkening Coefficients with Uncertainties? (y/n)": null,
            "allow_pixel_alignment_fallback": true,
            "bad_wcs_threshold_percent": 3.0,
            "detrend_on_outoftransit_baseline": true,
            "restrict_baseline_to_an_hour": true,
            "use_eebls_to_initialize_tmid_and_bounds": "y",
            "pick_comparison_by_eebls_snr": "y",
            "use_impactparameter_rather_than_inclination_to_fit": "y",
            "maximum_number_of_ensemble_comparisons_for_transit": 5,
            "maximum_number_of_ensemble_comparisons_for_stellar_variability": 5,
            "require_apparent_magnitudes": true,
            "use_exactly_the_comps_provided": false,
            "use_adaptive_apertures": false,
            "gain_electrons_per_adu": null,
            "read_noise_electrons": null,
            "dark_current_electrons_per_second_per_pixel": null,
            "flat_field_fractional_error": null,
            "telescope_aperture_m": null,
            "scintillation_coefficient": null,
            "require_comp_star": "y"
    }
}
""" % (planetary_params, image_dir, output_dir, flats_dir, darks_dir, biases_dir, 
       aavso_obs_code, sec_obs_code, obs_date, latitude, longitude, height, pixel_binning, filter, 
       obs_notes, targ_coords, comp_coords, min, max))

  display(HTML('<p class="output"><b>Initialization File Created.</b></p>'))
  print(f'Created: {inits_file_path}')
  print('This folder will also contain the output files when EXOTIC finishes running.')

  if not mobs_data:  
    print(f"\nThe inits.json file currently says that your observatory latitude was {latitude} deg,")
    print(f"longitude was {longitude} deg, and elevation was {height}m.  \n")
    print("*** If any of these are incorrect, please change them in the inits.json file. ***")
    print("*** (Please make sure that Western longitudes have a negative sign! ***")
    print("*** TheSkyX sometimes stamps Western longitudes as positive; this needs to be switched! ***\n")

  display(HTML('<p class="output"><br /><b>If you want to change anything in the inits file, such as planetary parameters or user info, please do that now.</b></p>'))
  print('You can edit the file by clicking the folder icon in the left nav,')
  print(f'navigating to the inits file at {inits_file_path}, and double-clicking the file.')
  print('\nWhen you are done, save your changes, and proceed to the next step.')
  

  return(inits_file_path)
  
##############################################################

def fix_planetary_params (p_param_dict):
  metadata_fields = {
    "Target Star RA", "Target Star Dec", "Planet Name", "Host Star Name",
    "Published Mid-Transit Time Standard", "Published Mid-Transit Time Reference",
  }
  for param in p_param_dict.keys():
    if param in metadata_fields or param == "Argument of Periastron (deg)":
      continue
    val = p_param_dict[param]
    if val is None or val == 0.0 or np.isnan(float(val)):
      if param == "Orbital Eccentricity (0 if null)":
        continue
      if param == "Ratio of Planet to Stellar Radius (Rp/Rs)":
        p_param_dict[param] = 0.151
      if param == "Ratio of Planet to Stellar Radius (Rp/Rs) Uncertainty":
        p_param_dict[param] = 0.151
        if p_param_dict["Host Star Name"] == "Qatar-6":
          p_param_dict[param] = 0.01
      print(f"\nIn the planetary parameters from the NASA Exoplanet Archive, \n\"{param}\" is listed as {val}.\n\n**** This might make EXOTIC crash. ****\n\nIf the parameter is *not* changed below, please edit it\nin the inits file before running EXOTIC.\n")
  # Preserve metadata as JSON strings/nulls, including quoted HTML references.
  return '"planetary_parameters": ' + json.dumps(p_param_dict, indent=4)
