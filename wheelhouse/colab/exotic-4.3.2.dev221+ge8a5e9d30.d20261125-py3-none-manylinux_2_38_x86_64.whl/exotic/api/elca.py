# ########################################################################### #
#    Copyright (c) 2019-2020, California Institute of Technology.
#    All rights reserved.  Based on Government Sponsored Research under
#    contracts NNN12AA01C, NAS7-1407 and/or NAS7-03001.
#
#    Redistribution and use in source and binary forms, with or without
#    modification, are permitted provided that the following conditions
#    are met:
#      1. Redistributions of source code must retain the above copyright
#         notice, this list of conditions and the following disclaimer.
#      2. Redistributions in binary form must reproduce the above copyright
#         notice, this list of conditions and the following disclaimer in
#         the documentation and/or other materials provided with the
#         distribution.
#      3. Neither the name of the California Institute of
#         Technology (Caltech), its operating division the Jet Propulsion
#         Laboratory (JPL), the National Aeronautics and Space
#         Administration (NASA), nor the names of its contributors may be
#         used to endorse or promote products derived from this software
#         without specific prior written permission.
#
#    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE CALIFORNIA
#    INSTITUTE OF TECHNOLOGY BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
#    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
#    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
#    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
#    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# ########################################################################### #
#    EXOplanet Transit Interpretation Code (EXOTIC)
#    # NOTE: See companion file version.py for version info.
# ########################################################################### #
# Exoplanet light curve analysis
#
# Fit an exoplanet transit model to time series data.
# ########################################################################### #
from astropy.time import Time
import copy
from itertools import cycle, product
import math
import os
import sys
from time import perf_counter
import bottleneck as bn
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator
import numpy as np
from scipy import spatial
from scipy.optimize import OptimizeResult, least_squares
from scipy.signal import savgol_filter
from scipy.special import ndtr, ndtri
from ultranest import ReactiveNestedSampler

try:
    from ..utils import format_value_and_uncertainty, format_value_with_uncertainty, residual_plot_limits
except ImportError:
    from utils import format_value_and_uncertainty, format_value_with_uncertainty, residual_plot_limits

try:
    from plotting import corner
except ImportError:
    from .plotting import corner

try:
    from ultranest_utils import run_reactive_sampler
except ImportError:
    from .ultranest_utils import run_reactive_sampler

BAD_LOG_LIKELIHOOD = -1.0e100
TRIANGLE_PLOT_EDGE_PEAK_FRACTION_MAX = 0.50
TRIANGLE_PLOT_EDGE_MIN_SAMPLE_COUNT = 30
TRIANGLE_PLOT_EDGE_EXPANSION_STEPS = 8
TRIANGLE_PLOT_FALLBACK_EXPANSION_BOUNDS = {
    'rprs': (0.0, 1.0),
}
TRANSIT_MODEL_UNCERTAINTY_KEYS = (
    'rprs', 'tmid', 'inc', 'ars', 'per', 'ecc', 'omega', 'u0', 'u1', 'u2', 'u3',
    'h0', 'h1', 'h2', 'h3',
)
BASELINE_MODEL_UNCERTAINTY_KEYS = ('a0', 'a1', 'a2')
MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT = 2000
EXPOSURE_SMEARING_EXPOSURE_TIME_KEY = '_exposure_time_days'
EXPOSURE_SMEARING_SUPERSAMPLE_KEY = '_exposure_smearing_supersample'
EXPOSURE_SMEARING_CHANGE_TOLERANCE_KEY = '_exposure_smearing_change_tolerance'
DEFAULT_EXPOSURE_SMEARING_SUPERSAMPLE = 7
DEFAULT_EXPOSURE_SMEARING_CHANGE_TOLERANCE = 1.0e-5
MIN_EXPOSURE_SMEARING_SECONDS = 1.0
EXPOSURE_SMEARING_TRANSIT_WINDOW_PADDING_FACTOR = 2.0
# Guard against a posterior summary that is really the prior width (a sampler that
# never localized), see test_nested_fit_replaces_prior_width_like_error_with_local_likelihood_width.
# The local reference is the profile-likelihood 1-sigma extent (half-range of the
# delta-chi2<=1 dead points, scaled by 1/sqrt(delta_chi2) when the window had to widen).
# A healthy fit lands at ratio ~0.7-1.5 against that reference; the prior-width pathology
# lands at ~20. The factor must sit well clear of the healthy band. Issue #1401: the previous
# reference (std of the delta-chi2<=1 points) is biased low by ~sqrt(d+2) in d sampled
# dimensions, so with factor 3.0 a healthy 4-parameter fit sat AT the threshold and the
# Tmid bar was cut ~3x on some runs and not others depending on sampler density.
ULTRANEST_INFLATED_ERROR_REPLACEMENT_FACTOR = 5.0
ULTRANEST_LOCAL_UNCERTAINTY_MAX_DELTA_CHI2 = 9.0
ULTRANEST_EXPANDED_PRIOR_WARMSTART_FULL_PRIOR_FRACTION = 0.5
ULTRANEST_EXPANDED_PRIOR_WARMSTART_MINIMUM_SAMPLE_COUNT = 32
ULTRANEST_EXPANDED_PRIOR_WARMSTART_MAXIMUM_SAMPLE_COUNT = 20000


def _format_differential_hour_tick(hours, _position=None):
    """Format half-hour offsets around phase zero with an explicit sign."""
    if not np.isfinite(hours):
        return ""
    if np.isclose(hours, 0.0, atol=1.0e-9):
        return "0"
    return f"{hours:+.1f}"


def _add_differential_hours_axis(ax, period_days):
    """Add a phase-aligned hours axis to the upper edge of a phase plot."""
    try:
        period_hours = float(period_days) * 24.0
    except (TypeError, ValueError):
        return None
    if not np.isfinite(period_hours) or period_hours <= 0:
        return None

    def phase_to_hours(phase):
        return np.asarray(phase, dtype=float) * period_hours

    def hours_to_phase(hours):
        return np.asarray(hours, dtype=float) / period_hours

    time_axis = ax.secondary_xaxis(
        'top',
        functions=(phase_to_hours, hours_to_phase),
    )
    time_axis.xaxis.set_major_locator(MultipleLocator(0.5))
    time_axis.xaxis.set_major_formatter(FuncFormatter(_format_differential_hour_tick))
    time_axis.set_xlabel("Time [hours]", fontsize=14)
    return time_axis


try:
    from .transit_reference import planet_orbit, transit as pytransit
except ImportError:
    from transit_reference import planet_orbit, transit as pytransit


def weightedflux(flux, gw, nearest):
    return np.sum(flux[nearest] * gw, axis=-1)


def gaussian_weights(X, w=1, neighbors=50, feature_scale=1000):
    Xm = (X - np.median(X, 0)) * w
    kdtree = spatial.cKDTree(Xm * feature_scale)
    nearest = np.zeros((X.shape[0], neighbors))
    gw = np.zeros((X.shape[0], neighbors), dtype=float)
    for point in range(X.shape[0]):
        ind = kdtree.query(kdtree.data[point], neighbors + 1)[1][1:]
        dX = Xm[ind] - Xm[point]
        Xstd = np.std(dX, 0)
        gX = np.exp(-dX ** 2 / (2 * Xstd ** 2))
        gwX = np.prod(gX, 1)
        gw[point, :] = gwX / gwX.sum()
        nearest[point, :] = ind
    gw[np.isnan(gw)] = 0.01
    return gw, nearest.astype(int)


def _instantaneous_transit(times, values):
    law = values.get('_limb_darkening_law', 'claret')
    if law == 'hybrid4':
        position = planet_orbit(
            values['per'], values['ars'], values['ecc'], values['inc'],
            values['omega'], values['tmid'], np.asarray(times, dtype=float),
        )
        separation = np.hypot(position[1], position[2])
        weights = [values[f'h{i}'] for i in range(4)]
        backend = values.get('_hybrid4_backend', 'numpy')
        if backend in ('cpp', 'cpp_flux'):
            try:
                from .limbdarkfast_cpp import hybrid4_flux
            except ImportError:
                from limbdarkfast_cpp import hybrid4_flux
            flux = hybrid4_flux(separation, values['rprs'], weights)
        elif backend == 'numpy':
            try:
                from .limbdarkfast import hybrid_flux
            except ImportError:
                from limbdarkfast import hybrid_flux
            flux = hybrid_flux(separation, values['rprs'], weights, 'hybrid4')
        else:
            raise ValueError(f'Unknown hybrid4 backend: {backend!r}')
        return np.where(position[0] < 0, 1.0, flux)
    if law != 'claret':
        raise ValueError(f'Unknown limb-darkening law: {law!r}')
    model = pytransit([values['u0'], values['u1'], values['u2'], values['u3']],
                      values['rprs'], values['per'], values['ars'],
                      values['ecc'], values['inc'], values['omega'],
                      values['tmid'], times, method='claret', precision=3)
    return model


def _exposure_time_days_for_times(values, shape):
    try:
        exposure_time_days = values.get(EXPOSURE_SMEARING_EXPOSURE_TIME_KEY)
    except AttributeError:
        return None
    if exposure_time_days is None:
        return None

    try:
        exposure_time_days = np.asarray(exposure_time_days, dtype=float)
    except (TypeError, ValueError):
        return None

    if exposure_time_days.shape == ():
        exposure_time_days = np.full(shape, float(exposure_time_days), dtype=float)
    elif exposure_time_days.shape != shape:
        return None
    else:
        exposure_time_days = np.array(exposure_time_days, dtype=float, copy=True)

    minimum_exposure_days = MIN_EXPOSURE_SMEARING_SECONDS / 86400.0
    finite_positive = np.isfinite(exposure_time_days) & (exposure_time_days > minimum_exposure_days)
    if not np.any(finite_positive):
        return None

    exposure_time_days[~finite_positive] = 0.0
    return exposure_time_days


def _exposure_smearing_supersample(values):
    try:
        sample_count = int(values.get(EXPOSURE_SMEARING_SUPERSAMPLE_KEY, DEFAULT_EXPOSURE_SMEARING_SUPERSAMPLE))
    except (AttributeError, TypeError, ValueError):
        sample_count = DEFAULT_EXPOSURE_SMEARING_SUPERSAMPLE
    sample_count = max(3, sample_count)
    if sample_count % 2 == 0:
        sample_count += 1
    return sample_count


def _exposure_smearing_change_tolerance(values):
    try:
        tolerance = float(values.get(
            EXPOSURE_SMEARING_CHANGE_TOLERANCE_KEY,
            DEFAULT_EXPOSURE_SMEARING_CHANGE_TOLERANCE,
        ))
    except (AttributeError, TypeError, ValueError):
        tolerance = DEFAULT_EXPOSURE_SMEARING_CHANGE_TOLERANCE
    if not np.isfinite(tolerance) or tolerance < 0:
        tolerance = DEFAULT_EXPOSURE_SMEARING_CHANGE_TOLERANCE
    return tolerance


def _exposure_smearing_candidate_mask(times, exposure_time_days, values):
    candidate = (
        np.isfinite(times)
        & np.isfinite(exposure_time_days)
        & (exposure_time_days > MIN_EXPOSURE_SMEARING_SECONDS / 86400.0)
    )
    if not np.any(candidate):
        return candidate

    try:
        period = float(values['per'])
        tmid = float(values['tmid'])
    except (KeyError, TypeError, ValueError):
        return candidate
    if not np.isfinite(period) or period <= 0 or not np.isfinite(tmid):
        return candidate

    duration = transit_duration(values)
    if not np.isfinite(duration) or duration <= 0:
        return candidate

    max_exposure = np.nanmax(exposure_time_days[candidate])
    if not np.isfinite(max_exposure) or max_exposure <= 0:
        return np.zeros(times.shape, dtype=bool)

    half_window = (
        0.5 * duration
        + (0.5 + EXPOSURE_SMEARING_TRANSIT_WINDOW_PADDING_FACTOR) * max_exposure
    )
    phase_days = get_phase(times[candidate], period, tmid) * period
    narrowed = np.abs(phase_days) <= half_window
    candidate_indices = np.flatnonzero(candidate)
    candidate[candidate_indices] = narrowed
    return candidate


def transit(times, values):
    if values.get('_limb_darkening_law','claret') == 'claret':
        backend = values.get('_claret_backend','cpp')
        if backend == 'cpp':
            try:
                from .limbdarkfast_cpp import claret_transit
            except ImportError:
                from limbdarkfast_cpp import claret_transit
            return claret_transit(
                times,values,samples=_exposure_smearing_supersample(values),
                tolerance=_exposure_smearing_change_tolerance(values),
                minimum_exposure_days=MIN_EXPOSURE_SMEARING_SECONDS/86400.,
                padding=EXPOSURE_SMEARING_TRANSIT_WINDOW_PADDING_FACTOR,
            )
        if backend != 'python':
            raise ValueError(f'Unknown Claret backend: {backend!r}')
    if values.get('_limb_darkening_law') == 'hybrid4' and values.get('_hybrid4_backend') == 'cpp':
        try:
            from .limbdarkfast_cpp import hybrid4_transit
        except ImportError:
            from limbdarkfast_cpp import hybrid4_transit
        return hybrid4_transit(
            times, values, samples=_exposure_smearing_supersample(values),
            tolerance=_exposure_smearing_change_tolerance(values),
            minimum_exposure_days=MIN_EXPOSURE_SMEARING_SECONDS/86400.0,
            padding=EXPOSURE_SMEARING_TRANSIT_WINDOW_PADDING_FACTOR,
        )
    model = _instantaneous_transit(times, values)
    exposure_time_days = _exposure_time_days_for_times(values, np.asarray(times).shape)
    if exposure_time_days is None:
        return model

    try:
        times_array = np.asarray(times, dtype=float)
        model_array = np.asarray(model, dtype=float)
    except (TypeError, ValueError):
        return model
    if model_array.shape != times_array.shape:
        return model

    flat_times = times_array.reshape(-1)
    flat_model = model_array.reshape(-1).copy()
    flat_exposure_time_days = exposure_time_days.reshape(-1)
    candidate_mask = _exposure_smearing_candidate_mask(
        flat_times,
        flat_exposure_time_days,
        values,
    )
    candidate_indices = np.flatnonzero(candidate_mask)
    if candidate_indices.size == 0:
        return model_array

    candidate_times = flat_times[candidate_indices]
    candidate_exposures = flat_exposure_time_days[candidate_indices]
    half_exposures = 0.5 * candidate_exposures
    try:
        start_model = np.asarray(
            _instantaneous_transit(candidate_times - half_exposures, values),
            dtype=float,
        ).reshape(-1)
        end_model = np.asarray(
            _instantaneous_transit(candidate_times + half_exposures, values),
            dtype=float,
        ).reshape(-1)
    except Exception:
        return model_array
    if start_model.shape != candidate_times.shape or end_model.shape != candidate_times.shape:
        return model_array

    center_model = flat_model[candidate_indices]
    model_change = np.maximum.reduce((
        np.abs(start_model - center_model),
        np.abs(end_model - center_model),
        np.abs(end_model - start_model),
    ))
    active_indices = candidate_indices[model_change > _exposure_smearing_change_tolerance(values)]
    if active_indices.size == 0:
        return model_array

    sample_count = _exposure_smearing_supersample(values)
    offsets = (np.arange(sample_count, dtype=float) + 0.5) / sample_count - 0.5
    active_times = flat_times[active_indices]
    active_exposures = flat_exposure_time_days[active_indices]
    sample_times = (active_times[:, None] + active_exposures[:, None] * offsets[None, :]).reshape(-1)
    try:
        sample_model = np.asarray(_instantaneous_transit(sample_times, values), dtype=float)
    except Exception:
        return model_array
    if sample_model.size != active_indices.size * sample_count:
        return model_array

    flat_model[active_indices] = sample_model.reshape(active_indices.size, sample_count).mean(axis=1)
    return flat_model.reshape(model_array.shape)


def impact_parameter_scale(values):
    ecc = values.get('ecc', 0.0)
    omega = np.deg2rad(values.get('omega', 0.0))
    denom = 1.0 + ecc * np.sin(omega)
    if np.any(np.isclose(denom, 0.0)):
        denom = np.where(np.isclose(denom, 0.0), np.finfo(float).eps, denom)
    return values['ars'] * (1.0 - ecc ** 2) / denom


def impact_parameter_from_inclination(values, inclination):
    return impact_parameter_scale(values) * np.cos(np.deg2rad(inclination))


def inclination_from_impact_parameter(values, impact_parameter):
    scale = impact_parameter_scale(values)
    if np.any(np.isclose(scale, 0.0)):
        scale = np.where(np.isclose(scale, 0.0), np.finfo(float).eps, scale)
    cosi = np.clip(np.asarray(impact_parameter, dtype=float) / scale, -1.0, 1.0)
    return np.rad2deg(np.arccos(cosi))


def grazing_impact_parameter(values):
    try:
        rprs = float(values['rprs'])
    except (KeyError, TypeError, ValueError):
        return np.nan

    if not np.isfinite(rprs) or rprs < 0:
        return np.nan
    return 1.0 + rprs


def transit_duration(values, contact_radius=None):
    """Contact duration in days; a missing inner chord has zero duration."""
    try:
        period = float(values['per'])
        rprs = float(values['rprs'])
        ars = float(values['ars'])
        inc = float(values['inc'])
    except (KeyError, TypeError, ValueError):
        return np.nan

    if (
        not np.isfinite(period) or period <= 0
        or not np.isfinite(rprs) or rprs < 0
        or not np.isfinite(ars) or ars <= 0
        or not np.isfinite(inc)
    ):
        return np.nan

    ecc = values.get('ecc', 0.0)
    omega = np.deg2rad(values.get('omega', 0.0))
    sin_inc = np.sin(np.deg2rad(inc))
    if not np.isfinite(sin_inc) or sin_inc <= 0:
        return np.nan

    impact_scale = ars * (1.0 - ecc ** 2) / max(np.finfo(float).eps, 1.0 + ecc * np.sin(omega))
    impact_parameter = impact_scale * np.cos(np.deg2rad(inc))
    radius = 1.0 + rprs if contact_radius is None else float(contact_radius)
    chord_sq = radius ** 2 - impact_parameter ** 2
    if contact_radius is not None and chord_sq <= 0:
        return 0.0
    if not np.isfinite(chord_sq) or chord_sq <= 0 or not np.isfinite(impact_scale) or impact_scale <= 0:
        return np.nan

    # The arcsin argument is normalized by a*sin(i) (NOT by the eccentricity-
    # scaled planet-star separation), and the eccentric orbital-speed factor
    # sqrt(1-e^2)/(1+e*sin(omega)) multiplies the whole duration — the same
    # correction issue #1383 / PR #1384 applied to the three copies of this
    # formula in exotic.py and transit QC; this fourth copy was missed. The
    # broken form biased the ns duration prior, the QC duration score, and the
    # exposure-smearing window for every eccentric target.
    argument = np.sqrt(chord_sq) / (ars * sin_inc)
    argument = float(np.clip(argument, -1.0, 1.0))
    eccentric_speed_factor = np.sqrt(1.0 - ecc ** 2) / max(np.finfo(float).eps, 1.0 + ecc * np.sin(omega))
    duration = (period / np.pi) * np.arcsin(argument) * eccentric_speed_factor
    return float(duration) if np.isfinite(duration) and duration > 0 else np.nan


def get_phase(times, per, tmid):
    return (times - tmid + 0.25 * per) / per % 1 - 0.25


def normalize_time_range(time_range):
    if time_range is None:
        return None

    values = np.asarray(time_range, dtype=float).reshape(-1)
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return None

    return float(np.min(finite)), float(np.max(finite))


def get_plot_phase(times, per, tmid, reference_times=None):
    times = np.asarray(times, dtype=float)
    if not np.isfinite(per) or per == 0:
        return times * np.nan

    raw_phase = (times - tmid) / per

    reference_range = normalize_time_range(reference_times)
    if reference_range is None:
        finite_phase = raw_phase[np.isfinite(raw_phase)]
        if finite_phase.size == 0:
            return raw_phase
        reference_epoch = float(np.rint(0.5 * (np.min(finite_phase) + np.max(finite_phase))))
    else:
        ref_phase = (np.asarray(reference_range, dtype=float) - tmid) / per
        reference_epoch = float(np.rint(np.mean(ref_phase)))

    return raw_phase - reference_epoch


def fallback_flux_baseline():
    return 1.0


def has_explicit_flux_baseline(bounds):
    return any(key in bounds for key in ('a0', 'a1'))


def get_flux_baseline(values, fallback=1.0):
    if 'a0' in values:
        return values['a0']
    if 'a1' in values:
        return values['a1']
    return fallback


def get_airmass_reference(airmass):
    airmass = np.asarray(airmass, dtype=float)
    finite_airmass = airmass[np.isfinite(airmass)]
    if finite_airmass.size == 0:
        return 0.0
    return float(np.nanmean(finite_airmass))


def center_airmass(airmass, reference=None):
    airmass = np.asarray(airmass, dtype=float)
    if reference is None:
        reference = get_airmass_reference(airmass)
    return airmass - float(reference)


def airmass_trend(a2, airmass, reference=None):
    return np.exp(np.asarray(a2, dtype=float) * center_airmass(airmass, reference=reference))


def airmass_trend_grid(a2_values, airmass, reference=None):
    centered = center_airmass(airmass, reference=reference)
    return np.exp(np.outer(np.asarray(a2_values, dtype=float), centered))


def normalized_optional_fit_mask(mask, shape):
    if mask is None:
        return None
    fit_mask = np.asarray(mask, dtype=bool)
    if fit_mask.shape != tuple(shape):
        return None
    if not np.any(fit_mask):
        return None
    return fit_mask


def solve_flux_baseline(model, data, dataerr=None, mask=None):
    model = np.asarray(model, dtype=float)
    data = np.asarray(data, dtype=float)
    weights = np.ones(model.shape, dtype=float)
    fit_mask = normalized_optional_fit_mask(mask, model.shape)

    if dataerr is not None:
        dataerr = np.asarray(dataerr, dtype=float)
        weights = np.zeros(model.shape, dtype=float)
        valid_err = np.isfinite(dataerr) & (dataerr > 0)
        weights[valid_err] = 1.0 / (dataerr[valid_err] ** 2)

    mask = np.isfinite(model) & np.isfinite(data) & (model != 0)
    if fit_mask is not None:
        mask &= fit_mask
    if dataerr is not None:
        mask &= np.isfinite(weights) & (weights > 0)

    if not np.any(mask):
        return fallback_flux_baseline()

    masked_model = model[mask]
    masked_data = data[mask]
    masked_weights = weights[mask]
    denom = np.sum(masked_weights * masked_model ** 2)

    if not np.isfinite(denom) or denom <= 0:
        ratio = masked_data / masked_model
        ratio = ratio[np.isfinite(ratio)]
        if ratio.size == 0:
            return fallback_flux_baseline()
        baseline = np.nanmedian(ratio)
        return baseline if np.isfinite(baseline) else fallback_flux_baseline()

    baseline = np.sum(masked_weights * masked_data * masked_model) / denom
    return baseline if np.isfinite(baseline) else fallback_flux_baseline()


def solve_flux_baseline_uncertainty(model, dataerr, mask=None):
    if dataerr is None:
        return 0.0
    model = np.asarray(model, dtype=float)
    dataerr = np.asarray(dataerr, dtype=float)
    fit_mask = normalized_optional_fit_mask(mask, model.shape)
    mask = np.isfinite(model) & np.isfinite(dataerr) & (dataerr > 0)
    if fit_mask is not None:
        mask &= fit_mask
    if not np.any(mask):
        return 0.0
    denom = np.sum((model[mask] / dataerr[mask]) ** 2)
    if not np.isfinite(denom) or denom <= 0:
        return 0.0
    return (1.0 / denom) ** 0.5


def mc_a1(m_a2, sig_a2, transit, airmass, data, dataerr=None, n=10000, mask=None):
    n = int(n)
    a2 = np.random.normal(m_a2, sig_a2, n)
    reference = get_airmass_reference(airmass)
    transit = np.asarray(transit, dtype=float)
    data = np.asarray(data, dtype=float)
    airmass = np.asarray(airmass, dtype=float)
    centered_airmass = center_airmass(airmass, reference=reference)
    weights = np.ones(transit.shape[0], dtype=float)
    fit_mask = normalized_optional_fit_mask(mask, transit.shape)

    if dataerr is not None:
        dataerr = np.asarray(dataerr, dtype=float)
        weights = np.zeros(transit.shape[0], dtype=float)
        valid_err = np.isfinite(dataerr) & (dataerr > 0)
        weights[valid_err] = 1.0 / (dataerr[valid_err] ** 2)

    mask = np.isfinite(data) & np.isfinite(transit) & np.isfinite(centered_airmass)
    if fit_mask is not None:
        mask &= fit_mask
    if dataerr is not None:
        mask &= np.isfinite(weights) & (weights > 0)

    if not np.any(mask):
        return fallback_flux_baseline(), 0.0

    masked_transit = transit[mask]
    masked_airmass = centered_airmass[mask]
    masked_data = data[mask]
    masked_weights = weights[mask]
    numer = np.empty(n, dtype=float)
    denom = np.empty(n, dtype=float)
    chunk_size = 1024

    for start in range(0, n, chunk_size):
        stop = min(start + chunk_size, n)
        masked_model = masked_transit * np.exp(np.outer(a2[start:stop], masked_airmass))
        numer[start:stop] = np.sum(masked_weights * masked_data * masked_model, axis=1)
        denom[start:stop] = np.sum(masked_weights * masked_model ** 2, axis=1)
    valid = np.isfinite(numer) & np.isfinite(denom) & (denom > 0)

    if not np.any(valid):
        best_model = transit * airmass_trend(m_a2, airmass, reference=reference)
        baseline = solve_flux_baseline(best_model, data, dataerr, mask=fit_mask)
        return baseline, solve_flux_baseline_uncertainty(best_model, dataerr, mask=fit_mask)

    baselines = numer[valid] / denom[valid]
    baseline = float(np.nanmean(baselines))
    baseline_unc = float(np.nanstd(baselines))

    if baseline_unc == 0.0:
        best_model = transit * airmass_trend(m_a2, airmass, reference=reference)
        baseline_unc = solve_flux_baseline_uncertainty(best_model, dataerr, mask=fit_mask)

    return baseline, baseline_unc


def round_to_2(*args):
    x = args[0]
    if len(args) == 1:
        y = args[0]
    else:
        y = args[1]
    if np.floor(y) >= 1.:
        roundval = 2
    else:
        try:
            roundval = -int(np.floor(np.log10(abs(y)))) + 1
        except:
            roundval = 1
    return round(x, roundval)


def format_value_error_for_plot(value, error):
    """Format value/error text with a two-significant-figure uncertainty."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        value = np.nan

    try:
        error = float(error)
    except (TypeError, ValueError):
        error = np.nan

    if not np.isfinite(error) or error < 0:
        value_text = f"{value:.6f}".rstrip('0').rstrip('.') if np.isfinite(value) else "n/a"
        return value_text, "n/a"

    if not np.isfinite(value):
        return "n/a", format_value_and_uncertainty(0, error)[1]
    return format_value_and_uncertainty(value, error)


# average data into bins of dt from start to finish
def time_bin(time, flux, dt=1. / (60 * 24)):
    bins = int(np.floor((max(time) - min(time)) / dt))
    bflux = np.zeros(bins)
    btime = np.zeros(bins)
    bstds = np.zeros(bins)
    for i in range(bins):
        mask = (time >= (min(time) + i * dt)) & (time < (min(time) + (i + 1) * dt))
        if mask.sum() > 0:
            bflux[i] = bn.nanmean(flux[mask])
            btime[i] = bn.nanmean(time[mask])
            bstds[i] = bn.nanstd(flux[mask]) / (mask.sum() ** 0.5)
    zmask = (bflux == 0) | (btime == 0) | np.isnan(bflux) | np.isnan(btime)
    return btime[~zmask], bflux[~zmask], bstds[~zmask]


def _pointwise_plot_uncertainties(values, errors, residuals=None, reference=None):
    """Require a finite, positive uncertainty for every plotted measurement.

    The legacy residual/reference arguments are accepted for compatibility only;
    residual scatter must never substitute for a measurement uncertainty.
    """
    values = np.asarray(values, dtype=float).reshape(-1)
    try:
        errors = np.asarray(errors, dtype=float).reshape(-1)
    except (TypeError, ValueError) as exc:
        raise ValueError("Cannot plot light curve: measurement uncertainties must be numeric.") from exc
    if errors.shape != values.shape:
        raise ValueError(
            f"Cannot plot light curve: {values.size} measurements but {errors.size} uncertainties; "
            "one finite, positive uncertainty is required per measurement."
        )
    invalid = ~np.isfinite(errors) | (errors <= 0)
    if np.any(invalid):
        raise ValueError(
            f"Cannot plot light curve: {np.count_nonzero(invalid)} measurement uncertainties "
            "are missing, non-finite, or non-positive; no scatter fallback is allowed."
        )
    return errors


# Function that bins an array
def binner(arr, n, err=''):
    if len(err) == 0:
        ecks = np.pad(arr.astype(float), (0, ((n - arr.size % n) % n)), mode='constant',
                      constant_values=np.nan).reshape(-1, n)
        arr = bn.nanmean(ecks, axis=1)
        return arr
    else:
        ecks = np.pad(arr.astype(float), (0, ((n - arr.size % n) % n)), mode='constant',
                      constant_values=np.nan).reshape(-1, n)
        why = np.pad(err.astype(float), (0, ((n - err.size % n) % n)), mode='constant', constant_values=np.nan).reshape(
            -1, n)
        weights = 1. / (why ** 2.)
        # Calculate the weighted average
        arr = bn.nansum(ecks * weights, axis=1) / bn.nansum(weights, axis=1)
        err = np.array([np.sqrt(1. / bn.nansum(1. / (np.array(i) ** 2.))) for i in why])
        return arr, err


def normalize_exposure_times_seconds_to_days(exposure_times_seconds, reference_shape):
    if exposure_times_seconds is None:
        return None
    try:
        exposure_times_seconds = np.asarray(exposure_times_seconds, dtype=float)
    except (TypeError, ValueError):
        return None

    if exposure_times_seconds.shape == ():
        exposure_times_seconds = np.full(reference_shape, float(exposure_times_seconds), dtype=float)
    elif exposure_times_seconds.shape != reference_shape:
        return None
    else:
        exposure_times_seconds = np.array(exposure_times_seconds, dtype=float, copy=True)

    valid = np.isfinite(exposure_times_seconds) & (exposure_times_seconds > MIN_EXPOSURE_SMEARING_SECONDS)
    if not np.any(valid):
        return None

    exposure_times_seconds[~valid] = 0.0
    return exposure_times_seconds / 86400.0


_STANDARD_TRANSIT_MODEL = transit


class lc_fitter(object):

    def __init__(
        self,
        time,
        data,
        dataerr,
        airmass,
        prior,
        bounds,
        neighbors=200,
        mode='ns',
        jd_times=None,
        verbose=True,
        use_impactparameter_rather_than_inclination_to_fit=True,
        duration_prior=None,
        keep_ultranest_sampler=False,
        baseline_fit_mask=None,
        fixed_parameter_errors=None,
        fixed_flux_baseline=False,
        ultranest_min_num_live_points=None,
        exposure_times_seconds=None,
        exposure_smearing_supersample=DEFAULT_EXPOSURE_SMEARING_SUPERSAMPLE,
        exposure_smearing_change_tolerance=DEFAULT_EXPOSURE_SMEARING_CHANGE_TOLERANCE,
        ultranest_warmstart_source=None,
        likelihood_backend='auto',
    ):
        self.time = time
        self.data = data
        self.dataerr = dataerr
        self.airmass = airmass
        self.airmass_reference = get_airmass_reference(airmass)
        # Optimizers update their working parameters on every evaluation. Keep
        # those trial values out of the caller's published starting priors.
        self.prior = copy.deepcopy(prior)
        self.bounds = bounds
        self.max_ncalls = 2e5
        self.verbose = verbose
        self.jd_times = jd_times
        self.mode = mode
        self.likelihood_backend_requested = likelihood_backend
        self.likelihood_backend = None
        self.neighbors = neighbors
        self.use_impactparameter_rather_than_inclination_to_fit = use_impactparameter_rather_than_inclination_to_fit
        self.duration_prior = copy.deepcopy(duration_prior) if isinstance(duration_prior, dict) else None
        self.keep_ultranest_sampler = bool(keep_ultranest_sampler)
        self.baseline_fit_mask = self._coerce_baseline_fit_mask(baseline_fit_mask)
        self.fixed_parameter_errors = (
            copy.deepcopy(fixed_parameter_errors)
            if isinstance(fixed_parameter_errors, dict)
            else {}
        )
        self.fixed_flux_baseline = bool(fixed_flux_baseline)
        self.ultranest_min_num_live_points = ultranest_min_num_live_points
        self.ultranest_warmstart_source = ultranest_warmstart_source
        self.ultranest_expanded_prior_warmstart_attempted = False
        self.ultranest_expanded_prior_warmstart_applied = False
        self.ultranest_expanded_prior_warmstart_note = None
        self.ultranest_expanded_prior_warmstart_source_sample_count = 0
        self.ultranest_expanded_prior_warmstart_effective_sample_size = 0.0
        self.ultranest_expanded_prior_warmstart_expanded_keys = []
        self.ultranest_expanded_prior_warmstart_full_prior_fraction = (
            ULTRANEST_EXPANDED_PRIOR_WARMSTART_FULL_PRIOR_FRACTION
        )
        self.exposure_times_days = normalize_exposure_times_seconds_to_days(
            exposure_times_seconds,
            np.asarray(time).shape,
        )
        self.exposure_smearing_supersample = _exposure_smearing_supersample({
            EXPOSURE_SMEARING_SUPERSAMPLE_KEY: exposure_smearing_supersample,
        })
        self.exposure_smearing_change_tolerance = _exposure_smearing_change_tolerance({
            EXPOSURE_SMEARING_CHANGE_TOLERANCE_KEY: exposure_smearing_change_tolerance,
        })
        self.exposure_smearing_available = self.exposure_times_days is not None
        if self.exposure_smearing_available:
            finite_exposures = self.exposure_times_days[
                np.isfinite(self.exposure_times_days) & (self.exposure_times_days > 0)
            ]
            self.exposure_smearing_median_seconds = (
                float(np.nanmedian(finite_exposures) * 86400.0)
                if finite_exposures.size
                else np.nan
            )
        else:
            self.exposure_smearing_median_seconds = np.nan
        self._ultranest_resume_context = None
        self.results = None
        self.sampled_keys = list(bounds.keys())
        self.sample_bounds = copy.deepcopy(bounds)
        self.impact_parameter_sampled_directly = False
        self.sample_parameters = {}
        self.sample_errors = {}
        self.sample_quantiles = {}
        self.nested_fit_fallback = False
        self.nested_fit_failure_reason = None
        if self.mode == "lm":
            self.fit_LM()
        elif self.mode == "ns":
            self.fit_nested()

    def _validate_flux_baseline_keys(self):
        free_flux_keys = [key for key in self.bounds if key in ('a0', 'a1')]
        if len(free_flux_keys) > 1:
            raise ValueError("Use only one of 'a0' or 'a1' as a free baseline parameter.")

    def _has_free_flux_baseline(self):
        return has_explicit_flux_baseline(getattr(self, 'bounds', {}))

    def _uses_fixed_flux_baseline(self):
        return bool(getattr(self, 'fixed_flux_baseline', False))

    def _uses_analytic_flux_baseline(self):
        return (
            np.ndim(getattr(self, 'airmass', np.array([]))) != 2
            and not self._has_free_flux_baseline()
            and not self._uses_fixed_flux_baseline()
            and hasattr(self, 'time')
            and hasattr(self, 'data')
            and hasattr(self, 'dataerr')
        )

    def _set_flux_baseline(self, value, error=0.0):
        self.parameters['a0'] = value
        self.errors['a0'] = error
        self.parameters['a1'] = value
        self.errors['a1'] = error

    def _values_with_analytic_flux_baseline(self, values):
        values = copy.deepcopy(values)
        if not self._uses_analytic_flux_baseline():
            return values

        try:
            model = self._transit_model(self.time, values)
            model = np.asarray(model, dtype=float) * airmass_trend(
                values.get('a2', 0),
                self.airmass,
                reference=self._get_airmass_reference(),
            )
            flux_scale = solve_flux_baseline(
                model,
                self.data,
                self.dataerr,
                mask=self._get_baseline_fit_mask(),
            )
        except Exception:
            return values

        values['a0'] = flux_scale
        values['a1'] = flux_scale
        return values

    def _coerce_baseline_fit_mask(self, baseline_fit_mask):
        fit_mask = normalized_optional_fit_mask(baseline_fit_mask, np.asarray(self.time).shape)
        if fit_mask is None:
            return None
        return fit_mask

    def _get_baseline_fit_mask(self):
        return getattr(self, 'baseline_fit_mask', None)

    def _apply_fixed_parameter_errors(self):
        fixed_errors = getattr(self, 'fixed_parameter_errors', None)
        if not isinstance(fixed_errors, dict):
            return
        if not hasattr(self, 'parameters') or not isinstance(self.parameters, dict):
            return
        if not hasattr(self, 'errors') or not isinstance(self.errors, dict):
            self.errors = {}
        if not hasattr(self, 'quantiles') or not isinstance(self.quantiles, dict):
            self.quantiles = {}

        for key, error in fixed_errors.items():
            if key not in self.parameters or key in self.errors:
                continue
            try:
                error = float(error)
            except (TypeError, ValueError):
                continue
            if not np.isfinite(error) or error < 0:
                continue
            self.errors[key] = error
            self.quantiles[key] = [-error, error]

    def _get_airmass_reference(self):
        if hasattr(self, 'airmass_reference'):
            return self.airmass_reference
        return get_airmass_reference(self.airmass)

    def _get_plot_time_range(self):
        plot_time_range = normalize_time_range(getattr(self, 'plot_time_range', None))
        if plot_time_range is not None:
            return plot_time_range
        return normalize_time_range(self.time)

    def _exposure_times_for_model_times(self, times):
        exposure_times_days = getattr(self, 'exposure_times_days', None)
        if exposure_times_days is None:
            return None

        times = np.asarray(times, dtype=float)
        source_times = np.asarray(self.time, dtype=float)
        if (
            times.shape == source_times.shape
            and exposure_times_days.shape == source_times.shape
            and np.allclose(times, source_times, rtol=0.0, atol=0.0)
        ):
            return exposure_times_days

        finite_exposures = exposure_times_days[
            np.isfinite(exposure_times_days) & (exposure_times_days > 0)
        ]
        if finite_exposures.size == 0:
            return None
        return float(np.nanmedian(finite_exposures))

    def _values_with_exposure_smearing(self, values, times):
        exposure_times_days = self._exposure_times_for_model_times(times)
        if exposure_times_days is None:
            return values

        smeared_values = copy.deepcopy(values)
        smeared_values[EXPOSURE_SMEARING_EXPOSURE_TIME_KEY] = exposure_times_days
        smeared_values[EXPOSURE_SMEARING_SUPERSAMPLE_KEY] = self.exposure_smearing_supersample
        smeared_values[EXPOSURE_SMEARING_CHANGE_TOLERANCE_KEY] = self.exposure_smearing_change_tolerance
        return smeared_values

    def _transit_model(self, times, values):
        return transit(times, self._values_with_exposure_smearing(values, times))

    _native_likelihood_transit_model = _transit_model

    def _select_likelihood_backend(self):
        requested = self.likelihood_backend_requested
        if requested not in ('auto', 'cpp', 'python'):
            raise ValueError(f'Unknown likelihood backend: {requested!r}')
        law = self.prior.get('_limb_darkening_law', 'claret')
        native_model = (
            (law == 'claret' and self.prior.get('_claret_backend', 'cpp') == 'cpp')
            or (law == 'hybrid4' and self.prior.get('_hybrid4_backend', 'numpy') == 'cpp')
        )
        standard_model = (
            transit is _STANDARD_TRANSIT_MODEL
            and getattr(self._transit_model, '__func__', None)
            is self._native_likelihood_transit_model.__func__
        )
        shape = np.asarray(self.time).shape
        native_arrays = len(shape) == 1 and all(
            np.asarray(value).shape == shape for value in (self.data, self.dataerr, self.airmass)
        )
        supported = native_model and standard_model and native_arrays
        if requested == 'cpp' and not supported:
            raise ValueError('C++ likelihood requires the standard native transit model and matching 1D fit arrays.')
        return 'cpp' if supported and requested != 'python' else 'python'

    def _update_plot_geometry(self):
        plot_time_range = self._get_plot_time_range()
        self.phase = get_plot_phase(self.time, self.parameters['per'], self.parameters['tmid'], plot_time_range)

        if plot_time_range is None:
            self.time_upsample = np.linspace(min(self.time), max(self.time), 1000)
        else:
            self.time_upsample = np.linspace(plot_time_range[0], plot_time_range[1], 1000)

        self.transit_upsample = self._transit_model(self.time_upsample, self.parameters)
        self.phase_upsample = get_plot_phase(
            self.time_upsample,
            self.parameters['per'],
            self.parameters['tmid'],
            plot_time_range,
        )

    def _build_systematics_model(self, values):
        return get_flux_baseline(values) * airmass_trend(
            values.get('a2', 0),
            self.airmass,
            reference=self._get_airmass_reference(),
        )

    def _build_systematics_model_at(self, values, times=None):
        if times is None:
            return self._build_systematics_model(values)

        times = np.asarray(times, dtype=float)
        if np.ndim(self.airmass) == 2:
            return np.full(times.shape, get_flux_baseline(values), dtype=float)

        source_times = np.asarray(self.time, dtype=float)
        source_airmass = np.asarray(self.airmass, dtype=float)
        finite = np.isfinite(source_times) & np.isfinite(source_airmass)
        if times.shape == source_times.shape and np.allclose(times, source_times, rtol=0.0, atol=0.0):
            airmass_values = source_airmass
        elif np.count_nonzero(finite) >= 2:
            order = np.argsort(source_times[finite])
            airmass_values = np.interp(
                times,
                source_times[finite][order],
                source_airmass[finite][order],
                left=source_airmass[finite][order][0],
                right=source_airmass[finite][order][-1],
            )
        elif np.count_nonzero(finite) == 1:
            airmass_values = np.full(times.shape, source_airmass[finite][0], dtype=float)
        else:
            airmass_values = np.zeros(times.shape, dtype=float)

        return get_flux_baseline(values) * airmass_trend(
            values.get('a2', 0),
            airmass_values,
            reference=self._get_airmass_reference(),
        )

    def _get_perturbed_transit_parameter_value(self, key, value):
        try:
            value = float(value)
        except (TypeError, ValueError):
            return np.nan

        if key in ('rprs', 'ars', 'per', 'a0', 'a1'):
            return max(value, np.finfo(float).eps)
        if key == 'ecc':
            return float(np.clip(value, 0.0, 0.999999))
        if key == 'inc':
            return float(np.clip(value, 0.0, 180.0))
        return value

    def _normalized_model_for_plot_times(self, times, values):
        values = self._values_with_analytic_flux_baseline(values)
        model = np.asarray(self._transit_model(times, values), dtype=float)
        if np.ndim(self.airmass) == 2:
            return model

        try:
            sample_systematics = self._build_systematics_model_at(values, times)
            best_systematics = self._build_systematics_model_at(self.parameters, times)
        except Exception:
            return model

        with np.errstate(divide='ignore', invalid='ignore'):
            normalized_model = model * sample_systematics / best_systematics
        if normalized_model.shape != model.shape or not np.any(np.isfinite(normalized_model)):
            return model
        return normalized_model

    def _posterior_model_uncertainty(self, times, sigma=1.0):
        if getattr(self, 'results', None) is None:
            return None

        try:
            sample_points, sample_logl, sample_weights = self._get_triangle_plot_samples()
        except Exception:
            return None

        sample_points = np.asarray(sample_points, dtype=float)
        if sample_points.ndim != 2 or sample_points.shape[0] < 2:
            return None

        finite_rows = np.all(np.isfinite(sample_points), axis=1)
        if sample_logl is not None:
            sample_logl = np.asarray(sample_logl, dtype=float)
            if sample_logl.shape[0] == sample_points.shape[0]:
                finite_rows &= np.isfinite(sample_logl)

        if np.count_nonzero(finite_rows) < 2:
            return None

        row_indices = np.flatnonzero(finite_rows)
        if row_indices.size > MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT:
            if sample_weights is not None:
                weights_array = np.asarray(sample_weights, dtype=float)
                if weights_array.shape[0] == sample_points.shape[0]:
                    row_weights = np.where(np.isfinite(weights_array[row_indices]), weights_array[row_indices], 0.0)
                    order = np.argsort(row_weights)[-MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT:]
                    row_indices = row_indices[np.sort(order)]
                else:
                    row_indices = row_indices[
                        np.linspace(0, row_indices.size - 1, MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT).astype(int)
                    ]
            else:
                row_indices = row_indices[
                    np.linspace(0, row_indices.size - 1, MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT).astype(int)
                ]

        selected_points = sample_points[row_indices]
        selected_weights = None
        if sample_weights is not None:
            weights_array = np.asarray(sample_weights, dtype=float)
            if weights_array.shape[0] == sample_points.shape[0]:
                selected_weights = weights_array[row_indices]
                selected_weights = np.where(np.isfinite(selected_weights) & (selected_weights >= 0), selected_weights, 0.0)
                if np.sum(selected_weights) <= 0:
                    selected_weights = None

        bound_keys = list(self.bounds.keys())
        sampled_keys = getattr(self, 'sampled_keys', None)
        if sampled_keys is None:
            sampled_keys = self._get_sampled_keys(bound_keys)
        models = []
        for point in selected_points:
            try:
                values = copy.deepcopy(self.parameters)
                values.update(self._physical_values_from_sample_point(point, bound_keys, sampled_keys))
                model = self._normalized_model_for_plot_times(times, values)
            except Exception:
                continue
            if model.shape == times.shape and np.all(np.isfinite(model)):
                models.append(model)

        if len(models) < 2:
            return None

        model_grid = np.asarray(models, dtype=float)
        if selected_weights is not None and selected_weights.shape[0] != model_grid.shape[0]:
            selected_weights = None

        try:
            sigma = float(sigma)
        except (TypeError, ValueError):
            sigma = 1.0
        if not np.isfinite(sigma) or sigma <= 0:
            sigma = 1.0
        coverage = math.erf(sigma / np.sqrt(2.0))
        q_lower = 0.5 * (1.0 - coverage)
        q_upper = 1.0 - q_lower

        if selected_weights is None:
            lower, median, upper = np.nanpercentile(
                model_grid,
                [100.0 * q_lower, 50.0, 100.0 * q_upper],
                axis=0,
            )
        else:
            # Sort each posterior column once for all three quantiles.
            lower, median, upper = np.array([
                self._weighted_quantiles(
                    model_grid[:, i], [q_lower, 0.5, q_upper], weights=selected_weights,
                )
                for i in range(model_grid.shape[1])
            ]).T

        try:
            best_model = self._normalized_model_for_plot_times(times, self.parameters)
        except Exception:
            best_model = median

        lower_width = median - lower
        upper_width = upper - median
        lower = best_model - np.maximum(lower_width, 0.0)
        upper = best_model + np.maximum(upper_width, 0.0)

        finite = np.isfinite(lower) & np.isfinite(upper) & (lower <= upper)
        if not np.any(finite):
            return None
        return lower, upper

    def transit_model_uncertainty(self, times=None, sigma=1.0):
        if times is None:
            times = getattr(self, 'time_upsample', self.time)
        times = np.asarray(times, dtype=float)
        if times.size == 0:
            return None

        try:
            model = self._normalized_model_for_plot_times(times, self.parameters)
        except Exception:
            return None

        posterior_envelope = self._posterior_model_uncertainty(times, sigma=sigma)
        if posterior_envelope is not None:
            return posterior_envelope

        sigma = float(sigma)
        variance = np.zeros_like(model, dtype=float)
        uncertainty_keys = list(TRANSIT_MODEL_UNCERTAINTY_KEYS)
        for key in BASELINE_MODEL_UNCERTAINTY_KEYS:
            if key == 'a1' and 'a0' in self.parameters:
                continue
            uncertainty_keys.append(key)

        for key in uncertainty_keys:
            if key not in self.parameters:
                continue
            error = self.errors.get(key)
            try:
                center = float(self.parameters[key])
                error = float(error)
            except (TypeError, ValueError):
                continue
            if not np.isfinite(center) or not np.isfinite(error) or error <= 0:
                continue

            lower_value = self._get_perturbed_transit_parameter_value(key, center - error)
            upper_value = self._get_perturbed_transit_parameter_value(key, center + error)
            if (
                not np.isfinite(lower_value)
                or not np.isfinite(upper_value)
                or np.isclose(lower_value, upper_value)
            ):
                continue

            lower_parameters = copy.deepcopy(self.parameters)
            upper_parameters = copy.deepcopy(self.parameters)
            lower_parameters[key] = lower_value
            upper_parameters[key] = upper_value
            try:
                lower_model = self._normalized_model_for_plot_times(times, lower_parameters)
                upper_model = self._normalized_model_for_plot_times(times, upper_parameters)
            except Exception:
                continue

            derivative = (upper_model - lower_model) / (upper_value - lower_value)
            contribution = derivative * error * sigma
            finite = np.isfinite(contribution)
            variance[finite] += contribution[finite] ** 2

        model_uncertainty = np.sqrt(variance)
        if not np.any(np.isfinite(model_uncertainty) & (model_uncertainty > 0)):
            return None
        return model - model_uncertainty, model + model_uncertainty

    def _empirical_uncertainty_value(self, key):
        empirical_uncertainty = getattr(self, 'empirical_transit_uncertainty', None)
        if not isinstance(empirical_uncertainty, dict) or not empirical_uncertainty.get('available'):
            return np.nan
        try:
            value = float(empirical_uncertainty.get(key))
        except (TypeError, ValueError):
            return np.nan
        return value if np.isfinite(value) else np.nan

    def _empirical_baseline_uncertainty_fraction(self):
        value = self._empirical_uncertainty_value('baseline_red_noise_uncertainty_fraction')
        if not np.isfinite(value) or value <= 0:
            value = self._empirical_uncertainty_value('depth_uncertainty_fraction')
        return value if np.isfinite(value) and value > 0 else np.nan

    def _baseline_envelope_with_empirical_floor(self, envelope):
        if envelope is None:
            return None

        lower, upper = envelope
        lower = np.asarray(lower, dtype=float)
        upper = np.asarray(upper, dtype=float)
        empirical_baseline_uncertainty = self._empirical_baseline_uncertainty_fraction()
        if not np.isfinite(empirical_baseline_uncertainty) or empirical_baseline_uncertainty <= 0:
            return lower, upper

        existing_width = np.maximum(1.0 - lower, upper - 1.0)
        combined_width = np.sqrt(
            np.where(np.isfinite(existing_width), existing_width, 0.0) ** 2
            + empirical_baseline_uncertainty ** 2
        )
        return 1.0 - combined_width, 1.0 + combined_width

    def _combined_rprs_uncertainty_for_reporting(self):
        value = self._empirical_uncertainty_value('combined_rprs_uncertainty')
        if np.isfinite(value) and value >= 0:
            return value
        try:
            value = float(self.errors.get('rprs'))
        except (TypeError, ValueError):
            return np.nan
        return value if np.isfinite(value) and value >= 0 else np.nan

    def _model_data_uncertainty_for_reporting(self, parameter_name):
        try:
            value = float(self.errors.get(parameter_name))
        except (TypeError, ValueError):
            return np.nan
        if not np.isfinite(value) or value < 0:
            return np.nan

        beta = self._empirical_uncertainty_value('red_noise_beta_factor')
        if not np.isfinite(beta) or beta < 1.0:
            beta = 1.0
        return value * beta

    def _posterior_baseline_model_uncertainty(self, times, sigma=1.0):
        if getattr(self, 'results', None) is None or np.ndim(getattr(self, 'airmass', np.array([]))) == 2:
            return None

        try:
            sample_points, sample_logl, sample_weights = self._get_triangle_plot_samples()
        except Exception:
            return None

        sample_points = np.asarray(sample_points, dtype=float)
        if sample_points.ndim != 2 or sample_points.shape[0] < 2:
            return None

        finite_rows = np.all(np.isfinite(sample_points), axis=1)
        if sample_logl is not None:
            sample_logl = np.asarray(sample_logl, dtype=float)
            if sample_logl.shape[0] == sample_points.shape[0]:
                finite_rows &= np.isfinite(sample_logl)

        if np.count_nonzero(finite_rows) < 2:
            return None

        row_indices = np.flatnonzero(finite_rows)
        if row_indices.size > MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT:
            if sample_weights is not None:
                weights_array = np.asarray(sample_weights, dtype=float)
                if weights_array.shape[0] == sample_points.shape[0]:
                    row_weights = np.where(np.isfinite(weights_array[row_indices]), weights_array[row_indices], 0.0)
                    order = np.argsort(row_weights)[-MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT:]
                    row_indices = row_indices[np.sort(order)]
                else:
                    row_indices = row_indices[
                        np.linspace(0, row_indices.size - 1, MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT).astype(int)
                    ]
            else:
                row_indices = row_indices[
                    np.linspace(0, row_indices.size - 1, MODEL_UNCERTAINTY_POSTERIOR_SAMPLE_LIMIT).astype(int)
                ]

        selected_points = sample_points[row_indices]
        selected_weights = None
        if sample_weights is not None:
            weights_array = np.asarray(sample_weights, dtype=float)
            if weights_array.shape[0] == sample_points.shape[0]:
                selected_weights = weights_array[row_indices]
                selected_weights = np.where(
                    np.isfinite(selected_weights) & (selected_weights >= 0),
                    selected_weights,
                    0.0,
                )
                if np.sum(selected_weights) <= 0:
                    selected_weights = None

        try:
            best_parameters = self._values_with_analytic_flux_baseline(self.parameters)
            best_systematics = self._build_systematics_model_at(best_parameters, times)
        except Exception:
            return None

        best_systematics = np.asarray(best_systematics, dtype=float)
        if best_systematics.shape != times.shape or not np.all(np.isfinite(best_systematics)):
            return None

        bound_keys = list(getattr(self, 'bounds', {}).keys())
        sampled_keys = getattr(self, 'sampled_keys', None)
        if sampled_keys is None:
            sampled_keys = self._get_sampled_keys(bound_keys)

        ratios = []
        ratio_weights = []
        for index, point in enumerate(selected_points):
            try:
                values = copy.deepcopy(self.parameters)
                values.update(self._physical_values_from_sample_point(point, bound_keys, sampled_keys))
                values = self._values_with_analytic_flux_baseline(values)
                sample_systematics = self._build_systematics_model_at(values, times)
                with np.errstate(divide='ignore', invalid='ignore'):
                    ratio = np.asarray(sample_systematics, dtype=float) / best_systematics
            except Exception:
                continue
            if ratio.shape != times.shape or not np.all(np.isfinite(ratio)):
                continue
            ratios.append(ratio)
            if selected_weights is not None:
                ratio_weights.append(selected_weights[index])

        if len(ratios) < 2:
            return None

        ratio_grid = np.asarray(ratios, dtype=float)
        if selected_weights is not None:
            selected_weights = np.asarray(ratio_weights, dtype=float)
            if selected_weights.shape[0] != ratio_grid.shape[0] or np.sum(selected_weights) <= 0:
                selected_weights = None

        try:
            sigma = float(sigma)
        except (TypeError, ValueError):
            sigma = 1.0
        if not np.isfinite(sigma) or sigma <= 0:
            sigma = 1.0
        coverage = math.erf(sigma / np.sqrt(2.0))
        q_lower = 0.5 * (1.0 - coverage)
        q_upper = 1.0 - q_lower

        if selected_weights is None:
            lower, median, upper = np.nanpercentile(
                ratio_grid,
                [100.0 * q_lower, 50.0, 100.0 * q_upper],
                axis=0,
            )
        else:
            lower, median, upper = np.array([
                self._weighted_quantiles(
                    ratio_grid[:, i], [q_lower, 0.5, q_upper], weights=selected_weights,
                )
                for i in range(ratio_grid.shape[1])
            ]).T

        lower_width = median - lower
        upper_width = upper - median
        lower = 1.0 - np.maximum(lower_width, 0.0)
        upper = 1.0 + np.maximum(upper_width, 0.0)
        finite = np.isfinite(lower) & np.isfinite(upper) & (lower <= upper)
        if not np.any(finite):
            return None
        return lower, upper

    def baseline_model_uncertainty(self, times=None, sigma=1.0):
        if times is None:
            times = getattr(self, 'time_upsample', self.time)
        times = np.asarray(times, dtype=float)
        if times.size == 0 or np.ndim(getattr(self, 'airmass', np.array([]))) == 2:
            return None

        posterior_envelope = self._posterior_baseline_model_uncertainty(times, sigma=sigma)
        if posterior_envelope is not None:
            return self._baseline_envelope_with_empirical_floor(posterior_envelope)

        try:
            best_parameters = self._values_with_analytic_flux_baseline(self.parameters)
            best_systematics = self._build_systematics_model_at(best_parameters, times)
        except Exception:
            return None

        if (
            np.asarray(best_systematics).shape != times.shape
            or not np.any(np.isfinite(best_systematics))
        ):
            return None

        try:
            sigma = float(sigma)
        except (TypeError, ValueError):
            sigma = 1.0
        if not np.isfinite(sigma) or sigma <= 0:
            sigma = 1.0

        variance = np.zeros_like(times, dtype=float)
        uses_analytic_flux_baseline = self._uses_analytic_flux_baseline()
        a2_error = self.errors.get('a2')
        try:
            a2_error = float(a2_error)
        except (TypeError, ValueError):
            a2_error = 0.0
        for key in ('a0', 'a1', 'a2'):
            if key == 'a1' and 'a0' in self.parameters:
                continue
            if key in ('a0', 'a1') and uses_analytic_flux_baseline and a2_error > 0:
                continue
            if key not in self.parameters:
                continue
            error = self.errors.get(key)
            try:
                center = float(self.parameters[key])
                error = float(error)
            except (TypeError, ValueError):
                continue
            if not np.isfinite(center) or not np.isfinite(error) or error <= 0:
                continue

            lower_value = self._get_perturbed_transit_parameter_value(key, center - error)
            upper_value = self._get_perturbed_transit_parameter_value(key, center + error)
            if (
                not np.isfinite(lower_value)
                or not np.isfinite(upper_value)
                or np.isclose(lower_value, upper_value)
            ):
                continue

            lower_parameters = copy.deepcopy(self.parameters)
            upper_parameters = copy.deepcopy(self.parameters)
            lower_parameters[key] = lower_value
            upper_parameters[key] = upper_value
            lower_parameters = self._values_with_analytic_flux_baseline(lower_parameters)
            upper_parameters = self._values_with_analytic_flux_baseline(upper_parameters)
            try:
                lower_systematics = self._build_systematics_model_at(lower_parameters, times)
                upper_systematics = self._build_systematics_model_at(upper_parameters, times)
            except Exception:
                continue

            with np.errstate(divide='ignore', invalid='ignore'):
                lower_ratio = lower_systematics / best_systematics
                upper_ratio = upper_systematics / best_systematics
            derivative = (upper_ratio - lower_ratio) / (upper_value - lower_value)
            contribution = derivative * error * sigma
            finite = np.isfinite(contribution)
            variance[finite] += contribution[finite] ** 2

        baseline_uncertainty = np.sqrt(variance)
        if not np.any(np.isfinite(baseline_uncertainty) & (baseline_uncertainty > 0)):
            empirical_baseline_uncertainty = self._empirical_baseline_uncertainty_fraction()
            if not np.isfinite(empirical_baseline_uncertainty) or empirical_baseline_uncertainty <= 0:
                return None
        return self._baseline_envelope_with_empirical_floor(
            (1.0 - baseline_uncertainty, 1.0 + baseline_uncertainty)
        )

    def _plot_transit_model_uncertainty(
        self, ax, x_values, times, sort_index, label=None, uncertainty_evaluator=None,
    ):
        envelope = (
            self.transit_model_uncertainty(times) if uncertainty_evaluator is None
            else uncertainty_evaluator('transit_model_uncertainty', times)
        )
        if envelope is None:
            return None

        lower, upper = envelope
        x_values = np.asarray(x_values, dtype=float)
        sort_index = np.asarray(sort_index, dtype=int)
        x_sorted = x_values[sort_index]
        lower_sorted = np.asarray(lower, dtype=float)[sort_index]
        upper_sorted = np.asarray(upper, dtype=float)[sort_index]
        band = ax.fill_between(
            x_sorted,
            lower_sorted,
            upper_sorted,
            color='red',
            alpha=0.16,
            linewidth=0,
            zorder=2.5,
            label=label,
        )
        ax.plot(
            x_sorted,
            lower_sorted,
            color='red',
            linestyle='--',
            linewidth=0.9,
            alpha=0.72,
            zorder=3.4,
        )
        ax.plot(
            x_sorted,
            upper_sorted,
            color='red',
            linestyle='--',
            linewidth=0.9,
            alpha=0.72,
            zorder=3.4,
        )
        return band

    def _plot_baseline_model_uncertainty(
        self, ax, x_values, times, sort_index, label=None, uncertainty_evaluator=None,
    ):
        envelope = (
            self.baseline_model_uncertainty(times) if uncertainty_evaluator is None
            else uncertainty_evaluator('baseline_model_uncertainty', times)
        )
        if envelope is None:
            return None

        lower, upper = envelope
        x_values = np.asarray(x_values, dtype=float)
        sort_index = np.asarray(sort_index, dtype=int)
        x_sorted = x_values[sort_index]
        lower_sorted = np.asarray(lower, dtype=float)[sort_index]
        upper_sorted = np.asarray(upper, dtype=float)[sort_index]
        band = ax.fill_between(
            x_sorted,
            lower_sorted,
            upper_sorted,
            color='gold',
            alpha=0.32,
            linewidth=0,
            zorder=2.1,
            label=label,
        )
        ax.plot(
            x_sorted,
            lower_sorted,
            color='gold',
            linestyle='--',
            linewidth=0.9,
            alpha=0.78,
            zorder=3.2,
        )
        ax.plot(
            x_sorted,
            upper_sorted,
            color='gold',
            linestyle='--',
            linewidth=0.9,
            alpha=0.78,
            zorder=3.2,
        )
        return band

    def _uses_internal_impact_parameter(self):
        return (
            self.use_impactparameter_rather_than_inclination_to_fit
            and self.mode == "ns"
            and 'inc' in self.bounds
            and 'b' not in self.bounds
        )

    def _get_sampled_keys(self, bound_keys=None):
        bound_keys = list(self.bounds.keys()) if bound_keys is None else list(bound_keys)
        if not self._uses_internal_impact_parameter():
            return bound_keys
        return ['b' if key == 'inc' else key for key in bound_keys]

    def _get_impact_parameter_scale_upper_bound(self, values):
        values = dict(values)
        scale_keys = ('ars', 'ecc', 'omega')
        endpoint_sets = []
        for key in scale_keys:
            if key in self.bounds:
                endpoints = np.asarray(self.bounds[key], dtype=float).reshape(-1)[:2]
            else:
                endpoints = np.asarray([values.get(key, 0.0)], dtype=float)
            finite_endpoints = [float(value) for value in endpoints if np.isfinite(value)]
            if not finite_endpoints:
                return np.nan
            endpoint_sets.append((key, finite_endpoints))

        scales = []
        for candidate_values in product(*[endpoints for _, endpoints in endpoint_sets]):
            candidate = dict(values)
            for key, value in zip([key for key, _ in endpoint_sets], candidate_values):
                candidate[key] = value
            try:
                scale = float(impact_parameter_scale(candidate))
            except (KeyError, TypeError, ValueError):
                continue
            if np.isfinite(scale) and scale > 0:
                scales.append(scale)

        return float(max(scales)) if scales else np.nan

    def _get_impact_parameter_sampling_bounds(self, values=None, use_search_bounds=False):
        values = self.prior if values is None else values
        if use_search_bounds and 'rprs' in self.bounds:
            values = dict(values)
            rprs_bounds = np.asarray(self.bounds['rprs'], dtype=float).reshape(-1)[:2]
            finite_rprs = rprs_bounds[np.isfinite(rprs_bounds) & (rprs_bounds >= 0)]
            if finite_rprs.size > 0:
                values['rprs'] = float(np.max(finite_rprs))

        grazing_upper = grazing_impact_parameter(values)
        if use_search_bounds:
            scale_upper = self._get_impact_parameter_scale_upper_bound(values)
        else:
            try:
                scale_upper = float(impact_parameter_scale(values))
            except (KeyError, TypeError, ValueError):
                scale_upper = np.nan

        upper_candidates = [
            float(value)
            for value in (grazing_upper, scale_upper)
            if np.isfinite(value) and value > 0
        ]
        upper = min(upper_candidates) if upper_candidates else 1.0
        return [0.0, float(max(0.0, upper))]

    def _get_impact_parameter_upper_bounds_for_sample_points(self, sample_points, bound_keys):
        sample_points = np.atleast_2d(np.asarray(sample_points, dtype=float))
        bound_index = {key: index for index, key in enumerate(bound_keys)}
        sample_count = sample_points.shape[0]

        def values_for(key, default):
            if key in bound_index:
                return sample_points[:, bound_index[key]]
            value = np.asarray(self.prior.get(key, default), dtype=float)
            if value.shape == ():
                return np.full(sample_count, float(value), dtype=float)
            return np.broadcast_to(value, (sample_count,)).astype(float)

        rprs = values_for('rprs', np.nan)
        grazing_upper = np.where(np.isfinite(rprs) & (rprs >= 0), 1.0 + rprs, np.nan)

        ars = values_for('ars', np.nan)
        ecc = values_for('ecc', 0.0)
        omega = np.deg2rad(values_for('omega', 0.0))
        denom = 1.0 + ecc * np.sin(omega)
        denom = np.where(np.isclose(denom, 0.0), np.finfo(float).eps, denom)
        scale_upper = ars * (1.0 - ecc ** 2) / denom

        valid_grazing = np.isfinite(grazing_upper) & (grazing_upper > 0)
        valid_scale = np.isfinite(scale_upper) & (scale_upper > 0)
        upper = np.full(sample_count, 1.0, dtype=float)

        both_valid = valid_grazing & valid_scale
        upper[both_valid] = np.minimum(grazing_upper[both_valid], scale_upper[both_valid])

        grazing_only = valid_grazing & ~valid_scale
        upper[grazing_only] = grazing_upper[grazing_only]

        scale_only = valid_scale & ~valid_grazing
        upper[scale_only] = scale_upper[scale_only]

        return np.maximum(0.0, upper)

    def _get_sample_bounds(self, bound_keys=None, values=None):
        bound_keys = list(self.bounds.keys()) if bound_keys is None else list(bound_keys)
        sampled_keys = self._get_sampled_keys(bound_keys)
        values = self.prior if values is None else values
        sample_bounds = {}
        for key, sampled_key in zip(bound_keys, sampled_keys):
            if key == 'inc' and sampled_key == 'b':
                sample_bounds[sampled_key] = self._get_impact_parameter_sampling_bounds(
                    values,
                    use_search_bounds=True,
                )
            else:
                sample_bounds[sampled_key] = list(self.bounds[key])
        return sample_bounds

    def _sample_point_from_unit_cube(self, upars, bound_keys=None):
        bound_keys = list(self.bounds.keys()) if bound_keys is None else list(bound_keys)
        upars_array = np.asarray(upars, dtype=float)
        boundarray = np.array([self.bounds[k] for k in bound_keys], dtype=float)
        lower_bounds = boundarray[:, 0]
        bound_widths = boundarray[:, 1] - lower_bounds
        uses_internal_impact_parameter = self._uses_internal_impact_parameter()
        inc_indices = [i for i, key in enumerate(bound_keys) if key == 'inc']

        sample_point = lower_bounds + bound_widths * upars_array
        if not uses_internal_impact_parameter or not inc_indices:
            return sample_point

        if len(inc_indices) == 1:
            inc_index = inc_indices[0]
            if upars_array.ndim == 2:
                upper_bounds = self._get_impact_parameter_upper_bounds_for_sample_points(
                    sample_point,
                    bound_keys,
                )
                sample_point[:, inc_index] = upper_bounds * upars_array[:, inc_index]
                return sample_point

            upper_bound = self._get_impact_parameter_upper_bounds_for_sample_points(
                sample_point.reshape(1, -1),
                bound_keys,
            )[0]
            sample_point[inc_index] = upper_bound * upars_array[inc_index]
            return sample_point

        if upars_array.ndim == 2:
            for row_index, row_sample_point in enumerate(sample_point):
                physical = dict(self.prior)
                for i, key in enumerate(bound_keys):
                    if i not in inc_indices:
                        physical[key] = row_sample_point[i]
                for i in inc_indices:
                    b_lower, b_upper = self._get_impact_parameter_sampling_bounds(physical)
                    row_sample_point[i] = b_lower + (b_upper - b_lower) * upars_array[row_index, i]
            return sample_point

        physical = dict(self.prior)
        for i, key in enumerate(bound_keys):
            if i not in inc_indices:
                physical[key] = sample_point[i]
        for i in inc_indices:
            b_lower, b_upper = self._get_impact_parameter_sampling_bounds(physical)
            sample_point[i] = b_lower + (b_upper - b_lower) * upars_array[i]

        return sample_point

    def _unit_cube_from_sample_points(self, sample_points, bound_keys=None):
        bound_keys = list(self.bounds.keys()) if bound_keys is None else list(bound_keys)
        points = np.asarray(sample_points, dtype=float)
        scalar_input = points.ndim == 1
        points_2d = np.atleast_2d(points)
        if points_2d.shape[1] != len(bound_keys):
            raise ValueError(
                "Sample-point dimensionality does not match the expanded-prior bounds."
            )

        boundarray = np.array([self.bounds[key] for key in bound_keys], dtype=float)
        widths = boundarray[:, 1] - boundarray[:, 0]
        if (
            not np.all(np.isfinite(boundarray))
            or not np.all(np.isfinite(widths))
            or np.any(widths <= 0)
        ):
            raise ValueError("Expanded-prior bounds are not finite and increasing.")

        unit_points = (points_2d - boundarray[:, 0]) / widths
        if self._uses_internal_impact_parameter() and 'inc' in bound_keys:
            inc_index = bound_keys.index('inc')
            upper_bounds = self._get_impact_parameter_upper_bounds_for_sample_points(
                points_2d,
                bound_keys,
            )
            valid_upper = np.isfinite(upper_bounds) & (upper_bounds > 0)
            if not np.all(valid_upper):
                raise ValueError(
                    "Impact-parameter upper bounds are invalid for warm-start samples."
                )
            unit_points[:, inc_index] = points_2d[:, inc_index] / upper_bounds

        return unit_points[0] if scalar_input else unit_points

    @staticmethod
    def _warmstart_values_match(left, right):
        if left is None or right is None:
            return left is None and right is None
        if isinstance(left, dict) or isinstance(right, dict):
            if not isinstance(left, dict) or not isinstance(right, dict):
                return False
            if set(left) != set(right):
                return False
            return all(
                lc_fitter._warmstart_values_match(left[key], right[key])
                for key in left
            )
        try:
            left_array = np.asarray(left)
            right_array = np.asarray(right)
            if left_array.shape != right_array.shape:
                return False
            if (
                np.issubdtype(left_array.dtype, np.number)
                and np.issubdtype(right_array.dtype, np.number)
            ):
                return bool(np.array_equal(
                    left_array.astype(float),
                    right_array.astype(float),
                    equal_nan=True,
                ))
            return bool(np.array_equal(left_array, right_array))
        except (TypeError, ValueError):
            return left == right

    def _expanded_prior_warmstart_compatibility(self, source, bound_keys, sampled_keys):
        if source is None:
            return None, "No previous UltraNest fit was supplied."
        if getattr(source, 'ns_type', None) != 'ultranest':
            return None, "The previous fit is not an UltraNest result."

        source_bound_keys = list(getattr(source, 'bounds', {}).keys())
        source_sampled_keys = list(getattr(source, 'sampled_keys', []))
        if source_bound_keys != list(bound_keys) or source_sampled_keys != list(sampled_keys):
            return None, "The sampled parameterization changed between UltraNest fits."

        expanded_keys = []
        tolerance = 1e-12
        for key in bound_keys:
            try:
                source_lower, source_upper = [
                    float(value)
                    for value in np.asarray(source.bounds[key], dtype=float).reshape(-1)[:2]
                ]
                target_lower, target_upper = [
                    float(value)
                    for value in np.asarray(self.bounds[key], dtype=float).reshape(-1)[:2]
                ]
            except (KeyError, TypeError, ValueError):
                return None, f"The {key} bounds are unavailable for warm-start validation."
            if (
                target_lower > source_lower + tolerance
                or target_upper < source_upper - tolerance
            ):
                return None, f"The {key} bounds contracted instead of forming a true superset."
            if (
                target_lower < source_lower - tolerance
                or target_upper > source_upper + tolerance
            ):
                expanded_keys.append(key)

        if not expanded_keys:
            return None, "The prior bounds did not expand."

        likelihood_attributes = (
            'time',
            'data',
            'dataerr',
            'airmass',
            'exposure_times_days',
            'baseline_fit_mask',
            'duration_prior',
            'fixed_flux_baseline',
            'use_impactparameter_rather_than_inclination_to_fit',
        )
        for attribute_name in likelihood_attributes:
            if not self._warmstart_values_match(
                getattr(source, attribute_name, None),
                getattr(self, attribute_name, None),
            ):
                return None, (
                    f"The likelihood input {attribute_name} changed between UltraNest fits."
                )

        free_keys = set(bound_keys)
        source_prior = getattr(source, 'prior', {})
        if not isinstance(source_prior, dict) or not isinstance(self.prior, dict):
            return None, "The fixed model parameters are unavailable for warm-start validation."
        fixed_keys = (set(source_prior) | set(self.prior)) - free_keys
        for key in fixed_keys:
            if not self._warmstart_values_match(
                source_prior.get(key),
                self.prior.get(key),
            ):
                return None, f"The fixed model parameter {key} changed between UltraNest fits."

        try:
            weighted_samples = source.results['weighted_samples']
            source_points = np.asarray(weighted_samples['points'], dtype=float)
            source_weights = np.asarray(weighted_samples['weights'], dtype=float)
        except (AttributeError, KeyError, TypeError, ValueError):
            return None, "The previous weighted posterior samples are unavailable."

        parameter_count = len(sampled_keys)
        if (
            source_points.ndim != 2
            or source_points.shape[1] < parameter_count
            or source_weights.ndim != 1
            or source_weights.shape[0] != source_points.shape[0]
        ):
            return None, "The previous weighted posterior sample arrays are malformed."

        source_points = source_points[:, :parameter_count]
        valid = (
            np.all(np.isfinite(source_points), axis=1)
            & np.isfinite(source_weights)
            & (source_weights > 0)
        )
        source_points = source_points[valid]
        source_weights = source_weights[valid]
        minimum_count = max(
            ULTRANEST_EXPANDED_PRIOR_WARMSTART_MINIMUM_SAMPLE_COUNT,
            4 * max(1, parameter_count),
        )
        if source_points.shape[0] < minimum_count:
            return None, (
                f"Only {source_points.shape[0]} valid previous posterior samples are available; "
                f"at least {minimum_count} are required."
            )

        weight_sum = float(np.sum(source_weights))
        if not np.isfinite(weight_sum) or weight_sum <= 0:
            return None, "The previous posterior sample weights are invalid."
        source_weights = source_weights / weight_sum
        effective_sample_size = float(1.0 / np.sum(source_weights ** 2))
        minimum_effective_count = max(16, 2 * max(1, parameter_count))
        if not np.isfinite(effective_sample_size) or effective_sample_size < minimum_effective_count:
            return None, (
                f"The previous posterior effective sample size is only "
                f"{effective_sample_size:.1f}; at least {minimum_effective_count} is required."
            )

        return {
            'expanded_keys': expanded_keys,
            'points': source_points,
            'weights': source_weights,
            'effective_sample_size': effective_sample_size,
        }, None

    @staticmethod
    def _bounded_warmstart_posterior_sample(points, weights, maximum_count):
        if points.shape[0] <= maximum_count:
            return points, weights

        cumulative = np.cumsum(weights)
        cumulative[-1] = 1.0
        quantiles = (np.arange(maximum_count, dtype=float) + 0.5) / maximum_count
        selected = np.searchsorted(cumulative, quantiles, side='left')
        selected = np.clip(selected, 0, points.shape[0] - 1)
        return points[selected], np.full(maximum_count, 1.0 / maximum_count)

    def _build_expanded_prior_warmstart_problem(
        self,
        bound_keys,
        sampled_keys,
        loglike,
        prior_transform,
    ):
        source = getattr(self, 'ultranest_warmstart_source', None)
        compatibility, reason = self._expanded_prior_warmstart_compatibility(
            source,
            bound_keys,
            sampled_keys,
        )
        if compatibility is None:
            return None, reason

        points, weights = self._bounded_warmstart_posterior_sample(
            compatibility['points'],
            compatibility['weights'],
            ULTRANEST_EXPANDED_PRIOR_WARMSTART_MAXIMUM_SAMPLE_COUNT,
        )
        unit_points = np.asarray(
            self._unit_cube_from_sample_points(points, bound_keys),
            dtype=float,
        )
        tolerance = 1e-10
        inside = (
            np.all(np.isfinite(unit_points), axis=1)
            & np.all(unit_points >= -tolerance, axis=1)
            & np.all(unit_points <= 1.0 + tolerance, axis=1)
        )
        unit_points = unit_points[inside]
        weights = weights[inside]
        if unit_points.shape[0] < ULTRANEST_EXPANDED_PRIOR_WARMSTART_MINIMUM_SAMPLE_COUNT:
            return None, (
                "Too few previous posterior samples remain inside the expanded prior."
            )

        weights = weights / np.sum(weights)
        unit_points = np.clip(unit_points, 1e-12, 1.0 - 1e-12)
        full_prior_fraction = float(np.clip(
            ULTRANEST_EXPANDED_PRIOR_WARMSTART_FULL_PRIOR_FRACTION,
            1e-6,
            1.0 - 1e-6,
        ))
        parameter_count = len(sampled_keys)
        weighted_mean = np.sum(unit_points * weights[:, None], axis=0)
        weighted_variance = np.sum(
            weights[:, None] * (unit_points - weighted_mean) ** 2,
            axis=0,
        )
        # A modest scale floor avoids a singular hot proposal when the old
        # posterior is extremely narrow. The 50% uniform component below is
        # the stronger defense and guarantees full expanded-prior support.
        hot_scale = np.clip(np.sqrt(np.maximum(weighted_variance, 0.0)), 0.02, 0.5)
        hot_mean = np.clip(weighted_mean, 1e-8, 1.0 - 1e-8)
        hot_alpha = -hot_mean / hot_scale
        hot_beta = (1.0 - hot_mean) / hot_scale
        hot_cdf_lower = ndtr(hot_alpha)
        hot_cdf_width = np.maximum(
            ndtr(hot_beta) - hot_cdf_lower,
            np.finfo(float).tiny,
        )
        log_hot_normalization = np.log(hot_cdf_width)
        log_two_pi_half = 0.5 * np.log(2.0 * np.pi)
        log_full_fraction = np.log(full_prior_fraction)
        log_hot_fraction = np.log1p(-full_prior_fraction)

        def hot_transform(unit_values):
            probabilities = hot_cdf_lower + unit_values * hot_cdf_width
            probabilities = np.clip(
                probabilities,
                np.finfo(float).eps,
                1.0 - np.finfo(float).eps,
            )
            return np.clip(
                hot_mean + hot_scale * ndtri(probabilities),
                0.0,
                1.0,
            )

        def hot_log_density(unit_values):
            standardized = (unit_values - hot_mean) / hot_scale
            return np.sum(
                -0.5 * standardized ** 2
                - np.log(hot_scale)
                - log_two_pi_half
                - log_hot_normalization,
                axis=1,
            )

        # Defensive importance proposal:
        #
        #   q_mix(u) = f * Uniform(u) + (1-f) * q_hot(u)
        #
        # The latent selector samples one of those components, while every
        # point receives the common correction pi(u)/q_mix(u). Unlike using a
        # branch-specific correction, this remains evidence-correct even if
        # nested sampling prunes the component that contributes negligibly in
        # a particular likelihood region. Half of all proposal mass still
        # comes directly from the complete expanded prior.
        def defensive_transform(unit_values):
            values = np.asarray(unit_values, dtype=float)
            scalar_input = values.ndim == 1
            values_2d = np.atleast_2d(values)
            if values_2d.shape[1] != parameter_count + 1:
                raise ValueError(
                    "Expanded-prior warm-start unit points have the wrong dimensionality."
                )

            proposal_unit = np.empty(
                (values_2d.shape[0], parameter_count),
                dtype=float,
            )
            full_prior_mask = values_2d[:, -1] < full_prior_fraction
            proposal_unit[full_prior_mask] = values_2d[
                full_prior_mask, :parameter_count
            ]
            hot_mask = ~full_prior_mask
            if np.any(hot_mask):
                proposal_unit[hot_mask] = hot_transform(
                    values_2d[hot_mask, :parameter_count]
                )

            log_q_hot = hot_log_density(proposal_unit)
            log_q_mix = np.logaddexp(
                log_full_fraction,
                log_hot_fraction + log_q_hot,
            )
            transformed = np.empty(
                (values_2d.shape[0], parameter_count + 1),
                dtype=float,
            )
            transformed[:, :parameter_count] = prior_transform(proposal_unit)
            transformed[:, -1] = -log_q_mix

            return transformed[0] if scalar_input else transformed

        def defensive_loglike(parameters):
            values = np.asarray(parameters, dtype=float)
            physical = values[..., :parameter_count]
            correction = values[..., parameter_count]
            return loglike(physical) + correction

        self.ultranest_expanded_prior_warmstart_source_sample_count = int(
            unit_points.shape[0]
        )
        self.ultranest_expanded_prior_warmstart_effective_sample_size = float(
            compatibility['effective_sample_size']
        )
        self.ultranest_expanded_prior_warmstart_expanded_keys = list(
            compatibility['expanded_keys']
        )
        return {
            'param_names': list(sampled_keys) + ['aux_logweight'],
            'loglike': defensive_loglike,
            'transform': defensive_transform,
            'vectorized': True,
            'full_prior_fraction': full_prior_fraction,
        }, None

    @staticmethod
    def _expanded_prior_warmstart_result_is_usable(results, parameter_count):
        try:
            maximum_likelihood = np.asarray(
                results['maximum_likelihood']['point'],
                dtype=float,
            )
            weighted_points = np.asarray(
                results['weighted_samples']['points'],
                dtype=float,
            )
            weighted_logl = np.asarray(
                results['weighted_samples']['logl'],
                dtype=float,
            )
        except (KeyError, TypeError, ValueError):
            return False
        return bool(
            maximum_likelihood.ndim == 1
            and maximum_likelihood.size >= parameter_count
            and np.all(np.isfinite(maximum_likelihood[:parameter_count]))
            and weighted_points.ndim == 2
            and weighted_points.shape[0] > 0
            and weighted_points.shape[1] >= parameter_count
            and weighted_logl.shape == (weighted_points.shape[0],)
            and np.any(np.isfinite(weighted_logl))
        )

    @staticmethod
    def _restore_expanded_prior_physical_likelihoods(results, loglike, parameter_count):
        weighted_samples = results['weighted_samples']
        points = np.asarray(weighted_samples['points'], dtype=float)
        auxiliary_logl = np.asarray(weighted_samples['logl'], dtype=float)
        physical_logl = np.asarray(
            loglike(points[:, :parameter_count]),
            dtype=float,
        )
        if physical_logl.shape != (points.shape[0],) or not np.any(np.isfinite(physical_logl)):
            raise ValueError(
                "the corrected warm-start samples could not be evaluated under the physical likelihood"
            )

        weighted_samples['auxiliary_logl'] = auxiliary_logl.copy()
        weighted_samples['logl'] = physical_logl
        if points.shape[1] > parameter_count:
            weighted_samples['auxiliary_points'] = points[:, parameter_count:].copy()
        weighted_samples['points'] = points[:, :parameter_count].copy()
        maximum_index = int(np.nanargmax(physical_logl))
        maximum_likelihood = results.setdefault('maximum_likelihood', {})
        # The auxiliary likelihood contains a proposal correction and is not
        # the physical maximum-likelihood criterion reported by EXOTIC.
        maximum_likelihood['auxiliary_point'] = points[maximum_index].copy()
        maximum_likelihood['point'] = points[maximum_index, :parameter_count].copy()
        maximum_likelihood['logl'] = float(physical_logl[maximum_index])

        equal_weight_samples = np.asarray(results.get('samples'), dtype=float)
        if (
            equal_weight_samples.ndim == 2
            and equal_weight_samples.shape[1] >= parameter_count
        ):
            if equal_weight_samples.shape[1] > parameter_count:
                results['auxiliary_samples'] = equal_weight_samples[:, parameter_count:].copy()
            results['samples'] = equal_weight_samples[:, :parameter_count].copy()

        posterior = results.get('posterior')
        if isinstance(posterior, dict):
            for key, value in list(posterior.items()):
                value_array = np.asarray(value)
                if value_array.ndim == 1 and value_array.size == points.shape[1]:
                    posterior[key] = value_array[:parameter_count].copy()

    def _physical_values_from_sample_point(self, sample_point, bound_keys=None, sampled_keys=None):
        bound_keys = list(self.bounds.keys()) if bound_keys is None else list(bound_keys)
        sampled_keys = self._get_sampled_keys(bound_keys) if sampled_keys is None else list(sampled_keys)
        physical = dict(self.prior)
        impact_parameter = None

        for value, bound_key, sampled_key in zip(sample_point, bound_keys, sampled_keys):
            if sampled_key == 'b' and bound_key == 'inc':
                impact_parameter = value
                continue
            physical[bound_key] = value

        if impact_parameter is not None:
            physical['b'] = impact_parameter
            physical['inc'] = float(inclination_from_impact_parameter(physical, impact_parameter))

        return physical

    def _update_posterior_summaries(self, bound_keys, sampled_keys, physical_from_sample_point):
        from exotic.posterior import summarize_posterior, posterior_distribution_estimates

        self.posterior_summaries = {}
        self.posterior_distribution_estimates = {}
        weighted = self.results.get('weighted_samples', {})
        points = np.asarray(weighted.get('points', []), dtype=float)
        weights = np.asarray(weighted.get('weights', []), dtype=float)
        if (points.ndim == 2 and weights.shape == (points.shape[0],)
                and np.all(np.isfinite(weights)) and np.all(weights >= 0)
                and np.sum(weights) > 0):
            source = 'weighted_samples'
        else:
            # UltraNest's samples are already resampled to equal posterior weight.
            # Never treat unweighted nested-sampling dead points as a posterior.
            points = np.asarray(self.results.get('samples', []), dtype=float)
            weights = None
            source = 'equal_weight_samples'
        if points.ndim != 2 or not points.shape[0] or points.shape[1] < len(sampled_keys):
            self.posterior_summary_status = 'Posterior samples with usable weights are unavailable.'
            return
        physical_ml = dict(self.prior)
        physical_ml.update(physical_from_sample_point(self.results['maximum_likelihood']['point']))
        if 'b' in sampled_keys:
            physical_ml['inc'] = float(inclination_from_impact_parameter(physical_ml, physical_ml['b']))
        elif 'inc' in bound_keys:
            physical_ml['b'] = float(impact_parameter_from_inclination(physical_ml, physical_ml['inc']))
        values = {key: points[:, index] for index, key in enumerate(sampled_keys)}
        if 'inc' in bound_keys or 'b' in sampled_keys:
            physical = []
            for point in points:
                sample = dict(self.prior)
                sample.update(physical_from_sample_point(point))
                if 'b' in sampled_keys:
                    sample['inc'] = float(inclination_from_impact_parameter(sample, sample['b']))
                else:
                    sample['b'] = float(impact_parameter_from_inclination(sample, sample['inc']))
                physical.append(sample)
            values['inc'] = np.asarray([sample['inc'] for sample in physical])
            values['b'] = np.asarray([
                sample['b'] if 'b' in sample else impact_parameter_from_inclination(sample, sample['inc'])
                for sample in physical
            ])
        for key, samples in values.items():
            summary = summarize_posterior(samples, weights)
            if summary is not None:
                summary['sample_source'] = source
                summary['maximum_likelihood'] = float(physical_ml.get(key, self.prior.get(key, np.nan)))
                self.posterior_summaries[key] = summary
                estimate = posterior_distribution_estimates(samples, weights, parameter_key=key)
                if estimate is not None:
                    estimate['sample_source'] = source
                    self.posterior_distribution_estimates[key] = estimate
        self.posterior_summary_status = 'available' if self.posterior_summaries else 'No finite posterior samples.'

    def _get_ultranest_weighted_sample_arrays(self):
        try:
            weighted_samples = self.results['weighted_samples']
            points = np.asarray(weighted_samples['points'], dtype=float)
            logl = np.asarray(weighted_samples['logl'], dtype=float)
        except Exception:
            return None, None

        if points.ndim != 2 or points.shape[0] == 0:
            return None, None
        if logl.shape[0] != points.shape[0]:
            return None, None
        sampled_key_count = len(getattr(self, 'sampled_keys', []))
        if sampled_key_count and points.shape[1] >= sampled_key_count:
            points = points[:, :sampled_key_count]
        return points, logl

    def _loglike_neighborhood_uncertainty(self, parameter_index, center, minimum_count=8, points=None, logl=None):
        if points is None or logl is None:
            points, logl = self._get_ultranest_weighted_sample_arrays()
        if points is None or parameter_index >= points.shape[1]:
            return None

        values = np.asarray(points[:, parameter_index], dtype=float)
        finite = np.isfinite(values) & np.isfinite(logl)
        if np.count_nonzero(finite) < 2:
            return None

        finite_values = values[finite]
        finite_logl = logl[finite]
        max_logl = float(np.nanmax(finite_logl))
        if not np.isfinite(max_logl):
            return None

        selected_values = None
        selected_delta = np.inf
        for delta_chi2 in (1.0, 4.0, 9.0, 16.0, 25.0, np.inf):
            if np.isfinite(delta_chi2):
                mask = 2.0 * (max_logl - finite_logl) <= delta_chi2
            else:
                mask = np.ones(finite_logl.shape, dtype=bool)
            if np.count_nonzero(mask) >= minimum_count or delta_chi2 == np.inf:
                selected_values = finite_values[mask]
                selected_delta = delta_chi2
                break

        if selected_values is None or selected_values.size < 2:
            return None

        lower, upper = np.nanpercentile(selected_values, [15.8655, 84.1345])
        std = float(np.nanstd(selected_values))
        half_width = float(0.5 * (upper - lower))
        # The spread of the points INSIDE a delta-chi2<=k region is not a 1-sigma
        # width: projected onto one axis it is ~sigma*sqrt(k/(d+2)) for d sampled
        # dimensions. The EXTENT of that region along the axis is the profile
        # likelihood interval, whose half-range at k=1 is the marginal 1-sigma of a
        # Gaussian posterior (the shadow of the delta-chi2=1 ellipsoid). Use that,
        # rescaled when the window had to widen, and keep std / half_width only as
        # floors (issue #1401).
        scale = 1.0 / np.sqrt(selected_delta) if np.isfinite(selected_delta) and selected_delta > 0 else 1.0
        half_range = float(0.5 * (np.nanmax(selected_values) - np.nanmin(selected_values)) * scale)
        candidates = [value for value in (std, half_width, half_range) if np.isfinite(value) and value > 0]
        if not candidates:
            return None

        error = float(max(candidates))
        try:
            center_value = float(center)
        except (TypeError, ValueError):
            center_value = np.nan
        if np.isfinite(center_value):
            # Keep the quoted interval consistent with the quoted error.
            quantiles = [center_value - error, center_value + error]
        else:
            quantiles = [float(lower), float(upper)]
        return {
            'error': error,
            'quantiles': quantiles,
            'sample_count': int(selected_values.size),
            'delta_chi2': float(selected_delta),
            'interior_std': std,
            'interior_half_width': half_width,
            'profile_half_range': half_range,
        }

    def _ultranest_error_needs_sample_fallback(self, parameter_index, center, reported_error, points=None):
        if points is None:
            points, _ = self._get_ultranest_weighted_sample_arrays()
        if points is None or parameter_index >= points.shape[1]:
            return False

        values = np.asarray(points[:, parameter_index], dtype=float)
        finite_values = values[np.isfinite(values)]
        if finite_values.size < 2:
            return False

        sample_scale = float(np.nanstd(finite_values))
        if not np.isfinite(sample_scale) or sample_scale <= 0:
            return False

        try:
            reported_error = float(reported_error)
        except (TypeError, ValueError):
            return True

        if not np.isfinite(reported_error) or reported_error <= 0:
            return True

        absolute_floor = max(abs(float(center)) * 1e-12, np.finfo(float).eps)
        return reported_error <= absolute_floor or reported_error < sample_scale * 1e-6

    def _ultranest_error_is_inflated_relative_to_local_fit(self, reported_error, local_uncertainty):
        if not isinstance(local_uncertainty, dict):
            return False

        try:
            reported_error = float(reported_error)
            local_error = float(local_uncertainty.get('error', np.nan))
            delta_chi2 = float(local_uncertainty.get('delta_chi2', np.inf))
        except (TypeError, ValueError):
            return False

        if (
            not np.isfinite(reported_error)
            or reported_error <= 0
            or not np.isfinite(local_error)
            or local_error <= 0
        ):
            return False
        if not np.isfinite(delta_chi2) or delta_chi2 > ULTRANEST_LOCAL_UNCERTAINTY_MAX_DELTA_CHI2:
            return False

        return reported_error > local_error * ULTRANEST_INFLATED_ERROR_REPLACEMENT_FACTOR

    def _get_plot_range(self, key):
        sample_parameters = getattr(self, 'sample_parameters', {})
        sample_errors = getattr(self, 'sample_errors', {})
        sample_bounds = getattr(self, 'sample_bounds', getattr(self, 'bounds', {}))
        center = sample_parameters[key] if key in sample_parameters else self.parameters[key]
        error = sample_errors[key] if key in sample_errors else self.errors[key]

        if isinstance(sample_bounds, dict) and key in sample_bounds:
            try:
                lower, upper = [
                    float(value) for value in np.asarray(sample_bounds[key], dtype=float).reshape(-1)[:2]
                ]
            except (TypeError, ValueError, IndexError):
                lower = np.nan
                upper = np.nan
            if np.isfinite(lower) and np.isfinite(upper) and lower < upper:
                return [lower, upper]

        lower = center - 5 * error
        upper = center + 5 * error
        if np.isfinite(lower) and np.isfinite(upper) and lower < upper:
            return [lower, upper]

        pad = error if np.isfinite(error) and error > 0 else max(abs(center) * 1e-6, 1e-6)
        return [center - pad, center + pad]

    def _expand_plot_range_for_sample_cloud(
        self,
        key,
        plot_range,
        sample_values,
        center,
        required_visible_fraction=1.0,
    ):
        sample_values = np.asarray(sample_values, dtype=float)
        finite_values = sample_values[np.isfinite(sample_values)]
        if finite_values.size < 2:
            return plot_range

        lower, upper = [float(value) for value in plot_range]
        in_range = (finite_values >= lower) & (finite_values <= upper)
        visible_fraction = np.count_nonzero(in_range) / float(finite_values.size)
        if visible_fraction >= required_visible_fraction:
            return plot_range

        new_lower = min(float(np.nanmin(finite_values)), float(center))
        new_upper = max(float(np.nanmax(finite_values)), float(center))
        padding = 0.05 * (new_upper - new_lower)
        if not np.isfinite(padding) or padding <= 0:
            padding = max(abs(float(center)) * 1e-6, 1e-6)
        new_lower -= padding
        new_upper += padding

        sample_bounds = getattr(self, 'sample_bounds', self.bounds)
        if key in sample_bounds:
            bound_lower, bound_upper = sample_bounds[key]
            new_lower = max(new_lower, float(bound_lower))
            new_upper = min(new_upper, float(bound_upper))

        if not np.isfinite(new_lower) or not np.isfinite(new_upper) or new_lower >= new_upper:
            return plot_range
        return [float(new_lower), float(new_upper)]

    def _histogram_edge_peak_fractions(self, sample_values, plot_range, bins, weights=None):
        sample_values = np.asarray(sample_values, dtype=float)
        finite_mask = np.isfinite(sample_values)
        finite_weights = None

        if weights is not None:
            weights = np.asarray(weights, dtype=float)
            if weights.shape == sample_values.shape:
                finite_mask &= np.isfinite(weights) & (weights >= 0)
                finite_weights = weights[finite_mask]
                finite_weight_sum = np.sum(finite_weights)
                if (
                    finite_weights.size == 0
                    or not np.isfinite(finite_weight_sum)
                    or finite_weight_sum <= 0
                ):
                    finite_weights = None

        finite_values = sample_values[finite_mask]
        if finite_values.size < 2:
            return np.nan, np.nan, np.nan

        try:
            lower, upper = [float(value) for value in np.asarray(plot_range, dtype=float).reshape(-1)[:2]]
        except (TypeError, ValueError, IndexError):
            return np.nan, np.nan, np.nan

        if not np.isfinite(lower) or not np.isfinite(upper) or lower >= upper:
            return np.nan, np.nan, np.nan

        bins = max(1, int(bins))
        counts, _ = np.histogram(
            finite_values,
            bins=bins,
            range=(lower, upper),
            weights=finite_weights,
        )
        counts = np.asarray(counts, dtype=float)
        if counts.size == 0:
            return np.nan, np.nan, np.nan

        peak = float(np.nanmax(counts))
        if not np.isfinite(peak) or peak <= 0:
            return np.nan, np.nan, np.nan

        lower_fraction = float(counts[0] / peak)
        upper_fraction = float(counts[-1] / peak)
        return lower_fraction, upper_fraction, peak

    def _get_plot_range_expansion_bounds(self, key, sample_values, center):
        sample_bounds = getattr(self, 'sample_bounds', getattr(self, 'bounds', {}))
        if isinstance(sample_bounds, dict) and key in sample_bounds:
            try:
                bound_lower, bound_upper = [
                    float(value) for value in np.asarray(sample_bounds[key], dtype=float).reshape(-1)[:2]
                ]
            except (TypeError, ValueError, IndexError):
                bound_lower = np.nan
                bound_upper = np.nan

            if np.isfinite(bound_lower) and np.isfinite(bound_upper) and bound_lower < bound_upper:
                fallback_bounds = TRIANGLE_PLOT_FALLBACK_EXPANSION_BOUNDS.get(key)
                if fallback_bounds is not None:
                    fallback_lower, fallback_upper = fallback_bounds
                    if (
                        np.isfinite(fallback_lower)
                        and np.isfinite(fallback_upper)
                        and fallback_lower < fallback_upper
                    ):
                        return [
                            float(min(bound_lower, fallback_lower)),
                            float(max(bound_upper, fallback_upper)),
                        ]
                return [bound_lower, bound_upper]

        fallback_bounds = TRIANGLE_PLOT_FALLBACK_EXPANSION_BOUNDS.get(key)
        if fallback_bounds is not None:
            fallback_lower, fallback_upper = fallback_bounds
            if np.isfinite(fallback_lower) and np.isfinite(fallback_upper) and fallback_lower < fallback_upper:
                return [float(fallback_lower), float(fallback_upper)]

        sample_values = np.asarray(sample_values, dtype=float)
        finite_values = sample_values[np.isfinite(sample_values)]
        try:
            center = float(center)
        except (TypeError, ValueError):
            center = np.nan
        if np.isfinite(center):
            finite_values = np.concatenate([finite_values, [center]])
        if finite_values.size < 2:
            return None

        bound_lower = float(np.nanmin(finite_values))
        bound_upper = float(np.nanmax(finite_values))
        width = bound_upper - bound_lower
        if not np.isfinite(width) or width <= 0:
            padding = max(abs(float(center)) * 1e-6 if np.isfinite(center) else 0.0, 1e-6)
        else:
            padding = 0.05 * width
        return [bound_lower - padding, bound_upper + padding]

    def _expand_plot_range_for_histogram_edge_dropoff(
        self,
        key,
        plot_range,
        sample_values,
        center,
        bins=None,
        weights=None,
        max_edge_peak_fraction=TRIANGLE_PLOT_EDGE_PEAK_FRACTION_MAX,
        minimum_count=TRIANGLE_PLOT_EDGE_MIN_SAMPLE_COUNT,
        max_steps=TRIANGLE_PLOT_EDGE_EXPANSION_STEPS,
    ):
        sample_values = np.asarray(sample_values, dtype=float)
        finite_values = sample_values[np.isfinite(sample_values)]
        if finite_values.size < int(minimum_count):
            return plot_range

        try:
            lower, upper = [float(value) for value in np.asarray(plot_range, dtype=float).reshape(-1)[:2]]
        except (TypeError, ValueError, IndexError):
            return plot_range

        if not np.isfinite(lower) or not np.isfinite(upper) or lower >= upper:
            return plot_range

        expansion_bounds = self._get_plot_range_expansion_bounds(key, finite_values, center)
        if expansion_bounds is None:
            return plot_range

        bound_lower, bound_upper = expansion_bounds
        if not np.isfinite(bound_lower) or not np.isfinite(bound_upper) or bound_lower >= bound_upper:
            return plot_range

        lower = max(lower, bound_lower)
        upper = min(upper, bound_upper)
        if lower >= upper:
            return plot_range

        if bins is None:
            bins = int(np.clip(np.sqrt(finite_values.size), 10, 80))
        bins = max(1, int(bins))
        epsilon = max((bound_upper - bound_lower) * 1e-12, np.finfo(float).eps)

        for _ in range(max(0, int(max_steps)) + 1):
            lower_fraction, upper_fraction, _ = self._histogram_edge_peak_fractions(
                sample_values,
                [lower, upper],
                bins,
                weights=weights,
            )
            if not np.isfinite(lower_fraction) or not np.isfinite(upper_fraction):
                return [float(lower), float(upper)]

            needs_lower = lower_fraction >= max_edge_peak_fraction
            needs_upper = upper_fraction >= max_edge_peak_fraction
            if not needs_lower and not needs_upper:
                return [float(lower), float(upper)]

            width = upper - lower
            if not np.isfinite(width) or width <= 0:
                return [float(lower), float(upper)]

            new_lower = lower
            new_upper = upper
            if needs_lower and lower > bound_lower + epsilon:
                new_lower = max(bound_lower, lower - width)
            if needs_upper and upper < bound_upper - epsilon:
                new_upper = min(bound_upper, upper + width)

            if new_lower == lower and new_upper == upper:
                return [float(lower), float(upper)]

            lower, upper = new_lower, new_upper

        return [float(lower), float(upper)]

    def _get_mirrored_geometry_sample_cloud_range(self, sample_values, center, percentile_padding=0.5):
        sample_values = np.asarray(sample_values, dtype=float)
        finite_values = sample_values[np.isfinite(sample_values)]
        if finite_values.size < 2:
            return None

        try:
            center = float(center)
        except (TypeError, ValueError):
            center = np.nan
        if not np.isfinite(center):
            return None

        percentile_padding = float(percentile_padding)
        percentile_padding = min(max(percentile_padding, 0.0), 49.0)
        q_lower, q_upper = np.nanpercentile(
            finite_values,
            [percentile_padding, 100.0 - percentile_padding],
        )
        plot_lower = min(float(q_lower), center)
        plot_upper = max(float(q_upper), center)
        width = plot_upper - plot_lower
        if not np.isfinite(width) or width <= 0:
            return None

        padding = 0.05 * width
        plot_lower -= padding
        plot_upper += padding
        max_distance = float(np.nanmax(np.abs([plot_lower - center, plot_upper - center])))
        if not np.isfinite(max_distance) or max_distance <= 0:
            return None
        return [-max_distance, max_distance]

    def _get_mirrored_geometry_full_range(
        self,
        key,
        sample_values,
        center,
        sample_weights=None,
    ):
        try:
            center = float(center)
        except (TypeError, ValueError):
            center = np.nan
        if not np.isfinite(center):
            return None

        plot_lower, plot_upper = self._get_plot_range(key)
        plot_lower, plot_upper = self._expand_plot_range_for_sample_cloud(
            key,
            [plot_lower, plot_upper],
            sample_values,
            center,
            required_visible_fraction=1.0,
        )
        plot_bins = int(max(1, np.sqrt(np.asarray(sample_values).size)))
        plot_lower, plot_upper = self._expand_plot_range_for_histogram_edge_dropoff(
            key,
            [plot_lower, plot_upper],
            sample_values,
            center,
            bins=plot_bins,
            weights=sample_weights,
        )

        max_distance = float(np.nanmax(np.abs([plot_lower - center, plot_upper - center])))
        if not np.isfinite(max_distance) or max_distance <= 0:
            finite_offsets = np.asarray(sample_values, dtype=float) - center
            finite_offsets = finite_offsets[np.isfinite(finite_offsets)]
            if finite_offsets.size > 0:
                max_distance = float(np.nanmax(np.abs(finite_offsets)))
        if not np.isfinite(max_distance) or max_distance <= 0:
            max_distance = max(abs(center) * 1e-6, 1e-6)
        return [-max_distance, max_distance]

    def _get_triangle_plot_samples(self):
        if self.ns_type == 'ultranest':
            weighted_samples = self.results['weighted_samples']
            points = np.asarray(weighted_samples['points'], dtype=float)
            logl = np.asarray(weighted_samples['logl'], dtype=float)
            sampled_key_count = len(getattr(self, 'sampled_keys', []))
            if sampled_key_count and points.shape[1] >= sampled_key_count:
                points = points[:, :sampled_key_count]
            weights = self._get_triangle_plot_sample_weights(
                weighted_samples.get('weights'),
                points.shape[0],
            )
            return points, logl, weights

        raise RuntimeError("Triangle plots require an UltraNest nested-sampling result.")

    def _get_triangle_plot_sample_weights(self, weights, sample_count):
        if weights is None:
            return None

        weights = np.asarray(weights, dtype=float)
        if weights.ndim != 1 or weights.shape[0] != sample_count:
            return None

        finite = np.isfinite(weights) & (weights >= 0)
        if not np.all(finite):
            weights = np.where(finite, weights, 0.0)

        if not np.isfinite(np.sum(weights)) or np.sum(weights) <= 0:
            return None
        return weights

    def get_parameter_posterior_samples(self, key):
        sample_points = None
        try:
            equal_weight_samples = np.asarray(self.results.get('samples'), dtype=float)
            if equal_weight_samples.ndim == 2 and equal_weight_samples.shape[0] > 0:
                sample_points = equal_weight_samples
        except Exception:
            sample_points = None
        if sample_points is None:
            try:
                sample_points, _, _ = self._get_triangle_plot_samples()
            except Exception:
                return np.array([], dtype=float)

        sample_points = np.asarray(sample_points, dtype=float)
        if sample_points.ndim != 2 or sample_points.shape[0] == 0:
            return np.array([], dtype=float)

        sampled_keys = list(getattr(self, 'sampled_keys', self._get_sampled_keys()))
        if key in sampled_keys:
            key_index = sampled_keys.index(key)
            if key_index < sample_points.shape[1]:
                return np.asarray(sample_points[:, key_index], dtype=float)

        bound_keys = list(self.bounds.keys())
        physical_samples = [
            self._physical_values_from_sample_point(point, bound_keys, sampled_keys).get(key, np.nan)
            for point in sample_points
        ]
        return np.asarray(physical_samples, dtype=float)

    def _estimate_histogram_mode(self, samples, bounds=None, bins=None, weights=None):
        samples = np.asarray(samples, dtype=float)
        if weights is None:
            finite_mask = np.isfinite(samples)
            finite_weights = None
        else:
            weights = np.asarray(weights, dtype=float)
            if weights.shape != samples.shape:
                finite_mask = np.isfinite(samples)
                finite_weights = None
            else:
                finite_mask = np.isfinite(samples) & np.isfinite(weights) & (weights >= 0)
                finite_weights = weights[finite_mask]
                if finite_weights.size == 0 or np.sum(finite_weights) <= 0:
                    finite_weights = None

        finite_samples = samples[finite_mask]
        if finite_samples.size == 0:
            return np.nan, np.nan
        if finite_samples.size == 1:
            return float(finite_samples[0]), np.nan

        if bounds is None:
            lower = float(np.nanmin(finite_samples))
            upper = float(np.nanmax(finite_samples))
        else:
            lower, upper = np.asarray(bounds, dtype=float).reshape(-1)[:2]
            if not np.isfinite(lower) or not np.isfinite(upper) or lower >= upper:
                lower = float(np.nanmin(finite_samples))
                upper = float(np.nanmax(finite_samples))

        if not np.isfinite(lower) or not np.isfinite(upper) or lower >= upper:
            return float(np.nanmedian(finite_samples)), np.nan

        if bins is None:
            bins = int(np.clip(np.sqrt(finite_samples.size), 10, 80))
        bins = max(1, int(bins))

        counts, edges = np.histogram(finite_samples, bins=bins, range=(lower, upper), weights=finite_weights)
        if counts.size == 0:
            return float(np.nanmedian(finite_samples)), np.nan
        if not np.any(counts > 0):
            return float(np.nanmedian(finite_samples)), np.nan

        mode_index = int(np.argmax(counts))
        mode = float(0.5 * (edges[mode_index] + edges[mode_index + 1]))
        bin_width = float(edges[1] - edges[0]) if edges.size > 1 else np.nan
        return mode, bin_width

    def _format_triangle_plot_parameter_title(self, value, error):
        try:
            value = float(value)
        except (TypeError, ValueError):
            return "n/a"
        try:
            error = float(error)
        except (TypeError, ValueError):
            error = np.nan
        if not np.isfinite(value):
            return "n/a"
        if not np.isfinite(error) or error < 0:
            return str(round_to_2(value))
        return format_value_with_uncertainty(value, error)

    def _weighted_quantiles(self, values, quantiles, weights=None):
        values = np.asarray(values, dtype=float)
        quantiles = np.asarray(quantiles, dtype=float)
        finite_mask = np.isfinite(values)

        finite_weights = None
        if weights is not None:
            weights = np.asarray(weights, dtype=float)
            if weights.shape == values.shape:
                finite_mask &= np.isfinite(weights) & (weights >= 0)
                finite_weights = weights[finite_mask]
                if finite_weights.size == 0 or np.sum(finite_weights) <= 0:
                    finite_weights = None

        finite_values = values[finite_mask]
        if finite_values.size == 0:
            return np.full(quantiles.shape, np.nan, dtype=float)
        if finite_weights is None:
            return np.nanpercentile(finite_values, 100.0 * quantiles)

        order = np.argsort(finite_values)
        sorted_values = finite_values[order]
        sorted_weights = finite_weights[order]
        cumulative = np.cumsum(sorted_weights)
        total = cumulative[-1]
        if not np.isfinite(total) or total <= 0:
            return np.nanpercentile(finite_values, 100.0 * quantiles)

        cumulative = (cumulative - 0.5 * sorted_weights) / total
        cumulative = np.clip(cumulative, 0.0, 1.0)
        return np.interp(quantiles, cumulative, sorted_values)

    def _triangle_plot_display_estimate(
        self,
        sample_values,
        fallback_center,
        fallback_error,
        plot_range=None,
        weights=None,
        min_informative_peak_ratio=1.5,
        bins=None,
        force_histogram_mode=False,
    ):
        sample_values = np.asarray(sample_values, dtype=float)
        finite_mask = np.isfinite(sample_values)
        finite_weights = None
        if weights is not None:
            weights = np.asarray(weights, dtype=float)
            if weights.shape == sample_values.shape:
                finite_mask &= np.isfinite(weights) & (weights >= 0)
                finite_weights = weights[finite_mask]
                if finite_weights.size == 0 or np.sum(finite_weights) <= 0:
                    finite_weights = None

        finite_values = sample_values[finite_mask]
        if finite_values.size < 2:
            return fallback_center, fallback_error

        q16, q50, q84 = self._weighted_quantiles(
            sample_values,
            [0.158655, 0.5, 0.841345],
            weights=weights,
        )
        estimate = q50
        if plot_range is None:
            bounds = [float(np.nanmin(finite_values)), float(np.nanmax(finite_values))]
        else:
            try:
                bounds = [float(value) for value in np.asarray(plot_range, dtype=float).reshape(-1)[:2]]
            except (TypeError, ValueError, IndexError):
                bounds = [float(np.nanmin(finite_values)), float(np.nanmax(finite_values))]

        if np.all(np.isfinite(bounds)) and bounds[0] < bounds[1]:
            if bins is None:
                bins = int(np.clip(np.sqrt(finite_values.size), 10, 80))
            else:
                bins = max(1, int(bins))
            counts, edges = np.histogram(
                finite_values,
                bins=max(1, bins),
                range=bounds,
                weights=finite_weights,
            )
            positive_counts = counts[counts > 0]
            if positive_counts.size > 0:
                peak = float(np.nanmax(positive_counts))
                typical = float(np.nanmedian(positive_counts))
                total = float(np.nansum(positive_counts))
                informative_peak = (
                    np.isfinite(peak)
                    and np.isfinite(typical)
                    and np.isfinite(total)
                    and total > 0
                    and (
                        force_histogram_mode
                        or (
                            typical > 0
                            and peak >= min_informative_peak_ratio * typical
                            and peak >= 0.05 * total
                        )
                    )
                )
                if informative_peak:
                    mode_index = int(np.argmax(counts))
                    estimate = float(0.5 * (edges[mode_index] + edges[mode_index + 1]))

        try:
            fallback_center = float(fallback_center)
        except (TypeError, ValueError):
            fallback_center = np.nan
        if not np.isfinite(estimate):
            estimate = fallback_center

        spread_candidates = [
            abs(float(q84) - float(estimate)) if np.isfinite(q84) and np.isfinite(estimate) else np.nan,
            abs(float(estimate) - float(q16)) if np.isfinite(q16) and np.isfinite(estimate) else np.nan,
            0.5 * abs(float(q84) - float(q16)) if np.isfinite(q16) and np.isfinite(q84) else np.nan,
        ]
        try:
            fallback_error = float(fallback_error)
        except (TypeError, ValueError):
            fallback_error = np.nan

        finite_spreads = [value for value in spread_candidates if np.isfinite(value) and value >= 0]
        if finite_spreads and max(finite_spreads) > 0:
            error = float(max(finite_spreads))
        elif np.isfinite(fallback_error) and fallback_error > 0:
            error = fallback_error
        else:
            error = np.nan

        return float(estimate), error

    def _visible_triangle_plot_values(self, values, plot_range, weights=None):
        values = np.asarray(values, dtype=float)
        try:
            lower, upper = [float(value) for value in np.asarray(plot_range, dtype=float).reshape(-1)[:2]]
        except (TypeError, ValueError, IndexError):
            finite_mask = np.isfinite(values)
            return values[finite_mask], None

        finite_mask = np.isfinite(values)
        if np.isfinite(lower) and np.isfinite(upper) and lower < upper:
            finite_mask &= (values >= lower) & (values <= upper)

        visible_weights = None
        if weights is not None:
            weights = np.asarray(weights, dtype=float)
            if weights.shape == values.shape:
                visible_weights = weights[finite_mask]
        return values[finite_mask], visible_weights

    def get_parameter_posterior_recenter_diagnostics(self, key, sigma_scale=5.0, bins=None):
        diagnostics = {
            'key': key,
            'clipped': False,
            'edge': None,
            'mode': np.nan,
            'std': np.nan,
            'full_std': np.nan,
            'bounds': None,
            'original_bounds': None,
            'sample_size': 0,
            'peak_height': np.nan,
            'lower_edge_height': np.nan,
            'upper_edge_height': np.nan,
            'lower_edge_peak_fraction': np.nan,
            'upper_edge_peak_fraction': np.nan,
            'reason': None,
        }

        bounds = getattr(self, 'sample_bounds', {}).get(key, self.bounds.get(key))
        if bounds is None:
            diagnostics['reason'] = "parameter bounds are unavailable."
            return diagnostics

        try:
            lower_bound, upper_bound = np.asarray(bounds, dtype=float).reshape(-1)[:2]
        except (TypeError, ValueError, IndexError):
            diagnostics['reason'] = "parameter bounds are malformed."
            return diagnostics

        diagnostics['original_bounds'] = [float(lower_bound), float(upper_bound)]
        if not np.isfinite(lower_bound) or not np.isfinite(upper_bound) or lower_bound >= upper_bound:
            diagnostics['reason'] = "parameter bounds are not finite."
            return diagnostics

        samples = self.get_parameter_posterior_samples(key)
        finite_samples = np.asarray(samples, dtype=float)
        finite_samples = finite_samples[np.isfinite(finite_samples)]
        diagnostics['sample_size'] = int(finite_samples.size)
        if finite_samples.size < 8:
            diagnostics['reason'] = "too few posterior samples are available."
            return diagnostics

        mode, bin_width = self._estimate_histogram_mode(finite_samples, bounds=(lower_bound, upper_bound), bins=bins)
        full_std = float(np.nanstd(finite_samples))
        diagnostics['mode'] = mode
        diagnostics['full_std'] = full_std

        if not np.isfinite(mode):
            diagnostics['reason'] = "posterior mode could not be estimated."
            return diagnostics

        q05, q16, q50, q84, q95 = np.nanpercentile(finite_samples, [5, 16, 50, 84, 95])
        width = float(upper_bound - lower_bound)
        histogram_bins = int(np.clip(np.sqrt(finite_samples.size), 10, 80)) if bins is None else max(1, int(bins))
        histogram_counts, _ = np.histogram(
            finite_samples,
            bins=histogram_bins,
            range=(lower_bound, upper_bound),
        )
        histogram_counts = np.asarray(histogram_counts, dtype=float)
        peak_height = float(np.nanmax(histogram_counts)) if histogram_counts.size else np.nan
        lower_edge_height = float(histogram_counts[0]) if histogram_counts.size else np.nan
        upper_edge_height = float(histogram_counts[-1]) if histogram_counts.size else np.nan
        if np.isfinite(peak_height) and peak_height > 0:
            lower_edge_peak_fraction = float(lower_edge_height / peak_height)
            upper_edge_peak_fraction = float(upper_edge_height / peak_height)
        else:
            lower_edge_peak_fraction = np.nan
            upper_edge_peak_fraction = np.nan

        diagnostics['peak_height'] = peak_height
        diagnostics['lower_edge_height'] = lower_edge_height
        diagnostics['upper_edge_height'] = upper_edge_height
        diagnostics['lower_edge_peak_fraction'] = lower_edge_peak_fraction
        diagnostics['upper_edge_peak_fraction'] = upper_edge_peak_fraction

        scale_floor = max(
            2.0 * bin_width if np.isfinite(bin_width) and bin_width > 0 else 0.0,
            0.01 * width,
            np.finfo(float).eps,
        )
        tail_gap_threshold = max(0.5 * full_std if np.isfinite(full_std) and full_std > 0 else 0.0, scale_floor)
        mode_gap_threshold = max(
            1.0 * full_std if np.isfinite(full_std) and full_std > 0 else 0.0,
            3.0 * bin_width if np.isfinite(bin_width) and bin_width > 0 else 0.0,
            0.05 * width,
            np.finfo(float).eps,
        )

        upper_gap_q95 = float(upper_bound - q95)
        lower_gap_q05 = float(q05 - lower_bound)
        upper_gap_mode = float(upper_bound - mode)
        lower_gap_mode = float(mode - lower_bound)

        upper_clipped = upper_gap_q95 <= tail_gap_threshold and upper_gap_mode <= mode_gap_threshold
        lower_clipped = lower_gap_q05 <= tail_gap_threshold and lower_gap_mode <= mode_gap_threshold
        edge_peak_fraction_floor = 0.20
        rejected_edges = []

        if upper_clipped and np.isfinite(upper_edge_peak_fraction) and upper_edge_peak_fraction < edge_peak_fraction_floor:
            upper_clipped = False
            rejected_edges.append(
                f"upper edge histogram height is only {upper_edge_peak_fraction:.3f} of the posterior peak"
            )
        if lower_clipped and np.isfinite(lower_edge_peak_fraction) and lower_edge_peak_fraction < edge_peak_fraction_floor:
            lower_clipped = False
            rejected_edges.append(
                f"lower edge histogram height is only {lower_edge_peak_fraction:.3f} of the posterior peak"
            )

        if upper_clipped and lower_clipped:
            clipped_edge = 'upper' if upper_gap_mode <= lower_gap_mode else 'lower'
        elif upper_clipped:
            clipped_edge = 'upper'
        elif lower_clipped:
            clipped_edge = 'lower'
        else:
            diagnostics['bounds'] = [float(lower_bound), float(upper_bound)]
            if rejected_edges:
                diagnostics['reason'] = (
                    "posterior reaches a search bound, but "
                    + " and ".join(rejected_edges)
                    + ", so it is not treated as truncated."
                )
            else:
                diagnostics['reason'] = "posterior support is comfortably inside the sampled bounds."
            return diagnostics

        diagnostics['clipped'] = True
        diagnostics['edge'] = clipped_edge

        if clipped_edge == 'upper':
            side_distances = mode - finite_samples[finite_samples <= mode]
        else:
            side_distances = finite_samples[finite_samples >= mode] - mode

        side_distances = np.asarray(side_distances, dtype=float)
        side_distances = side_distances[np.isfinite(side_distances)]
        side_distances = side_distances[side_distances >= 0]

        if side_distances.size >= 2:
            mirrored = np.concatenate([side_distances, -side_distances])
            estimated_std = float(np.nanstd(mirrored))
        else:
            estimated_std = full_std

        min_std = max(
            bin_width if np.isfinite(bin_width) and bin_width > 0 else 0.0,
            width * 1e-3,
            np.finfo(float).eps,
        )
        if not np.isfinite(estimated_std) or estimated_std <= 0:
            estimated_std = full_std
        if not np.isfinite(estimated_std) or estimated_std <= 0:
            estimated_std = min_std
        estimated_std = float(max(estimated_std, min_std))
        diagnostics['std'] = estimated_std

        radius = float(max(sigma_scale * estimated_std, min_std))
        new_lower = float(mode - radius)
        new_upper = float(mode + radius)
        if lower_bound >= 0:
            new_lower = max(0.0, new_lower)
        diagnostics['bounds'] = [new_lower, new_upper]
        diagnostics['reason'] = (
            f"posterior peaks against the {clipped_edge} search bound "
            f"(mode={mode:.6g}, sigma={estimated_std:.6g})."
        )
        diagnostics['q16'] = float(q16)
        diagnostics['q50'] = float(q50)
        diagnostics['q84'] = float(q84)
        diagnostics['q05'] = float(q05)
        diagnostics['q95'] = float(q95)
        return diagnostics

    def _get_triangle_plot_display_spec(
        self,
        sampled_keys,
        sample_parameters,
        sample_errors,
        sample_points,
        sample_weights=None,
    ):
        if 'b' in sampled_keys:
            key = 'b'
            label = r'Impact parameter $b$'
            mirror = False
        elif 'inc' in sampled_keys:
            key = 'inc'
            label = r'$\Delta i$'
            mirror = True
        else:
            return None

        geometry_index = sampled_keys.index(key)
        center = float(sample_parameters.get(key, self.parameters.get(key, 0.0)))
        sample_values = np.asarray(sample_points[:, geometry_index], dtype=float)
        magnitude_samples = np.abs(sample_values - center)
        error = float(sample_errors.get(key, np.nanstd(magnitude_samples)))
        if not np.isfinite(error) or error <= 0:
            error = float(np.nanstd(magnitude_samples))

        if mirror:
            display_range = self._get_mirrored_geometry_full_range(
                key,
                sample_values,
                center,
                sample_weights=sample_weights,
            )
        else:
            display_range = None

        if display_range is None:
            plot_lower, plot_upper = self._get_plot_range(key)
            plot_lower, plot_upper = self._expand_plot_range_for_sample_cloud(
                key,
                [plot_lower, plot_upper],
                sample_values,
                center,
            )
            plot_bins = int(max(1, np.sqrt(sample_points.shape[0])))
            plot_lower, plot_upper = self._expand_plot_range_for_histogram_edge_dropoff(
                key,
                [plot_lower, plot_upper],
                sample_values,
                center,
                bins=plot_bins,
                weights=sample_weights,
            )
            if mirror:
                max_distance = float(np.nanmax(np.abs([plot_lower - center, plot_upper - center])))
                if not np.isfinite(max_distance) or max_distance <= 0:
                    max_distance = float(np.nanmax(magnitude_samples))
                if not np.isfinite(max_distance) or max_distance <= 0:
                    max_distance = max(abs(center) * 1e-6, 1e-6)
                display_range = [-max_distance, max_distance]
            else:
                display_range = [float(plot_lower), float(plot_upper)]
        return {
            'key': key,
            'index': geometry_index,
            'label': label,
            'mirror': mirror,
            'center': center,
            'mask_center': 0.0 if mirror else center,
            'mask_error': error,
            'magnitude_samples': magnitude_samples,
            'range': display_range,
            'truth': 0.0 if mirror else center,
            'reference_lines': self._get_triangle_plot_geometry_reference_lines(
                key,
                center,
                sample_parameters,
            ),
        }

    def _get_triangle_plot_geometry_reference_lines(self, key, center, sample_parameters):
        if key != 'b':
            return []

        try:
            center = float(center)
        except (TypeError, ValueError):
            center = np.nan
        if not np.isfinite(center):
            return []

        rprs = sample_parameters.get('rprs')
        if rprs is None:
            rprs = getattr(self, 'parameters', {}).get(
                'rprs',
                getattr(self, 'prior', {}).get('rprs', np.nan),
            )
        try:
            rprs = float(rprs)
        except (TypeError, ValueError):
            rprs = np.nan

        reference_lines = [
            {
                'value': 1.0,
                'color': '#707070',
                'linestyle': ':',
                'linewidth': 0.9,
                'alpha': 0.9,
            },
        ]
        if np.isfinite(rprs) and rprs >= 0:
            reference_lines.append(
                {
                    'value': 1.0 + rprs,
                    'color': '#a35d00',
                    'linestyle': '-.',
                    'linewidth': 0.9,
                    'alpha': 0.9,
                }
            )
        return reference_lines

    def _get_triangle_plot_geometry_reference_offsets(self, display_spec):
        reference_lines = display_spec.get('reference_lines', []) if isinstance(display_spec, dict) else []
        if not reference_lines:
            return []

        try:
            center = float(display_spec['center'])
        except (KeyError, TypeError, ValueError):
            return []
        if not np.isfinite(center):
            return []

        offsets = []
        for reference in reference_lines:
            try:
                value = float(reference['value'])
            except (KeyError, TypeError, ValueError):
                continue
            if not np.isfinite(value):
                continue

            distance = abs(value - center)
            if not np.isfinite(distance):
                continue
            reference_offsets = [0.0] if distance <= np.finfo(float).eps else [-distance, distance]
            for offset in reference_offsets:
                offsets.append({
                    'offset': float(offset),
                    'color': reference.get('color', '#707070'),
                    'linestyle': reference.get('linestyle', ':'),
                    'linewidth': reference.get('linewidth', 0.9),
                    'alpha': reference.get('alpha', 0.9),
                })
        return offsets

    def _draw_triangle_plot_geometry_reference_lines(self, ax, display_spec, axis='x', limits=None):
        if ax is None:
            return

        if limits is None:
            limits = ax.get_xlim() if axis == 'x' else ax.get_ylim()
        lower, upper = np.sort(np.asarray(limits, dtype=float).reshape(-1)[:2])
        if not display_spec.get('mirror', True):
            for reference in display_spec.get('reference_lines', []):
                try:
                    value = float(reference['value'])
                except (KeyError, TypeError, ValueError):
                    continue
                if not np.isfinite(value) or value < lower or value > upper:
                    continue
                line_kwargs = {
                    'color': reference.get('color', '#707070'),
                    'linestyle': reference.get('linestyle', ':'),
                    'linewidth': reference.get('linewidth', 0.9),
                    'alpha': reference.get('alpha', 0.9),
                    'zorder': 2,
                }
                if axis == 'y':
                    ax.axhline(value, **line_kwargs)
                else:
                    ax.axvline(value, **line_kwargs)
            return

        if lower <= 0.0 <= upper:
            center_kwargs = {
                'color': '#4682b4',
                'linestyle': '--',
                'linewidth': 0.9,
                'alpha': 0.85,
                'zorder': 2,
            }
            if axis == 'y':
                ax.axhline(0.0, **center_kwargs)
            else:
                ax.axvline(0.0, **center_kwargs)
        for reference in self._get_triangle_plot_geometry_reference_offsets(display_spec):
            offset = reference['offset']
            if offset < lower or offset > upper:
                continue
            line_kwargs = {
                'color': reference['color'],
                'linestyle': reference['linestyle'],
                'linewidth': reference['linewidth'],
                'alpha': reference['alpha'],
                'zorder': 2,
            }
            if axis == 'y':
                ax.axhline(offset, **line_kwargs)
            else:
                ax.axvline(offset, **line_kwargs)

    def _get_triangle_plot_geometry_overlay(self, display_spec, sample_points):
        if display_spec is None:
            return None
        if not display_spec.get('mirror', True):
            return None

        geometry_index = display_spec['index']
        center = display_spec['center']
        offsets = np.asarray(sample_points[:, geometry_index], dtype=float) - center
        left_offsets = offsets[offsets <= 0]
        right_offsets = offsets[offsets >= 0]

        def mirrored_offsets(branch_offsets):
            if branch_offsets.size == 0:
                return np.array([], dtype=float)
            return np.concatenate([branch_offsets, -branch_offsets])

        return {
            'index': geometry_index,
            'left_count': left_offsets.size,
            'right_count': right_offsets.size,
            'left_mirrored': mirrored_offsets(left_offsets),
            'right_mirrored': mirrored_offsets(right_offsets),
        }

    def _format_triangle_plot_geometry_value(self, value, error, suffix=''):
        if value is None or not np.isfinite(value):
            return f"n/a{suffix}"
        if error is None or not np.isfinite(error) or error < 0:
            return f"{round_to_2(value)}{suffix}"
        return f"{format_value_with_uncertainty(value, error)}{suffix}"

    def _get_triangle_plot_geometry_summary(self, sampled_keys, sample_points):
        bound_keys = list(self.bounds.keys())
        sample_points = np.asarray(sample_points, dtype=float)
        sample_parameters = getattr(self, 'sample_parameters', {})
        sample_errors = getattr(self, 'sample_errors', {})

        physical_samples = [
            self._physical_values_from_sample_point(point, bound_keys, sampled_keys)
            for point in sample_points
        ]
        inc_samples = np.array([sample['inc'] for sample in physical_samples], dtype=float)
        b_samples = np.array([
            sample.get('b', impact_parameter_from_inclination(sample, sample['inc']))
            for sample in physical_samples
        ], dtype=float)

        inc_center = float(self.parameters.get('inc', np.nanmedian(inc_samples)))
        inc_error = float(self.errors.get('inc', np.nanstd(inc_samples)))
        if 'b' in sample_parameters:
            b_center = float(sample_parameters['b'])
        elif 'b' in self.parameters:
            b_center = float(self.parameters['b'])
        else:
            b_center = float(np.nanmedian(b_samples))
        b_error = float(sample_errors.get('b', self.errors.get('b', np.nanstd(b_samples))))

        title = (
            f"b={self._format_triangle_plot_geometry_value(b_center, b_error)}\n"
            f"i={self._format_triangle_plot_geometry_value(inc_center, inc_error, ' deg')}"
        )
        from exotic.posterior import fit_posterior_summary, format_posterior_interval
        b_summary = fit_posterior_summary(self, 'b')
        inc_summary = fit_posterior_summary(self, 'inc')
        if b_summary is not None and inc_summary is not None:
            title = (f"b={format_posterior_interval(b_summary, include_probability=False)}\n"
                     f"i={format_posterior_interval(inc_summary, 'deg', include_probability=False)}")
        return {
            'b_center': b_center,
            'b_error': b_error,
            'inc_center': inc_center,
            'inc_error': inc_error,
            'title': title,
        }

    def _smooth_triangle_plot_counts(self, counts):
        counts = np.asarray(counts, dtype=float)
        if counts.size <= 1 or not np.any(counts > 0):
            return counts

        sigma_bins = max(1.0, counts.size / 18.0)
        radius = max(1, int(np.ceil(3 * sigma_bins)))
        grid = np.arange(-radius, radius + 1, dtype=float)
        kernel = np.exp(-0.5 * (grid / sigma_bins) ** 2)
        kernel /= np.sum(kernel)
        return np.convolve(counts, kernel, mode='same')

    def _build_triangle_plot_geometry_curves(self, geometry_overlay, hist_range, bins_1d):
        hist_range = np.sort(np.asarray(hist_range, dtype=float))
        bins_1d = max(1, int(bins_1d))
        edges = np.linspace(hist_range[0], hist_range[1], bins_1d + 1)
        centers = 0.5 * (edges[:-1] + edges[1:])
        half_bin = 0.5 * (edges[1] - edges[0]) if edges.size > 1 else 0.0

        def branch_curve(samples):
            samples = np.asarray(samples, dtype=float)
            counts, _ = np.histogram(samples, bins=edges)
            support = np.zeros_like(counts, dtype=bool)
            if samples.size > 0:
                support = np.abs(centers) <= (np.max(np.abs(samples)) + half_bin)
            return counts.astype(float), support

        left_curve, left_support = branch_curve(geometry_overlay['left_mirrored'])
        right_curve, right_support = branch_curve(geometry_overlay['right_mirrored'])

        left_count = int(geometry_overlay.get('left_count', 0))
        right_count = int(geometry_overlay.get('right_count', 0))
        max_count = max(left_count, right_count)
        min_count = min(left_count, right_count)

        if max_count == 0:
            main_curve = np.zeros_like(centers, dtype=float)
        elif min_count == 0 or (min_count / max_count) < 0.35:
            main_curve = left_curve if left_count >= right_count else right_curve
        else:
            stacked = np.vstack([
                np.where(left_support, left_curve, np.nan),
                np.where(right_support, right_curve, np.nan),
            ])
            valid_counts = np.sum(np.isfinite(stacked), axis=0)
            summed = np.nansum(stacked, axis=0)
            main_curve = np.divide(
                summed,
                valid_counts,
                out=np.zeros_like(summed, dtype=float),
                where=valid_counts > 0,
            )

        main_curve = self._smooth_triangle_plot_counts(main_curve)

        return {
            'centers': centers,
            'left_curve': left_curve,
            'right_curve': right_curve,
            'main_curve': main_curve,
        }

    def _get_triangle_plot_payload(self):
        sampled_keys = getattr(self, 'sampled_keys', list(self.bounds.keys()))
        sample_parameters = getattr(self, 'sample_parameters', self.parameters)
        sample_errors = getattr(self, 'sample_errors', self.errors)
        sample_points, sample_logl, sample_weights = self._get_triangle_plot_samples()
        display_spec = self._get_triangle_plot_display_spec(
            sampled_keys,
            sample_parameters,
            sample_errors,
            sample_points,
            sample_weights=sample_weights,
        )
        geometry_overlay = self._get_triangle_plot_geometry_overlay(display_spec, sample_points)
        geometry_summary = self._get_triangle_plot_geometry_summary(sampled_keys, sample_points)

        display_points = np.array(sample_points, copy=True)
        display_logl = np.array(sample_logl, copy=True)
        display_weights = None if sample_weights is None else np.array(sample_weights, copy=True)
        mask_values = np.array(sample_points, copy=True)

        if display_spec is not None and display_spec.get('mirror', True):
            geometry_index = display_spec['index']
            positive_points = np.array(sample_points, copy=True)
            negative_points = np.array(sample_points, copy=True)
            positive_points[:, geometry_index] = display_spec['magnitude_samples']
            negative_points[:, geometry_index] = -display_spec['magnitude_samples']
            display_points = np.vstack([positive_points, negative_points])
            display_logl = np.concatenate([sample_logl, sample_logl])
            if sample_weights is not None:
                display_weights = np.concatenate([sample_weights, sample_weights])
            mask_values = np.array(display_points, copy=True)

        plot_bins = int(max(1, np.sqrt(display_points.shape[0])))

        flabels = {
            'rprs': r'R$_{p}$/R$_{s}$',
            'per': r'Period [day]',
            'tmid': r'T$_{mid}$',
            'ars': r'a/R$_{s}$',
            'inc': r'Inc. [deg]',
            'b': r'Impact parameter',
            'u1': r'u$_1$',
            'fpfs': r'F$_{p}$/F$_{s}$',
            'omega': r'$\omega$ [deg]',
            'mplanet': r'M$_{p}$ [M$_{\oplus}$]',
            'mstar': r'M$_{s}$ [M$_{\odot}$]',
            'ecc': r'$e$',
            'c0': r'$c_0$',
            'c1': r'$c_1$',
            'c2': r'$c_2$',
            'c3': r'$c_3$',
            'c4': r'$c_4$',
            'a0': r'$a_0$',
            'a1': r'$a_1$',
            'a2': r'$a_2$'
        }

        labels = []
        titles = []
        ranges = []
        mask_centers = []
        mask_errors = []
        truths = []

        for i, key in enumerate(sampled_keys):
            center = sample_parameters.get(key, self.parameters.get(key, 0.0))
            error = sample_errors.get(key, self.errors.get(key, 0.0))
            label = flabels.get(key, key)
            plot_range = self._get_plot_range(key)
            if sample_points.ndim == 2 and i < sample_points.shape[1]:
                plot_range = self._expand_plot_range_for_sample_cloud(
                    key,
                    plot_range,
                    sample_points[:, i],
                    center,
                )
                plot_range = self._expand_plot_range_for_histogram_edge_dropoff(
                    key,
                    plot_range,
                    sample_points[:, i],
                    center,
                    bins=plot_bins,
                    weights=sample_weights,
                )
                center, error = self._triangle_plot_display_estimate(
                    sample_points[:, i],
                    center,
                    error,
                    plot_range=plot_range,
                    weights=sample_weights,
                )
            title = self._format_triangle_plot_parameter_title(center, error)
            from exotic.posterior import fit_posterior_summary, format_posterior_interval
            summary = fit_posterior_summary(self, key)
            if summary is not None:
                title = format_posterior_interval(summary, include_probability=False)
            truth = center

            if display_spec is not None and key == display_spec['key']:
                label = display_spec['label']
                title = geometry_summary['title']
                plot_range = display_spec['range']
                center = display_spec['mask_center']
                error = display_spec['mask_error']
                truth = display_spec['truth']

            labels.append(label)
            titles.append(title)
            ranges.append(plot_range)
            mask_centers.append(center)
            mask_errors.append(error)
            try:
                truth = float(truth)
            except (TypeError, ValueError):
                truth = np.nan
            truths.append(truth if np.isfinite(truth) else None)

        return {
            'sampled_keys': sampled_keys,
            'display_points': display_points,
            'display_logl': display_logl,
            'display_weights': display_weights,
            'mask_values': mask_values,
            'display_spec': display_spec,
            'geometry_overlay': geometry_overlay,
            'geometry_summary': geometry_summary,
            'labels': labels,
            'titles': titles,
            'ranges': ranges,
            'mask_centers': mask_centers,
            'mask_errors': mask_errors,
            'truths': truths,
        }

    def _triangle_plot_sigma_window_ranges(self, payload, sigma):
        try:
            sigma = float(sigma)
        except (TypeError, ValueError):
            return payload['ranges']
        if not np.isfinite(sigma) or sigma <= 0:
            return payload['ranges']

        zoomed_ranges = []
        display_points = np.asarray(payload.get('display_points', []), dtype=float)
        for i, plot_range in enumerate(payload['ranges']):
            try:
                range_lower, range_upper = [
                    float(value) for value in np.asarray(plot_range, dtype=float).reshape(-1)[:2]
                ]
            except (TypeError, ValueError, IndexError):
                zoomed_ranges.append(plot_range)
                continue

            if not np.isfinite(range_lower) or not np.isfinite(range_upper) or range_lower >= range_upper:
                zoomed_ranges.append(plot_range)
                continue

            try:
                center = float(payload['mask_centers'][i])
                error = float(payload['mask_errors'][i])
            except (TypeError, ValueError, IndexError):
                zoomed_ranges.append(plot_range)
                continue

            if not np.isfinite(center) or not np.isfinite(error) or error <= 0:
                zoomed_ranges.append(plot_range)
                continue

            lower = max(range_lower, center - sigma * error)
            upper = min(range_upper, center + sigma * error)
            if not np.isfinite(lower) or not np.isfinite(upper) or lower >= upper:
                zoomed_ranges.append(plot_range)
                continue

            if display_points.ndim == 2 and i < display_points.shape[1]:
                values = display_points[:, i]
                finite_values = values[np.isfinite(values)]
                if finite_values.size and not np.any((finite_values >= lower) & (finite_values <= upper)):
                    zoomed_ranges.append(plot_range)
                    continue

            zoomed_ranges.append([float(lower), float(upper)])

        return zoomed_ranges

    def _recenter_triangle_plot_payload_for_visible_ranges(self, payload):
        display_points = np.asarray(payload.get('display_points', []), dtype=float)
        if display_points.ndim != 2 or display_points.shape[1] == 0:
            return payload

        updated = dict(payload)
        titles = list(payload.get('titles', []))
        truths = list(payload.get('truths', []))
        mask_centers = list(payload.get('mask_centers', []))
        mask_errors = list(payload.get('mask_errors', []))
        ranges = list(payload.get('ranges', []))
        sampled_keys = list(payload.get('sampled_keys', []))

        display_weights = payload.get('display_weights')
        if display_weights is not None:
            display_weights = np.asarray(display_weights, dtype=float)
            if display_weights.ndim != 1 or display_weights.shape[0] != display_points.shape[0]:
                display_weights = None

        plot_bins = int(max(1, np.sqrt(display_points.shape[0])))
        display_spec = payload.get('display_spec')
        geometry_summary = payload.get('geometry_summary') or {}

        for i, key in enumerate(sampled_keys):
            if i >= display_points.shape[1] or i >= len(ranges):
                continue
            if (
                display_spec is not None
                and key == display_spec.get('key')
                and display_spec.get('mirror', False)
            ):
                continue

            visible_values, visible_weights = self._visible_triangle_plot_values(
                display_points[:, i],
                ranges[i],
                weights=display_weights,
            )
            if visible_values.size < 2:
                continue

            fallback_center = truths[i] if i < len(truths) else np.nan
            if fallback_center is None or not np.isfinite(fallback_center):
                fallback_center = mask_centers[i] if i < len(mask_centers) else np.nan
            fallback_error = mask_errors[i] if i < len(mask_errors) else np.nan
            center, error = self._triangle_plot_display_estimate(
                visible_values,
                fallback_center,
                fallback_error,
                plot_range=ranges[i],
                weights=visible_weights,
                bins=plot_bins,
                force_histogram_mode=True,
            )
            if not np.isfinite(center):
                continue

            if i < len(truths):
                truths[i] = center
            if i < len(mask_centers):
                mask_centers[i] = center
            if i < len(mask_errors):
                mask_errors[i] = error
            if i < len(titles):
                from exotic.posterior import fit_posterior_summary, format_posterior_interval
                summary = fit_posterior_summary(self, key)
                if (display_spec is not None and key == 'inc'
                        and display_spec.get('key') == 'inc'
                        and not display_spec.get('mirror', False)):
                    titles[i] = geometry_summary['title']
                elif summary is not None:
                    # Zooming changes the displayed histogram, not the marginal
                    # posterior whose credible interval appears in its title.
                    if display_spec is not None and key == display_spec.get('key'):
                        titles[i] = geometry_summary['title']
                    else:
                        titles[i] = format_posterior_interval(summary, include_probability=False)
                elif display_spec is not None and key == display_spec.get('key'):
                    inc_center = geometry_summary.get('inc_center')
                    inc_error = geometry_summary.get('inc_error')
                    titles[i] = (
                        f"b={self._format_triangle_plot_geometry_value(center, error)}\n"
                        f"i={self._format_triangle_plot_geometry_value(inc_center, inc_error, ' deg')}"
                    )
                else:
                    titles[i] = self._format_triangle_plot_parameter_title(center, error)

        updated['titles'] = titles
        updated['truths'] = truths
        updated['mask_centers'] = mask_centers
        updated['mask_errors'] = mask_errors
        return updated

    def _triangle_contour_levels(self, chi2, mask1, mask2, mask3):
        raw_levels = np.array([
            np.percentile(chi2[mask1], 95),
            np.percentile(chi2[mask2], 95),
            np.percentile(chi2[mask3], 95),
        ], dtype=float)
        finite_levels = np.sort(raw_levels[np.isfinite(raw_levels)])
        if finite_levels.size == 0:
            return []

        unique_levels = []
        min_spacing = max(
            np.finfo(float).eps,
            np.nanmax(np.abs(finite_levels)) * 1e-12,
        )
        for level in finite_levels:
            if not unique_levels or level > unique_levels[-1] + min_spacing:
                unique_levels.append(float(level))
        return unique_levels

    def _overlay_triangle_plot_geometry_histograms(self, fig, payload, title_kwargs=None, label_kwargs=None):
        if not hasattr(fig, 'axes'):
            return

        display_spec = payload.get('display_spec')
        if display_spec is None:
            return

        sampled_keys = payload['sampled_keys']
        if len(fig.axes) != len(sampled_keys) ** 2:
            return

        axes = np.array(fig.axes).reshape((len(sampled_keys), len(sampled_keys)))
        if not display_spec.get('mirror', True):
            geometry_index = display_spec['index']
            for row in range(len(sampled_keys)):
                for col in range(len(sampled_keys)):
                    panel = axes[row, col]
                    if row == geometry_index and col == geometry_index:
                        self._draw_triangle_plot_geometry_reference_lines(panel, display_spec, axis='x')
                    elif col == geometry_index and row > col:
                        self._draw_triangle_plot_geometry_reference_lines(panel, display_spec, axis='x')
                    elif row == geometry_index and col < row:
                        self._draw_triangle_plot_geometry_reference_lines(panel, display_spec, axis='y')
            return

        geometry_overlay = payload.get('geometry_overlay')
        if geometry_overlay is None:
            return

        geometry_index = geometry_overlay['index']
        ax = axes[geometry_index, geometry_index]
        hist_range = np.sort(payload['ranges'][geometry_index])
        bins_1d = int(max(25, np.round(np.sqrt(payload['display_points'].shape[0]) * 6)))
        curves = self._build_triangle_plot_geometry_curves(geometry_overlay, hist_range, bins_1d)

        title = payload['titles'][geometry_index]
        x_label = payload['labels'][geometry_index]
        branch_left_color = '#6f8fcf'
        branch_right_color = '#d79b9b'
        title_kwargs = {} if title_kwargs is None else dict(title_kwargs)
        label_kwargs = {} if label_kwargs is None else dict(label_kwargs)

        ax.cla()
        ax.plot(curves['centers'], curves['main_curve'], color='black', linewidth=1.5, zorder=4)
        ax.plot(curves['centers'], curves['left_curve'], color=branch_left_color, linestyle='--',
                linewidth=0.75, alpha=0.75, zorder=3)
        ax.plot(curves['centers'], curves['right_curve'], color=branch_right_color, linestyle='--',
                linewidth=0.75, alpha=0.75, zorder=3)
        self._draw_triangle_plot_geometry_reference_lines(
            ax,
            display_spec,
            axis='x',
            limits=hist_range,
        )
        ax.set_title(title, **title_kwargs)
        if 'fontsize' in title_kwargs:
            ax.title.set_fontsize(title_kwargs['fontsize'])
        ax.set_xlim(hist_range)

        max_y = max(
            np.max(curves['main_curve']) if curves['main_curve'].size > 0 else 0.0,
            np.max(curves['left_curve']) if curves['left_curve'].size > 0 else 0.0,
            np.max(curves['right_curve']) if curves['right_curve'].size > 0 else 0.0,
        )
        ax.set_ylim(0, 1.1 * max(max_y, 1e-6))
        ax.set_yticks([])

        if geometry_index < len(sampled_keys) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel(x_label, **label_kwargs)

        for row in range(len(sampled_keys)):
            for col in range(len(sampled_keys)):
                if row == geometry_index and col == geometry_index:
                    continue
                panel = axes[row, col]
                if col == geometry_index and row > col:
                    self._draw_triangle_plot_geometry_reference_lines(panel, display_spec, axis='x')
                if row == geometry_index and col < row:
                    self._draw_triangle_plot_geometry_reference_lines(panel, display_spec, axis='y')

    def _overlay_single_parameter_triangle_gaussian(self, fig, payload):
        """Draw fixed full-posterior bins; normal approximations exclude geometry."""
        from exotic.posterior import fit_posterior_sample_values
        if not hasattr(fig, 'axes'):
            return
        sampled_keys = list(payload.get('sampled_keys', []))
        if not sampled_keys or len(fig.axes) != len(sampled_keys) ** 2:
            return
        display_points = np.asarray(payload.get('display_points', []), dtype=float)
        if display_points.ndim != 2 or not display_points.shape[0]:
            return
        full_values, weights, _ = fit_posterior_sample_values(self)
        axes = np.asarray(fig.axes).reshape(len(sampled_keys), len(sampled_keys))
        for index, key in enumerate(sampled_keys):
            estimate = (payload.get('posterior_distribution_estimates') or {}).get(key)
            if estimate is None:
                continue
            histogram = estimate['posterior_histogram_peak']
            ax = axes[index, index]
            parameter_values = np.asarray(full_values.get(key, []), dtype=float)
            valid = np.isfinite(parameter_values)
            parameter_weights = None if weights is None else np.asarray(weights)[valid]
            parameter_values = parameter_values[valid]
            if histogram['bin_width'] > 0 and key in full_values:
                # Fixed full-posterior bin edges keep the plotted peak identical
                # to the reported peak, even when the axes are zoomed.
                edges = np.linspace(*histogram['range'], histogram['bin_count'] + 1)
                for artist in list(ax.patches):
                    artist.remove()
                counts, _, _ = ax.hist(parameter_values, bins=edges, weights=parameter_weights,
                                       histtype='step', color='black')
                ax.set_ylim(0, max(float(np.max(counts)) * 1.1, np.finfo(float).tiny))
            gaussian = estimate['gaussian_fit']
            if key in ('b', 'inc') or 'center' not in gaussian or gaussian['sigma'] <= 0:
                continue
            center, sigma = gaussian['center'], gaussian['sigma']
            lower, upper = sorted(payload['ranges'][index])
            x_values = np.linspace(lower, upper, 400)
            total_weight = len(parameter_values) if parameter_weights is None else float(np.sum(parameter_weights))
            bin_width = histogram['bin_width']
            y_values = np.exp(-.5 * ((x_values - center) / sigma) ** 2)
            y_values *= total_weight * bin_width / (sigma * np.sqrt(2 * np.pi))
            ax.plot(x_values, y_values, color='#c2410c', linewidth=1.4, label='Gaussian approximation')
            ax.axvline(center, color='#c2410c', linestyle='--', linewidth=1., label='Gaussian centre')
            ax.set_ylim(0, max(ax.get_ylim()[1], float(np.max(y_values)) * 1.05))
        if payload.get('posterior_distribution_estimates'):
            from matplotlib.lines import Line2D
            fig.legend(handles=[
                Line2D([], [], color='black', label='Weighted posterior'),
                Line2D([], [], color='#4682b4', label='Posterior histogram peak'),
                Line2D([], [], color='#c2410c', label='Gaussian approximation'),
                Line2D([], [], color='#c2410c', linestyle='--', label='Gaussian centre'),
            ], loc='lower center', bbox_to_anchor=(.5, .005), ncol=4, frameon=False, fontsize=8)

    def _adjust_triangle_plot_layout(self, fig):
        if not hasattr(fig, 'subplots_adjust'):
            return
        subplotpars = getattr(fig, 'subplotpars', None)
        if subplotpars is None:
            return

        fig.subplots_adjust(
            left=max(subplotpars.left, 0.08),
            bottom=max(subplotpars.bottom, 0.12),
            right=min(subplotpars.right, 0.97),
            top=min(subplotpars.top, 0.94),
            wspace=subplotpars.wspace,
            hspace=subplotpars.hspace,
        )

    def _prepare_native_backend(self):
        if ((self.prior.get('_limb_darkening_law', 'claret') == 'claret'
             and self.prior.get('_claret_backend', 'cpp') == 'cpp')
            or (self.prior.get('_limb_darkening_law') == 'hybrid4'
                and self.prior.get('_hybrid4_backend', 'numpy') in ('cpp', 'cpp_flux'))):
            # Fail before optimizers/samplers can turn loading errors into
            # invalid likelihoods or an optimizer fallback.
            started = perf_counter()
            try:
                from .limbdarkfast_cpp import _library
            except ImportError:
                from limbdarkfast_cpp import _library
            _library()
            self.backend_setup_seconds = perf_counter() - started

    def estimate_geometry_information(self):
        """Local, data-only precision at the LM solution; no additional fit.

        Differentiate in b**2, which remains regular at a central transit, and
        include every free nuisance parameter. Duration priors and parameter
        bounds contribute no information here. Exposure integration uses the
        same model as the fit. This is a white-noise/local approximation, not
        a guarantee about a nonlinear or multimodal posterior.
        """
        result = {'available': False, 'note': 'No free transit geometry in the LM fit.'}
        keys = list(self.bounds)
        geometry_keys = [key for key in ('inc', 'b') if key in keys]
        if len(geometry_keys) != 1:
            return result
        if self.mode != 'lm' or np.ndim(self.airmass) != 1:
            result['note'] = 'Geometry precision not estimated for this fit/baseline; geometry remains free.'
            return result
        geometry_key = geometry_keys[0]
        geometry_index = keys.index(geometry_key)
        parameters = dict(self.parameters)
        b_squared = float(impact_parameter_from_inclination(parameters, parameters['inc'])) ** 2
        coordinates = np.array([parameters[key] for key in keys], dtype=float)
        coordinates[geometry_index] = b_squared
        total_duration = transit_duration(parameters)
        scales = np.array([float(self.bounds[key][1]) - float(self.bounds[key][0]) for key in keys])
        scales[geometry_index] = 1.0
        if 'tmid' in keys:
            scales[keys.index('tmid')] = min(scales[keys.index('tmid')], total_duration)
        if (not np.isfinite(total_duration) or total_duration <= 0
                or not np.all(np.isfinite(scales) & (scales > 0))):
            result['note'] = 'LM geometry or derivative scales are unavailable.'
            return result

        def evaluate(point):
            values = dict(parameters)
            values.update(zip(keys, point))
            q = float(point[geometry_index])
            scale = float(impact_parameter_scale(values))
            if q < 0 or scale <= 0 or q >= min(scale ** 2, (1 + values['rprs']) ** 2):
                return None
            values['inc'] = float(inclination_from_impact_parameter(values, np.sqrt(q)))
            if geometry_key == 'b':
                values['b'] = np.sqrt(q)
            outer = transit_duration(values)
            inner = transit_duration(values, max(1 - values['rprs'], 0.0))
            ingress = 0.5 * (outer - inner)
            if not np.isfinite(ingress) or ingress <= 0:
                return None
            curve = self._transit_model(self.time, values) * airmass_trend(
                values.get('a2', 0), self.airmass, reference=self._get_airmass_reference(),
            )
            if self._has_free_flux_baseline() or self._uses_fixed_flux_baseline():
                curve *= get_flux_baseline(values)
            else:
                curve *= solve_flux_baseline(
                    curve, self.data, self.dataerr, mask=self._get_baseline_fit_mask(),
                )
            return np.asarray(curve, dtype=float), ingress

        center = evaluate(coordinates)
        if center is None:
            result['note'] = 'LM solution has no measurable ingress duration.'
            return result
        curve, ingress = center
        jacobian = np.empty((len(self.time), len(keys)))
        duration_gradient = np.empty(len(keys))
        for index, scale in enumerate(scales):
            # Numerical derivative steps, not observational quality thresholds.
            step = max(np.cbrt(np.finfo(float).eps) * scale,
                       4 * abs(np.spacing(coordinates[index])))
            if index == geometry_index:
                upper = min(impact_parameter_scale(parameters) ** 2, (1 + parameters['rprs']) ** 2)
                step = min(step, 0.25 * (upper - b_squared))
            plus, minus = coordinates.copy(), coordinates.copy()
            plus[index] += step
            minus[index] -= step
            high, low = evaluate(plus), evaluate(minus)
            if high is None and low is None:
                result['note'] = f'Cannot estimate a local derivative for {keys[index]}; geometry remains free.'
                return result
            width = 2 * step
            if low is None:
                low, width = center, step
            if high is None:
                high, width = center, step
            jacobian[:, index] = (high[0] - low[0]) / self.dataerr * scale / width
            duration_gradient[index] = (high[1] - low[1]) * scale / width

        if not np.all(np.isfinite(jacobian)):
            result['note'] = 'Non-finite model derivatives; geometry precision is unavailable.'
            return result
        _, singular_values, vectors = np.linalg.svd(jacobian, full_matrices=False)
        tolerance = np.finfo(float).eps * max(jacobian.shape) * singular_values[0]
        keep = singular_values > tolerance
        vectors, singular_values = vectors[keep], singular_values[keep]
        rank = len(singular_values)
        profiled_baseline = not (self._has_free_flux_baseline() or self._uses_fixed_flux_baseline())
        dof = max(len(self.time) - rank - int(profiled_baseline), 1)
        variance = max(1.0, float(np.sum(((self.data - curve) / self.dataerr) ** 2) / dof))

        def uncertainty(gradient):
            projection = vectors @ gradient
            # A pseudoinverse alone gives false zero errors along null modes.
            if not np.allclose(vectors.T @ projection, gradient, rtol=1e-7,
                               atol=1e-10 * np.linalg.norm(gradient)):
                return np.inf
            return float(np.sqrt(variance * np.sum((projection / singular_values) ** 2)))

        b_gradient = np.zeros(len(keys))
        b_gradient[geometry_index] = 1.0
        ingress_error = uncertainty(duration_gradient)
        b_squared_error = uncertainty(b_gradient)
        offset = (np.asarray(self.time) - parameters['tmid'] + 0.5 * parameters['per']) % parameters['per'] - 0.5 * parameters['per']
        start, end = -0.5 * total_duration, 0.5 * total_duration
        result.update({
            'available': True,
            'method': 'data-only local Fisher information in b squared at the LM solution',
            'ingress_duration_minutes': float(ingress * 1440),
            'ingress_fractional_uncertainty': float(ingress_error / ingress) if np.isfinite(ingress_error) else None,
            'b_squared_uncertainty': b_squared_error if np.isfinite(b_squared_error) else None,
            'ingress_points': int(np.count_nonzero((offset >= start) & (offset <= start + ingress))),
            'egress_points': int(np.count_nonzero((offset >= end - ingress) & (offset <= end))),
            'noise_scale': float(np.sqrt(variance)),
            'note': 'Local white-noise estimate including free-parameter correlations; duration priors excluded.',
        })
        return result

    def profile_geometry_likelihood(self, published_geometry=None, bounds=None):
        if __package__:
            from .geometry_diagnostics import profile_geometry_likelihood
        else:
            from geometry_diagnostics import profile_geometry_likelihood
        return profile_geometry_likelihood(self, published_geometry, bounds)

    def fit_LM(self, *, fixed_impact_parameter=None, create_fit_variables=True,
               allow_unbounded_retry=True):
        self._prepare_native_backend()
        freekeys = list(self.bounds.keys())
        boundarray = np.array([self.bounds[k] for k in freekeys]).reshape(-1, 2)
        initial_parameters = np.asarray([self.prior[k] for k in freekeys], dtype=float)
        self.lm_initial_parameters = dict(zip(freekeys, initial_parameters.tolist()))
        self.lm_prior_uncertainties = {
            key: self.prior.get(f'{key}_unc')
            for key in ('rprs', 'ars', 'inc', 'tmid')
            if self.prior.get(f'{key}_unc') is not None
        }
        parameter_scales = np.asarray(boundarray[:, 1] - boundarray[:, 0], dtype=float)
        invalid_scales = ~np.isfinite(parameter_scales) | (parameter_scales <= 0)
        parameter_scales[invalid_scales] = np.maximum(
            np.abs(initial_parameters[invalid_scales]),
            1.0,
        )
        scaled_lower_bounds = (boundarray[:, 0] - initial_parameters) / parameter_scales
        scaled_upper_bounds = (boundarray[:, 1] - initial_parameters) / parameter_scales
        self._validate_flux_baseline_keys()

        duration_prior = self.duration_prior or {}
        try:
            expected_duration = float(duration_prior.get('expected_duration', np.nan))
            sigma_log_duration = float(duration_prior.get('sigma_log_duration', np.nan))
        except (TypeError, ValueError):
            expected_duration = sigma_log_duration = np.nan
        self.lm_duration_prior_applied = bool(
            duration_prior.get('applied')
            and np.isfinite(expected_duration) and expected_duration > 0
            and np.isfinite(sigma_log_duration) and sigma_log_duration > 0
        )
        model_evaluations = 0

        def assign_parameters(values, pars):
            values.update(zip(freekeys, pars))
            b = fixed_impact_parameter if fixed_impact_parameter is not None else (
                values['b'] if 'b' in freekeys else None
            )
            if b is not None:
                scale = float(impact_parameter_scale(values))
                if not np.isfinite(scale) or scale <= 0 or not 0 <= b <= scale:
                    raise ValueError('Fixed/fitted b requires 0 <= b <= the orbital impact-parameter scale.')
                values['b'] = float(b)
                values['inc'] = float(inclination_from_impact_parameter(values, b))

        def with_duration_prior(residuals):
            if not self.lm_duration_prior_applied:
                return residuals
            duration = transit_duration(self.prior)
            if np.isfinite(duration) and duration > 0:
                prior_residual = np.log(duration / expected_duration) / sigma_log_duration
            else:
                prior_residual = np.sqrt(-2.0 * BAD_LOG_LIKELIHOOD)
            return np.append(residuals, prior_residual)

        # trim data around predicted transit/eclipse time
        if np.ndim(self.airmass) == 2:
            print(f'Computing nearest neighbors and gaussian weights for {len(self.time)} npts...')
            self.gw, self.nearest = gaussian_weights(self.airmass, neighbors=self.neighbors)

        def lc2min_nneighbor(pars):
            nonlocal model_evaluations
            model_evaluations += 1
            self.lm_model_evaluations = model_evaluations
            assign_parameters(self.prior, pars)
            lightcurve = self._transit_model(self.time, self.prior)
            detrended = self.data / lightcurve
            wf = weightedflux(detrended, self.gw, self.nearest)
            model = lightcurve * wf
            # scipy.optimize.least_squares squares the returned residuals when
            # constructing its objective.  Return normalized residuals here so
            # LM minimizes chi-square, rather than the fourth power of each
            # residual.  The latter over-emphasizes isolated points and can pull
            # a transit timing solution away from its ingress/egress anchors.
            return with_duration_prior((self.data - model) / self.dataerr)

        def lc2min_airmass(pars):
            nonlocal model_evaluations
            model_evaluations += 1
            self.lm_model_evaluations = model_evaluations
            assign_parameters(self.prior, pars)
            model = self._transit_model(self.time, self.prior)
            model *= airmass_trend(
                self.prior.get('a2', 0),
                self.airmass,
                reference=self._get_airmass_reference(),
            )
            if self._has_free_flux_baseline():
                model *= get_flux_baseline(self.prior)
            elif self._uses_fixed_flux_baseline():
                model *= get_flux_baseline(self.prior)
            else:
                model *= solve_flux_baseline(
                    model,
                    self.data,
                    self.dataerr,
                    mask=self._get_baseline_fit_mask(),
                )
            return with_duration_prior((self.data - model) / self.dataerr)

        def scaled_residual_function(residual_function):
            def evaluate(scaled_parameters):
                physical_parameters = initial_parameters + np.asarray(
                    scaled_parameters,
                    dtype=float,
                ) * parameter_scales
                return residual_function(physical_parameters)

            return evaluate

        try:
            if not freekeys:
                residual = lc2min_nneighbor if np.ndim(self.airmass) == 2 else lc2min_airmass
                fun = residual(np.empty(0))
                res = OptimizeResult(x=np.empty(0), fun=fun, jac=np.empty((len(fun), 0)),
                                     active_mask=np.empty(0), success=True, status=1,
                                     message='No free nuisance parameters; evaluated fixed model.', nfev=1, njev=0)
            elif np.ndim(self.airmass) == 2:
                res = least_squares(
                    scaled_residual_function(lc2min_nneighbor),
                    x0=np.zeros(len(freekeys), dtype=float),
                    bounds=[scaled_lower_bounds, scaled_upper_bounds],
                    jac='3-point',
                    loss='linear',
                )
            else:
                res = least_squares(
                    scaled_residual_function(lc2min_airmass),
                    x0=np.zeros(len(freekeys), dtype=float),
                    bounds=[scaled_lower_bounds, scaled_upper_bounds],
                    jac='3-point',
                    loss='linear',
                )
        except Exception as e:
            if not allow_unbounded_retry:
                raise
            print(f"{e} \nbounded light curve fitting failed...check priors "
                  "(e.g. estimated mid-transit time + orbital period)")

            for i, k in enumerate(freekeys):
                if not boundarray[i, 0] < self.prior[k] < boundarray[i, 1]:
                    print(f"bound: [{boundarray[i, 0]}, {boundarray[i, 1]}] prior: {self.prior[k]}")

            print("removing bounds and trying again...")

            if np.ndim(self.airmass) == 2:
                res = least_squares(
                    scaled_residual_function(lc2min_nneighbor),
                    x0=np.zeros(len(freekeys), dtype=float),
                    method='lm',
                    jac='3-point',
                    loss='linear',
                )
            else:
                res = least_squares(
                    scaled_residual_function(lc2min_airmass),
                    x0=np.zeros(len(freekeys), dtype=float),
                    method='lm',
                    jac='3-point',
                    loss='linear',
                )

        optimized_parameters = initial_parameters + np.asarray(res.x, dtype=float) * parameter_scales
        self.lm_active_bounds = {
            key: ('lower' if active < 0 else 'upper')
            for key, active in zip(freekeys, res.active_mask)
            if active
        }

        self.parameters = copy.deepcopy(self.prior)
        self.errors = {}
        self.quantiles = {}

        parameter_errors = np.full(len(freekeys), np.nan, dtype=float)
        try:
            jacobian = np.asarray(res.jac, dtype=float)
            degrees_of_freedom = max(int(res.fun.size) - len(freekeys), 1)
            residual_variance = float(np.sum(np.square(res.fun)) / degrees_of_freedom)
            scaled_covariance = np.linalg.pinv(jacobian.T @ jacobian) * residual_variance
            covariance = scaled_covariance * np.outer(parameter_scales, parameter_scales)
            diagonal = np.diag(covariance)
            valid = np.isfinite(diagonal) & (diagonal >= 0)
            parameter_errors[valid] = np.sqrt(diagonal[valid])
        except (AttributeError, TypeError, ValueError, np.linalg.LinAlgError):
            # A converged bounded fit is still useful when its local covariance
            # is singular.  Preserve that result and report unavailable errors
            # instead of the scientifically misleading zero uncertainties used
            # by the historical LM path.
            pass

        for i, k in enumerate(freekeys):
            self.parameters[k] = optimized_parameters[i]
            self.errors[k] = parameter_errors[i]
            self.quantiles[k] = [-parameter_errors[i], parameter_errors[i]]
        assign_parameters(self.parameters, optimized_parameters)
        self.lm_data_chi2 = float(np.sum(np.square(np.asarray(res.fun)[:len(self.time)])))
        self.lm_optimizer_success = bool(getattr(res, 'success', False))
        self.lm_optimizer_message = str(getattr(res, 'message', ''))
        self.lm_model_evaluations = model_evaluations

        self.sampled_keys = list(freekeys)
        self.sample_bounds = copy.deepcopy(self.bounds)
        self.sample_parameters = {k: self.parameters[k] for k in self.sampled_keys}
        self.sample_errors = {k: self.errors[k] for k in self.sampled_keys}
        self.sample_quantiles = {k: self.quantiles[k] for k in self.sampled_keys}

        if create_fit_variables:
            self.create_fit_variables()
        elif self._uses_analytic_flux_baseline():
            model = self._transit_model(self.time, self.parameters) * airmass_trend(
                self.parameters.get('a2', 0), self.airmass, reference=self._get_airmass_reference(),
            )
            self._set_flux_baseline(solve_flux_baseline(
                model, self.data, self.dataerr, mask=self._get_baseline_fit_mask(),
            ))
            self.lm_model_evaluations += 1

    def create_fit_variables(self):
        self.transit = self._transit_model(self.time, self.parameters)
        self._apply_fixed_parameter_errors()
        self._update_plot_geometry()
        if np.ndim(self.airmass) != 2:
            if self._has_free_flux_baseline():
                flux_scale = get_flux_baseline(self.parameters)
                flux_scale_err = self.errors.get('a0', self.errors.get('a1', 0.0))
            elif self._uses_fixed_flux_baseline():
                flux_scale = get_flux_baseline(self.parameters)
                flux_scale_err = self.errors.get(
                    'a0',
                    self.errors.get('a1', self.fixed_parameter_errors.get('a0', 0.0)),
                )
            elif self.mode == "ns":
                flux_scale, flux_scale_err = mc_a1(
                    self.parameters.get('a2', 0),
                    self.errors.get('a2', 1e-6),
                    self.transit,
                    self.airmass,
                    self.data,
                    self.dataerr,
                    mask=self._get_baseline_fit_mask(),
                )
            else:
                systematics = self.transit * airmass_trend(
                    self.parameters.get('a2', 0),
                    self.airmass,
                    reference=self._get_airmass_reference(),
                )
                flux_scale = solve_flux_baseline(
                    systematics,
                    self.data,
                    self.dataerr,
                    mask=self._get_baseline_fit_mask(),
                )
                flux_scale_err = self.errors.get(
                    'a0',
                    self.errors.get(
                        'a1',
                        solve_flux_baseline_uncertainty(
                            systematics,
                            self.dataerr,
                            mask=self._get_baseline_fit_mask(),
                        ),
                    ),
                )
            self._set_flux_baseline(flux_scale, flux_scale_err)
        if np.ndim(self.airmass) == 2:
            detrended = self.data / self.transit
            self.wf = weightedflux(detrended, self.gw, self.nearest)
            self.model = self.transit * self.wf
            self.detrended = self.data / self.wf
            self.detrendederr = self.dataerr / self.wf
        else:
            self.airmass_model = self._build_systematics_model(self.parameters)
            self.model = self.transit * self.airmass_model
            self.detrended = self.data / self.airmass_model
            self.detrendederr = self.dataerr / self.airmass_model

        self.residuals = self.data - self.model
        self.res_stdev = np.std(self.residuals)/np.median(self.data)
        self.chi2 = np.sum(self.residuals ** 2 / self.dataerr ** 2)
        self.bic = len(self.bounds) * np.log(len(self.time)) - 2 * np.log(self.chi2)

        # compare fit chi2 to smoothed data chi2
        dt = np.diff(np.sort(self.time)).mean()
        si = np.argsort(self.time)
        try:
            self.sdata = savgol_filter(self.data[si], 1 + 2 * int(0.5 / 24 / dt), 2)
        except:
            self.sdata = np.ones(len(self.time))

        schi2 = np.sum((self.data[si] - self.sdata) ** 2 / self.dataerr[si] ** 2)
        self.quality = schi2 / self.chi2

        # measured duration
        tdur = (self.transit < 1).sum() * np.median(np.diff(np.sort(self.time)))

        # test for partial transit
        newdur = transit_duration(self.parameters)
        if not np.isfinite(newdur) or newdur <= 0:
            newtime = np.linspace(self.parameters['tmid'] - 0.2, self.parameters['tmid'] + 0.2, 10000)
            newtran = transit(newtime, self.parameters)
            masktran = newtran < 1
            newdur = np.diff(newtime).mean() * masktran.sum()

        self.duration_measured = tdur
        self.duration_expected = newdur

    def _finalize_ultranest_fit_results(self, bound_keys, sampled_keys, physical_from_sample_point):
        # A later sampler extension needs a new comparison, not the previously
        # reported secondary result. Invalidate by fit state, without hashing.
        for attribute in ('hybrid4_comparison', 'hybrid4_fit'):
            if hasattr(self, attribute):
                delattr(self, attribute)
        self.sample_parameters = {}
        self.sample_errors = {}
        self.sample_quantiles = {}
        self.errors = {}
        self.quantiles = {}
        self.parameters = copy.deepcopy(self.prior)

        ml_point = self.results['maximum_likelihood']['point']
        self.sample_bounds = self._get_sample_bounds(bound_keys, physical_from_sample_point(ml_point))
        self.ultranest_error_fallbacks = {}
        weighted_points, weighted_logl = self._get_ultranest_weighted_sample_arrays()

        for i, key in enumerate(sampled_keys):
            self.sample_parameters[key] = ml_point[i]
            reported_error = self.results['posterior']['stdev'][i]
            reported_quantiles = [
                self.results['posterior']['errlo'][i],
                self.results['posterior']['errup'][i]]
            if self._ultranest_error_needs_sample_fallback(
                i,
                ml_point[i],
                reported_error,
                points=weighted_points,
            ):
                fallback = self._loglike_neighborhood_uncertainty(
                    i,
                    ml_point[i],
                    points=weighted_points,
                    logl=weighted_logl,
                )
                if fallback is not None:
                    fallback['reason'] = 'degenerate_posterior_summary'
            else:
                fallback = None
                local_uncertainty = self._loglike_neighborhood_uncertainty(
                    i,
                    ml_point[i],
                    points=weighted_points,
                    logl=weighted_logl,
                )
                if self._ultranest_error_is_inflated_relative_to_local_fit(reported_error, local_uncertainty):
                    fallback = local_uncertainty
                    fallback['reported_error'] = float(reported_error)
                    fallback['reason'] = 'posterior_summary_inflated_relative_to_local_fit'
            if fallback is not None:
                self.sample_errors[key] = fallback['error']
                self.sample_quantiles[key] = fallback['quantiles']
                self.ultranest_error_fallbacks[key] = fallback
            else:
                self.sample_errors[key] = reported_error
                self.sample_quantiles[key] = reported_quantiles

        physical_ml = physical_from_sample_point(ml_point)
        self.parameters.update(physical_ml)

        for bound_key, sampled_key in zip(bound_keys, sampled_keys):
            if bound_key == 'inc' and sampled_key == 'b':
                continue
            self.errors[bound_key] = self.sample_errors[sampled_key]
            self.quantiles[bound_key] = self.sample_quantiles[sampled_key]

        self._update_posterior_summaries(bound_keys, sampled_keys, physical_from_sample_point)
        inc_summary = self.posterior_summaries.get('inc')
        if 'inc' in bound_keys and 'b' in sampled_keys and inc_summary is not None:
            self.errors['inc'] = inc_summary['stdev']
            self.quantiles['inc'] = [
                inc_summary['lower'] - physical_ml['inc'],
                inc_summary['upper'] - physical_ml['inc'],
            ]
        self._apply_fixed_parameter_errors()

    def extend_ultranest_fit(self, min_num_live_points=None, max_ncalls=None):
        started = perf_counter()
        context = getattr(self, '_ultranest_resume_context', None)
        if getattr(self, 'ns_type', None) != 'ultranest' or not isinstance(context, dict):
            return False

        sampler = context.get('sampler')
        if sampler is None:
            return False

        run_kwargs = {"max_ncalls": int(max_ncalls if max_ncalls is not None else self.max_ncalls)}
        if min_num_live_points is not None:
            run_kwargs["min_num_live_points"] = int(min_num_live_points)

        self.results = run_reactive_sampler(
            sampler,
            run_kwargs=run_kwargs,
            verbose=self.verbose,
        )
        if getattr(self, 'ultranest_expanded_prior_warmstart_applied', False):
            if not self._expanded_prior_warmstart_result_is_usable(
                self.results,
                len(context['sampled_keys']),
            ):
                return False
            self._restore_expanded_prior_physical_likelihoods(
                self.results,
                context['loglike'],
                len(context['sampled_keys']),
            )
        self._finalize_ultranest_fit_results(
            context['bound_keys'],
            context['sampled_keys'],
            context['physical_from_sample_point'],
        )
        if min_num_live_points is not None:
            self.ultranest_min_num_live_points = int(min_num_live_points)
        self.create_fit_variables()
        self.fit_runtime_seconds = getattr(self, 'fit_runtime_seconds', 0.0) + perf_counter() - started
        return True

    def clear_ultranest_resume_state(self):
        self._ultranest_resume_context = None

    def fit_nested(self):
        self._prepare_native_backend()
        started = perf_counter()
        bound_keys = list(self.bounds.keys())
        sampled_keys = self._get_sampled_keys(bound_keys)
        self._validate_flux_baseline_keys()
        self.sampled_keys = list(sampled_keys)
        self.sample_bounds = self._get_sample_bounds(bound_keys, self.prior)
        self.impact_parameter_sampled_directly = self._uses_internal_impact_parameter()

        if len(set(self.sampled_keys)) != len(self.sampled_keys):
            raise ValueError("Free-parameter labels must be unique after internal parameter transforms.")

        # alloc data for best fit + error
        self.sample_parameters = {}
        self.sample_errors = {}
        self.sample_quantiles = {}
        self.errors = {}
        self.quantiles = {}
        self.parameters = copy.deepcopy(self.prior)

        base_physical = dict(self.prior)
        direct_sample_assignments = [
            (bound_key, index)
            for index, (bound_key, sampled_key) in enumerate(zip(bound_keys, sampled_keys))
            if not (sampled_key == 'b' and bound_key == 'inc')
        ]
        impact_parameter_index = next(
            (
                index
                for index, (bound_key, sampled_key) in enumerate(zip(bound_keys, sampled_keys))
                if sampled_key == 'b' and bound_key == 'inc'
            ),
            None,
        )
        time = self.time
        data = np.asarray(self.data, dtype=float)
        dataerr = np.asarray(self.dataerr, dtype=float)
        data_shape = data.shape
        dataerr_shape_matches = dataerr.shape == data_shape
        finite_dataerr = np.isfinite(dataerr) & (dataerr > 0) if dataerr_shape_matches else False
        observed_values_valid = (
            dataerr_shape_matches
            and np.all(np.isfinite(data))
            and np.all(finite_dataerr)
        )
        inverse_dataerr = np.zeros(data_shape, dtype=float)
        baseline_weights = np.zeros(data_shape, dtype=float)
        baseline_static_mask = np.isfinite(data)
        if dataerr_shape_matches:
            inverse_dataerr[finite_dataerr] = 1.0 / dataerr[finite_dataerr]
            baseline_weights[finite_dataerr] = inverse_dataerr[finite_dataerr] ** 2
            baseline_static_mask &= np.isfinite(baseline_weights) & (baseline_weights > 0)
        else:
            baseline_static_mask &= False

        baseline_fit_mask = self._get_baseline_fit_mask()
        if baseline_fit_mask is not None:
            baseline_static_mask &= baseline_fit_mask

        centered_airmass = center_airmass(self.airmass, reference=self._get_airmass_reference())
        has_free_flux_baseline = self._has_free_flux_baseline()
        uses_fixed_flux_baseline = self._uses_fixed_flux_baseline()
        sampled_key_index = {key: index for index, key in enumerate(sampled_keys)}
        sampled_a2_index = sampled_key_index.get('a2')
        fixed_airmass_scale = None
        if sampled_a2_index is None:
            try:
                fixed_a2 = float(base_physical.get('a2', 0.0))
            except (TypeError, ValueError):
                fixed_a2 = np.nan
            if not np.isfinite(fixed_a2):
                observed_values_valid = False
            elif fixed_a2 != 0.0:
                fixed_airmass_scale = np.exp(fixed_a2 * centered_airmass)

        free_flux_baseline_index = next(
            (sampled_key_index[key] for key in ('a0', 'a1') if key in sampled_key_index),
            None,
        )
        fixed_flux_baseline_value = None
        if free_flux_baseline_index is None and uses_fixed_flux_baseline:
            fixed_flux_baseline_value = get_flux_baseline(base_physical)

        duration_prior = self.duration_prior if isinstance(self.duration_prior, dict) else None
        duration_prior_applied = bool(duration_prior and duration_prior.get('applied'))
        try:
            expected_duration = float(duration_prior.get('expected_duration', np.nan)) if duration_prior else np.nan
            sigma_log_duration = float(duration_prior.get('sigma_log_duration', np.nan)) if duration_prior else np.nan
        except (TypeError, ValueError):
            expected_duration = np.nan
            sigma_log_duration = np.nan
        duration_prior_valid = (
            duration_prior_applied
            and np.isfinite(expected_duration)
            and expected_duration > 0
            and np.isfinite(sigma_log_duration)
            and sigma_log_duration > 0
        )

        # Serializable snapshot of the likelihood actually used by this fit.
        # Post-fit orbit sensitivity reuses it without running an optimiser or
        # sampler, including exposure integration, baseline and duration prior.
        self.orbital_likelihood_context = {
            'base_physical': base_physical.copy(), 'time': np.array(time, copy=True),
            'data': data.copy(), 'inverse_dataerr': inverse_dataerr.copy(),
            'centered_airmass': np.array(centered_airmass, copy=True),
            'baseline_static_mask': np.array(baseline_static_mask, copy=True),
            'baseline_weights': baseline_weights.copy(),
            'uses_fixed_flux_baseline': uses_fixed_flux_baseline,
            'has_free_flux_baseline': has_free_flux_baseline,
            'fixed_flux_baseline_value': fixed_flux_baseline_value,
            'free_flux_baseline_key': sampled_keys[free_flux_baseline_index] if free_flux_baseline_index is not None else None,
            'duration_prior_valid': duration_prior_valid,
            'expected_duration': expected_duration, 'sigma_log_duration': sigma_log_duration,
        }

        def solve_flux_baseline_for_model(model):
            mask = baseline_static_mask & np.isfinite(model) & (model != 0)
            if not np.any(mask):
                return fallback_flux_baseline()

            masked_model = model[mask]
            masked_data = data[mask]
            masked_weights = baseline_weights[mask]
            denom = np.sum(masked_weights * masked_model ** 2)

            if not np.isfinite(denom) or denom <= 0:
                ratio = masked_data / masked_model
                ratio = ratio[np.isfinite(ratio)]
                if ratio.size == 0:
                    return fallback_flux_baseline()
                baseline = np.nanmedian(ratio)
                return baseline if np.isfinite(baseline) else fallback_flux_baseline()

            baseline = np.sum(masked_weights * masked_data * masked_model) / denom
            return baseline if np.isfinite(baseline) else fallback_flux_baseline()

        def physical_from_sample_point(sample_point):
            physical = base_physical.copy()
            for bound_key, index in direct_sample_assignments:
                physical[bound_key] = sample_point[index]
            if impact_parameter_index is not None:
                impact_parameter = sample_point[impact_parameter_index]
                physical['b'] = impact_parameter
                physical['inc'] = float(inclination_from_impact_parameter(physical, impact_parameter))
            return physical

        def single_loglike(pars):
            if not observed_values_valid:
                return BAD_LOG_LIKELIHOOD

            physical = physical_from_sample_point(pars)
            duration_loglike = 0.0
            if duration_prior_valid:
                duration = transit_duration(physical)
                if not np.isfinite(duration) or duration <= 0:
                    return BAD_LOG_LIKELIHOOD
                duration_log_residual = np.log(duration / expected_duration)
                duration_loglike = -0.5 * (duration_log_residual / sigma_log_duration) ** 2
            try:
                model = np.asarray(self._transit_model(time, physical), dtype=float)
                if sampled_a2_index is not None:
                    model *= np.exp(float(pars[sampled_a2_index]) * centered_airmass)
                elif fixed_airmass_scale is not None:
                    model *= fixed_airmass_scale

                if free_flux_baseline_index is not None:
                    model *= pars[free_flux_baseline_index]
                elif fixed_flux_baseline_value is not None:
                    model *= fixed_flux_baseline_value
                elif has_free_flux_baseline:
                    model *= get_flux_baseline(physical)
                else:
                    model *= solve_flux_baseline_for_model(model)
            except Exception:
                return BAD_LOG_LIKELIHOOD

            if model.shape != data_shape or not np.all(np.isfinite(model)):
                return BAD_LOG_LIKELIHOOD

            residuals = (data - model) * inverse_dataerr
            chi2 = np.sum(residuals * residuals)
            logl = -0.5 * chi2 + duration_loglike
            return float(logl) if np.isfinite(logl) else BAD_LOG_LIKELIHOOD

        def loglike(pars):
            pars_array = np.asarray(pars, dtype=float)
            if pars_array.ndim == 2:
                return np.fromiter(
                    (single_loglike(row) for row in pars_array),
                    dtype=float,
                    count=pars_array.shape[0],
                )
            return single_loglike(pars_array)

        self.likelihood_backend = self._select_likelihood_backend()
        if self.likelihood_backend == 'cpp':
            from .likelihood_cpp import NativeLogLikelihood
            loglike = NativeLogLikelihood(
                self, bound_keys, sampled_keys, impact_parameter_index,
                observed_values_valid, fixed_airmass_scale,
            )

        prior_boundarray = np.array([self.bounds[k] for k in bound_keys], dtype=float)
        prior_lower_bounds = prior_boundarray[:, 0]
        prior_bound_widths = prior_boundarray[:, 1] - prior_lower_bounds
        prior_bound_index = {key: index for index, key in enumerate(bound_keys)}
        prior_inc_index = prior_bound_index.get('inc')

        def prior_values_for(sample_points, key, default):
            if key in prior_bound_index:
                return sample_points[:, prior_bound_index[key]]
            value = np.asarray(base_physical.get(key, default), dtype=float)
            if value.shape == ():
                return np.full(sample_points.shape[0], float(value), dtype=float)
            return np.broadcast_to(value, (sample_points.shape[0],)).astype(float)

        def prior_impact_upper_bounds(sample_points):
            rprs = prior_values_for(sample_points, 'rprs', np.nan)
            grazing_upper = np.where(np.isfinite(rprs) & (rprs >= 0), 1.0 + rprs, np.nan)

            ars = prior_values_for(sample_points, 'ars', np.nan)
            ecc = prior_values_for(sample_points, 'ecc', 0.0)
            omega = np.deg2rad(prior_values_for(sample_points, 'omega', 0.0))
            denom = 1.0 + ecc * np.sin(omega)
            denom = np.where(np.isclose(denom, 0.0), np.finfo(float).eps, denom)
            scale_upper = ars * (1.0 - ecc ** 2) / denom

            valid_grazing = np.isfinite(grazing_upper) & (grazing_upper > 0)
            valid_scale = np.isfinite(scale_upper) & (scale_upper > 0)
            upper = np.full(sample_points.shape[0], 1.0, dtype=float)

            both_valid = valid_grazing & valid_scale
            upper[both_valid] = np.minimum(grazing_upper[both_valid], scale_upper[both_valid])
            upper[valid_grazing & ~valid_scale] = grazing_upper[valid_grazing & ~valid_scale]
            upper[valid_scale & ~valid_grazing] = scale_upper[valid_scale & ~valid_grazing]
            return np.maximum(0.0, upper)

        def prior_transform(upars):
            upars_array = np.asarray(upars, dtype=float)
            sample_points = prior_lower_bounds + prior_bound_widths * upars_array
            if not self.impact_parameter_sampled_directly or prior_inc_index is None:
                return sample_points

            if upars_array.ndim == 2:
                upper_bounds = prior_impact_upper_bounds(sample_points)
                sample_points[:, prior_inc_index] = upper_bounds * upars_array[:, prior_inc_index]
                return sample_points

            upper_bound = prior_impact_upper_bounds(sample_points.reshape(1, -1))[0]
            sample_points[prior_inc_index] = upper_bound * upars_array[prior_inc_index]
            return sample_points

        self.ns_type = 'ultranest'
        warmstart_problem, warmstart_skip_reason = self._build_expanded_prior_warmstart_problem(
            bound_keys,
            sampled_keys,
            loglike,
            prior_transform,
        )
        self.ultranest_expanded_prior_warmstart_attempted = (
            getattr(self, 'ultranest_warmstart_source', None) is not None
        )
        if warmstart_problem is not None:
            test = ReactiveNestedSampler(
                warmstart_problem['param_names'],
                warmstart_problem['loglike'],
                warmstart_problem['transform'],
                vectorized=warmstart_problem['vectorized'],
            )
            self.ultranest_expanded_prior_warmstart_applied = True
            self.ultranest_expanded_prior_warmstart_note = (
                "Applied a corrected expanded-prior UltraNest warm start using "
                f"{self.ultranest_expanded_prior_warmstart_source_sample_count} previous "
                "weighted posterior sample(s), with "
                f"{100.0 * warmstart_problem['full_prior_fraction']:.0f}% of the auxiliary "
                "prior reserved for direct exploration of the full expanded prior."
            )
        else:
            test = ReactiveNestedSampler(sampled_keys, loglike, prior_transform, vectorized=True)
            self.ultranest_expanded_prior_warmstart_applied = False
            self.ultranest_expanded_prior_warmstart_note = warmstart_skip_reason

        run_kwargs = {"max_ncalls": int(self.max_ncalls)}
        if self.ultranest_min_num_live_points is not None:
            run_kwargs["min_num_live_points"] = int(self.ultranest_min_num_live_points)

        try:
            self.results = run_reactive_sampler(
                test,
                run_kwargs=run_kwargs,
                verbose=self.verbose,
            )
            if (
                warmstart_problem is not None
                and not self._expanded_prior_warmstart_result_is_usable(
                    self.results,
                    len(sampled_keys),
                )
            ):
                raise ValueError(
                    "the corrected warm-start result did not contain usable posterior samples"
                )
            if warmstart_problem is not None:
                self._restore_expanded_prior_physical_likelihoods(
                    self.results,
                    loglike,
                    len(sampled_keys),
                )
        except Exception as exc:
            if warmstart_problem is None:
                raise
            self.ultranest_expanded_prior_warmstart_applied = False
            self.ultranest_expanded_prior_warmstart_note = (
                "Corrected expanded-prior warm start failed; reran from the full expanded "
                f"prior instead ({type(exc).__name__}: {exc})."
            )
            if self.verbose:
                print(f"WARNING: {self.ultranest_expanded_prior_warmstart_note}")
            test = ReactiveNestedSampler(
                sampled_keys,
                loglike,
                prior_transform,
                vectorized=True,
            )
            self.results = run_reactive_sampler(
                test,
                run_kwargs=run_kwargs,
                verbose=self.verbose,
            )

        if self.keep_ultranest_sampler:
            self._ultranest_resume_context = {
                'sampler': test,
                'bound_keys': list(bound_keys),
                'sampled_keys': list(sampled_keys),
                'physical_from_sample_point': physical_from_sample_point,
                'loglike': loglike,
            }
        else:
            self._ultranest_resume_context = None
        self._finalize_ultranest_fit_results(bound_keys, sampled_keys, physical_from_sample_point)

        if not self.sample_parameters:
            self.sample_parameters = {
                key: self.parameters.get(key, self.sample_parameters.get(key))
                for key in self.sampled_keys
            }
        for bound_key, sampled_key in zip(bound_keys, sampled_keys):
            if sampled_key not in self.sample_errors and bound_key in self.errors:
                self.sample_errors[sampled_key] = self.errors[bound_key]
            if sampled_key not in self.sample_quantiles and bound_key in self.quantiles:
                self.sample_quantiles[sampled_key] = self.quantiles[bound_key]

        # final model
        self.create_fit_variables()
        self.fit_runtime_seconds = perf_counter() - started

    def _plot_restricted_baseline_points(
        self,
        ax_lc,
        ax_res,
        phase=True,
        include_excluded=True,
        include_rejected=True,
    ):
        """Overlay measured points outside the fit window and its pre-fit rejects."""
        payload = getattr(self, 'restricted_baseline_points', None)
        if not isinstance(payload, dict):
            return

        def _plot_group(prefix, color, marker, label, zorder):
            times = np.asarray(payload.get(f'{prefix}times', []), dtype=float).reshape(-1)
            flux = np.asarray(payload.get(f'{prefix}flux', []), dtype=float).reshape(-1)
            flux_unc = np.asarray(payload.get(f'{prefix}unc', []), dtype=float).reshape(-1)
            if times.size == 0 or times.shape != flux.shape:
                return
            if flux_unc.shape != flux.shape:
                flux_unc = np.full(flux.shape, np.nan, dtype=float)

            try:
                transit_model = np.asarray(self._transit_model(times, self.parameters), dtype=float)
                systematics = np.asarray(
                    self._build_systematics_model_at(self.parameters, times),
                    dtype=float,
                )
            except Exception:
                transit_model = np.full(times.shape, np.nan, dtype=float)
                systematics = np.ones(times.shape, dtype=float)

            # Apply the same correction used by the final baseline-detrending
            # pass to points that were measured but left out of the fit.
            if getattr(self, 'oot_baseline_detrending_applied', False):
                try:
                    slope = float(getattr(self, 'oot_baseline_slope', np.nan))
                    intercept = float(getattr(self, 'oot_baseline_intercept', np.nan))
                    reference = float(getattr(self, 'oot_baseline_reference_time_bjd_tdb', np.nan))
                    correction = intercept + slope * (times - reference)
                    if np.all(np.isfinite(correction)) and np.all(correction > 0):
                        systematics = correction
                except (TypeError, ValueError):
                    pass

            with np.errstate(divide='ignore', invalid='ignore'):
                detrended = flux / systematics
            median_data = np.nanmedian(np.asarray(getattr(self, 'data', []), dtype=float))
            if not np.isfinite(median_data) or median_data == 0:
                median_data = 1.0
            with np.errstate(divide='ignore', invalid='ignore'):
                propagated_unc = np.abs(flux_unc / systematics)
            detrended_unc = _pointwise_plot_uncertainties(
                detrended,
                propagated_unc,
                residuals=getattr(self, 'residuals', None),
                reference=getattr(self, 'data', None),
            )
            with np.errstate(invalid='ignore'):
                residual_percent = (detrended - transit_model) / median_data * 100.0

            finite = np.isfinite(times) & np.isfinite(detrended)
            if not np.any(finite):
                return
            if phase:
                x_values = get_plot_phase(
                    times,
                    self.parameters.get('per'),
                    self.parameters.get('tmid'),
                    getattr(self, 'plot_time_range', None),
                )
            else:
                x_values = times
            x_values = np.asarray(x_values, dtype=float)
            finite &= np.isfinite(x_values)
            if not np.any(finite):
                return

            valid_unc = finite & np.isfinite(detrended_unc) & (detrended_unc >= 0)
            if marker == 'o':
                if np.any(valid_unc):
                    ax_lc.errorbar(
                        x_values[valid_unc], detrended[valid_unc], yerr=detrended_unc[valid_unc],
                        ls='none', marker=marker, color=color, ecolor=color,
                        elinewidth=1.0, markersize=4.5, zorder=zorder, label=label,
                    )
                no_unc = finite & ~valid_unc
                if np.any(no_unc):
                    ax_lc.plot(
                        x_values[no_unc], detrended[no_unc], linestyle='none', marker=marker,
                        color=color, markersize=4.5, zorder=zorder, label='_nolegend_',
                    )
            else:
                ax_lc.scatter(
                    x_values[finite], detrended[finite], marker=marker, s=58,
                    linewidths=1.6, color=color, zorder=zorder, label=label,
                )

            residual_finite = finite & np.isfinite(residual_percent)
            if np.any(residual_finite):
                ax_res.scatter(
                    x_values[residual_finite], residual_percent[residual_finite],
                    marker=marker, s=28 if marker == 'o' else 58,
                    linewidths=1.6 if marker != 'o' else 1.0,
                    color=color, zorder=zorder, label='_nolegend_',
                )

        if include_excluded:
            _plot_group('', '#1565c0', 'o', 'Excluded baseline points', 8)
        if include_rejected:
            _plot_group('rejected_', '#d62728', 'x', '_nolegend_', 9)

    def plot_bestfit(
        self,
        title="",
        bin_dt=30. / (60 * 24),
        zoom=False,
        phase=True,
        show_flux_baseline_label=True,
        show_model_uncertainty=False,
        show_baseline_uncertainty=False,
        show_restricted_baseline_points=True,
        show_rejected_points=True,
        show_binned_points=True,
        _uncertainty_evaluator=None,
    ):
        f = plt.figure(figsize=(9, 6))
        f.subplots_adjust(top=0.92, bottom=0.09, left=0.14, right=0.98, hspace=0)
        ax_lc = plt.subplot2grid((4, 5), (0, 0), colspan=5, rowspan=3)
        ax_res = plt.subplot2grid((4, 5), (3, 0), colspan=5, rowspan=1)
        axs = [ax_lc, ax_res]

        axs[0].set_title(title)
        axs[0].set_ylabel("Relative Flux", fontsize=14)
        axs[0].grid(True, ls='--')

        from exotic.posterior import (
            fit_posterior_summary, fit_posterior_sample_values,
            summarize_posterior, format_posterior_interval,
        )

        rprs2 = self.parameters['rprs'] ** 2
        rprs_error_for_depth = self._combined_rprs_uncertainty_for_reporting()
        rprs2err = 2 * self.parameters['rprs'] * rprs_error_for_depth
        rprs_prior_marker = " (Prior)" if getattr(self, 'rprs_prior_fallback_applied', False) else ""
        rprs2_text, rprs2err_text = format_value_error_for_plot(rprs2, rprs2err)
        lclabel1 = r"$(R_{p}/R_{s})^{2}$ = %s $\pm$ %s%s" % (
            rprs2_text,
            rprs2err_text,
            rprs_prior_marker,
        )
        if rprs_prior_marker:
            # Fixed-parameter errors may contain the data estimate, not the
            # input prior uncertainty. Keep their provenance explicit.
            try:
                prior_error = float(getattr(self, 'rprs_prior_fallback_prior_uncertainty', np.nan))
            except (TypeError, ValueError):
                prior_error = np.nan
            if np.isfinite(prior_error) and prior_error >= 0:
                prior_value_text, prior_error_text = format_value_error_for_plot(
                    rprs2, 2 * self.parameters['rprs'] * prior_error,
                )
                lclabel1 = r"$(R_{p}/R_{s})^{2}$ = %s $\pm$ %s (Prior)" % (
                    prior_value_text, prior_error_text,
                )
            else:
                lclabel1 = r"$(R_{p}/R_{s})^{2}$ = %s (Prior; uncertainty unavailable)" % rprs2_text
            if np.isfinite(rprs2err) and rprs2err >= 0:
                lclabel1 += "\n" + r"$\pm$ %s (Data-based estimate)" % rprs2err_text
            else:
                lclabel1 += "\nData-based estimate unavailable"
        else:
            # The displayed quantity is squared radius ratio. Transform each
            # posterior draw before summarising, retaining its actual weight.
            posterior_values, posterior_weights, _ = fit_posterior_sample_values(self)
            if 'rprs' in posterior_values:
                depth_summary = summarize_posterior(posterior_values['rprs'] ** 2, posterior_weights)
                if depth_summary is not None:
                    lclabel1 = r"$(R_{p}/R_{s})^{2}$ = " + format_posterior_interval(
                        depth_summary, include_probability=False, mathtext=True,
                    )

        from exotic.transit_depth import fit_transit_depth_summary

        # Use the same geometry- and limb-darkening-aware depth as the results.
        observable_summary = fit_transit_depth_summary(self)
        observable_value, observable_error = format_value_error_for_plot(
            observable_summary['observable_depth'],
            observable_summary['observable_depth_error'],
        )
        observable_label = r"Depth = %s $\pm$ %s %%" % (
            observable_value, observable_error,
        )
        # Keep it beside the area depth even when prior provenance adds a line.
        first_depth_line, separator, depth_note = lclabel1.partition('\n')
        lclabel1 = first_depth_line + '    ' + observable_label + separator + depth_note

        tmid_error_for_plot = self._model_data_uncertainty_for_reporting('tmid')
        if not np.isfinite(tmid_error_for_plot):
            tmid_error_for_plot = self.errors.get('tmid', 0)
        tmid_text, tmid_error_text = format_value_error_for_plot(
            self.parameters['tmid'],
            tmid_error_for_plot,
        )
        lclabel2 = r"$T_{mid}$ = $%s^{+%s}_{-%s}$ BJD$_{TDB}$" % (
            tmid_text,
            tmid_error_text,
            tmid_error_text,
        )
        tmid_summary = fit_posterior_summary(self, 'tmid')
        if tmid_summary is not None:
            lclabel2 = r"$T_{mid}$ = " + format_posterior_interval(
                tmid_summary, r'BJD$_{TDB}$', include_probability=False, mathtext=True,
            )

        lclabel = lclabel1 + "\n" + lclabel2
        if show_flux_baseline_label and 'a0' in self.parameters:
            a0_text, a0_error_text = format_value_error_for_plot(
                self.parameters['a0'],
                self.errors.get('a0', 0),
            )
            lclabel3 = r"$a_0$ = %s $\pm$ %s" % (
                a0_text,
                a0_error_text,
            )
            lclabel += "\n" + lclabel3

        if zoom:
            axs[0].set_ylim([1 - 1.25 * self.parameters['rprs'] ** 2, 1 + 0.5 * self.parameters['rprs'] ** 2])
        else:
            plot_uncertainties = _pointwise_plot_uncertainties(
                self.detrended,
                getattr(self, 'detrendederr', None),
                residuals=self.residuals,
                reference=self.data,
            )
            if phase:
                axs[0].errorbar(self.phase, self.detrended, yerr=plot_uncertainties,
                                ls='none', marker='.', color='black', ecolor='0.72',
                                elinewidth=1.0, zorder=1, alpha=1.0)
            else:
                axs[0].errorbar(self.time, self.detrended, yerr=plot_uncertainties,
                                ls='none', marker='.', color='black', ecolor='0.72',
                                elinewidth=1.0, zorder=1, alpha=1.0)

        # Keep measured baseline observations visible, while distinguishing
        # points intentionally excluded from the fit with blue markers.  The
        # canonical final export can disable this overlay and retain it only
        # in the full-data diagnostic plot.
        if show_restricted_baseline_points or show_rejected_points:
            self._plot_restricted_baseline_points(
                axs[0],
                axs[1],
                phase=phase,
                include_excluded=show_restricted_baseline_points,
                include_rejected=show_rejected_points,
            )

        if phase:
            si = np.argsort(self.phase)
            bt2, br2, _ = time_bin(self.phase[si] * self.parameters['per'],
                                   self.residuals[si] / np.median(self.data) * 1e2, bin_dt)
            axs[1].plot(self.phase, self.residuals / np.median(self.data) * 1e2, 'k.', alpha=1.0,
                        label=r'$\sigma$ = {:.2f} %'.format(np.std(self.residuals / np.median(self.data) * 1e2)))
            if show_binned_points:
                axs[1].plot(bt2 / self.parameters['per'], br2, 'bs', alpha=1, zorder=2)
            axs[1].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
            axs[1].set_xlabel("Phase", fontsize=14)

            si = np.argsort(self.phase)
            bt2, bf2, bs = time_bin(self.phase[si] * self.parameters['per'], self.detrended[si], bin_dt)
            if show_binned_points:
                axs[0].errorbar(bt2 / self.parameters['per'], bf2, yerr=bs, alpha=1, zorder=2, color='blue', ls='none',
                                marker='s')
            # axs[0].plot(self.phase[si], self.transit[si], 'r-', zorder=3, label=lclabel)
            sii = np.argsort(self.phase_upsample)
            if show_baseline_uncertainty:
                self._plot_baseline_model_uncertainty(
                    axs[0],
                    self.phase_upsample,
                    self.time_upsample,
                    sii,
                    label='_nolegend_',
                    uncertainty_evaluator=_uncertainty_evaluator,
                )
            if show_model_uncertainty:
                self._plot_transit_model_uncertainty(
                    axs[0],
                    self.phase_upsample,
                    self.time_upsample,
                    sii,
                    label='_nolegend_',
                    uncertainty_evaluator=_uncertainty_evaluator,
                )
            axs[0].plot(self.phase_upsample[sii], self.transit_upsample[sii], 'r-', zorder=3, label=lclabel)
            axs[0].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
            axs[0].set_xlabel("Phase ", fontsize=14)
        else:
            bt, br, _ = time_bin(self.time, self.residuals / np.median(self.data) * 1e2, bin_dt)
            axs[1].plot(self.time, self.residuals / np.median(self.data) * 1e2, 'k.', alpha=1.0,
                        label=r'$\sigma$ = {:.2f} %'.format(np.std(self.residuals / np.median(self.data) * 1e2)))
            if show_binned_points:
                axs[1].plot(bt, br, 'bs', alpha=1, zorder=2, label=r'$\sigma$ = {:.2f} %'.format(np.std(br)))
            axs[1].set_xlim([min(self.time_upsample), max(self.time_upsample)])
            axs[1].set_xlabel("Time [day]", fontsize=14)

            bt, bf, bs = time_bin(self.time, self.detrended, bin_dt)
            si = np.argsort(self.time)
            sii = np.argsort(self.time_upsample)
            if show_binned_points:
                axs[0].errorbar(bt, bf, yerr=bs, alpha=1, zorder=2, color='blue', ls='none', marker='s')
            if show_baseline_uncertainty:
                self._plot_baseline_model_uncertainty(
                    axs[0],
                    self.time_upsample,
                    self.time_upsample,
                    sii,
                    label='_nolegend_',
                    uncertainty_evaluator=_uncertainty_evaluator,
                )
            if show_model_uncertainty:
                self._plot_transit_model_uncertainty(
                    axs[0],
                    self.time_upsample,
                    self.time_upsample,
                    sii,
                    label='_nolegend_',
                    uncertainty_evaluator=_uncertainty_evaluator,
                )
            axs[0].plot(self.time_upsample[sii], self.transit_upsample[sii], 'r-', zorder=3, label=lclabel)
            axs[0].set_xlim([min(self.time_upsample), max(self.time_upsample)])
            axs[0].set_xlabel("Time [day]", fontsize=14)

        axs[0].get_xaxis().set_visible(False)
        if (
            phase
            and _add_differential_hours_axis(axs[1], self.parameters.get('per')) is not None
        ):
            f.subplots_adjust(hspace=0.55)
        axs[1].legend(loc='best')
        axs[0].legend(loc='best')
        axs[1].set_ylabel("Residuals [%]", fontsize=14)
        axs[1].grid(True, ls='--', axis='y')
        axs[1].set_ylim(residual_plot_limits(self.residuals / np.median(self.data) * 1e2))
        return f, axs

    def _triangle_plot_inclination_payload(self, payload):
        """Display the joint posterior in inclination without changing sampling."""
        from exotic.posterior import fit_posterior_summary, summarize_posterior, format_posterior_interval

        sampled_keys = list(payload['sampled_keys'])
        if 'b' not in sampled_keys and 'inc' not in sampled_keys:
            return payload
        index = sampled_keys.index('b' if 'b' in sampled_keys else 'inc')
        points, logl, weights = self._get_triangle_plot_samples()
        display_points = np.array(points, copy=True)
        if sampled_keys[index] == 'b':
            # Transform every joint sample, including its own a/Rs, e and omega.
            physical = [self._physical_values_from_sample_point(
                point, list(self.bounds), sampled_keys,
            ) for point in points]
            inclinations = np.asarray([
                inclination_from_impact_parameter(sample, point[index])
                for sample, point in zip(physical, points)
            ], dtype=float)
            display_points[:, index] = inclinations
        else:
            inclinations = display_points[:, index]
        summary = fit_posterior_summary(self, 'inc')
        if summary is None and weights is not None:
            summary = summarize_posterior(inclinations, weights)
        if summary is not None:
            center, error = summary['median'], summary['stdev']
            title = format_posterior_interval(summary, 'deg', include_probability=False)
        else:
            # A histogram estimate from unweighted dead points is not a
            # posterior credible interval.
            center, error = self._triangle_plot_display_estimate(
                inclinations, self.parameters.get('inc', np.median(inclinations)),
                self.errors.get('inc', np.std(inclinations)), weights=weights,
            )
            title = self._format_triangle_plot_parameter_title(center, error) + ' deg'
        lower, upper = float(np.min(inclinations)), float(np.max(inclinations))
        padding = max(0.05 * (upper - lower), np.finfo(float).eps * 90)
        # Respect the physical boundary for the usual folded inclination, while
        # retaining any directly sampled retrograde inclinations.
        plot_range = [max(0.0, lower - padding), min(90.0 if upper <= 90 else 180.0, upper + padding)]
        updated = dict(payload)
        for key in ('labels', 'titles', 'ranges', 'mask_centers', 'mask_errors', 'truths'):
            updated[key] = list(payload[key])
        sampled_keys[index] = 'inc'
        updated['sampled_keys'] = sampled_keys
        updated['labels'][index] = r'Inclination $i$ [deg]'
        updated['titles'][index] = title
        updated['ranges'][index] = plot_range
        updated['mask_centers'][index] = center
        updated['mask_errors'][index] = error
        updated['truths'][index] = center
        updated['display_points'] = display_points
        updated['display_logl'] = logl
        updated['display_weights'] = weights
        updated['mask_values'] = display_points.copy()
        updated['geometry_overlay'] = None
        updated['geometry_summary'] = dict(payload.get('geometry_summary') or {},
                                           inc_center=center, inc_error=error, title=title)
        updated['display_spec'] = {
            'key': 'inc', 'index': index, 'label': updated['labels'][index],
            'mirror': False, 'center': center, 'mask_center': center,
            'mask_error': error, 'range': plot_range, 'truth': center,
            'reference_lines': [],
        }
        return updated

    def plot_triangle(self, plot_title=None, zoom_sigma=None):
        from exotic.posterior import fit_posterior_distribution_estimates
        payload = self._get_triangle_plot_payload()
        payload = self._triangle_plot_inclination_payload(payload)
        if zoom_sigma is not None:
            payload = dict(payload)
            payload['ranges'] = self._triangle_plot_sigma_window_ranges(payload, zoom_sigma)
            payload = self._recenter_triangle_plot_payload_for_visible_ranges(payload)
        # Both reference estimates use the FULL posterior, independent of zoom.
        # They affect only display; the model remains the joint likelihood fit.
        payload = dict(payload)
        estimates = fit_posterior_distribution_estimates(self)
        payload['posterior_distribution_estimates'] = estimates
        payload['truths'] = [
            estimates[key]['posterior_histogram_peak']['value'] if key in estimates else value
            for key, value in zip(payload['sampled_keys'], payload['truths'])
        ]

        chi2 = payload['display_logl'] * -2
        parameter_count = max(1, len(payload['sampled_keys']))
        fig_size = max(9.0, 2.35 * parameter_count)
        mask1 = np.ones(len(chi2), dtype=bool)
        mask2 = np.ones(len(chi2), dtype=bool)
        mask3 = np.ones(len(chi2), dtype=bool)

        for i, key in enumerate(payload['sampled_keys']):
            if key in ('a0', 'a1', 'a2'):
                continue

            center = payload['mask_centers'][i]
            error = payload['mask_errors'][i]
            if not np.isfinite(center) or not np.isfinite(error) or error <= 0:
                continue

            values = payload['mask_values'][:, i]
            mask3 = mask3 & (values > (center - 3 * error)) & (values < (center + 3 * error))
            mask1 = mask1 & (values > (center - error)) & (values < (center + error))
            mask2 = mask2 & (values > (center - 2 * error)) & (values < (center + 2 * error))

        if not np.any(mask1):
            mask1 = np.ones(len(chi2), dtype=bool)
        if not np.any(mask2):
            mask2 = np.ones(len(chi2), dtype=bool)
        if not np.any(mask3):
            mask3 = np.ones(len(chi2), dtype=bool)

        label_kwargs = {
            'labelpad': 10,
            'fontsize': 10,
        }
        title_kwargs = {
            'loc': 'left',
            'pad': 4,
            'fontsize': 11,
        }
        # The full BJD and asymmetric interval need separate lines to fit the
        # final diagonal panel without clipping the exported caption.
        plot_titles = [
            title.replace(' -', '\n-', 1) if key == 'tmid' else title
            for key, title in zip(payload['sampled_keys'], payload['titles'])
        ]

        fig = corner(payload['display_points'],
                     labels=payload['labels'],
                     bins=[estimates[key]['posterior_histogram_peak']['bin_count']
                           if key in estimates else int(np.sqrt(payload['display_points'].shape[0]))
                           for key in payload['sampled_keys']],
                     range=payload['ranges'],
                      weights=payload['display_weights'],
                      plot_contours=True,
                      levels=self._triangle_contour_levels(chi2, mask1, mask2, mask3),
                      plot_density=False,
                      titles=plot_titles,
                      truths=payload['truths'],
                      data_kwargs={
                          'c': chi2,
                          'vmin': np.percentile(chi2[mask3], 1),
                          'vmax': np.percentile(chi2[mask3], 95),
                          'cmap': 'viridis',
                          's': 1.6,
                          'alpha': 0.38,
                      },
                      label_kwargs=label_kwargs,
                      title_kwargs=title_kwargs,
                      hist_kwargs={
                          'color': 'black',
                      }
                      )
        if hasattr(fig, 'set_size_inches'):
            fig.set_size_inches(fig_size, fig_size, forward=True)
        if plot_title and hasattr(fig, 'suptitle'):
            fig.suptitle(plot_title, fontsize=13, y=0.99)
        if getattr(self, 'posterior_summaries', None) and hasattr(fig, 'text'):
            fig.text(.5, .955, 'Titles show posterior medians and asymmetric intervals (68%).',
                     ha='center', va='bottom', fontsize=9)
        self._overlay_single_parameter_triangle_gaussian(fig, payload)
        self._adjust_triangle_plot_layout(fig)
        self._overlay_triangle_plot_geometry_histograms(
            fig,
            payload,
            title_kwargs=title_kwargs,
            label_kwargs=label_kwargs,
        )
        return fig

# simultaneously fit multiple data sets with global and local parameters
class glc_fitter(lc_fitter):
    # needed for lc_fitter
    ns_type = 'ultranest'

    def __init__(self, input_data, global_bounds, local_bounds, individual_fit=False, stdev_cutoff=0.03, verbose=False):
        # keys for input_data: time, flux, ferr, airmass, priors all numpy arrays
        self.lc_data = copy.deepcopy(input_data)
        self.global_bounds = global_bounds
        self.local_bounds = local_bounds
        self.individual_fit = individual_fit
        self.stdev_cutoff = stdev_cutoff
        self.verbose = verbose
        self.results = None
        self.fit_nested()

    def fit_nested(self):

        # create bound arrays for generating samples
        nobs = len(self.lc_data)
        gfreekeys = list(self.global_bounds.keys())

        # if isinstance(self.local_bounds, dict):
        #     lfreekeys = list(self.local_bounds.keys())
        #     boundarray = np.vstack([ [self.global_bounds[k] for k in gfreekeys], [self.local_bounds[k] for k in lfreekeys]*nobs ])
        # else:
        #     # if list type
        lfreekeys = []
        boundarray = [self.global_bounds[k] for k in gfreekeys]
        for i in range(nobs):
            lfreekeys.append(list(self.local_bounds[i].keys()))
            boundarray.extend([self.local_bounds[i][k] for k in lfreekeys[-1]])
        boundarray = np.array(boundarray)

        # fit individual light curves to constrain priors
        if self.individual_fit:
            for i in range(nobs):

                print(f"Fitting individual light curve {i+1}/{nobs}")
                try:
                    mybounds = dict(**self.local_bounds[i], **self.global_bounds)
                except:
                    mybounds = {}
                    for k in self.local_bounds[i]:
                        mybounds[k] = self.local_bounds[i][k]
                    for k in self.global_bounds:
                        mybounds[k] = self.global_bounds[k]
                if 'per' in mybounds: del(mybounds['per'])
                if 'inc' in mybounds and 'rprs' in mybounds: del(mybounds['inc'])
                if 'tmid' in mybounds:
                    # find the closet mid transit time to the last observation
                    phase = (self.lc_data[i]['time'][-1] - self.lc_data[i]['priors']['tmid']) / self.lc_data[i]['priors']['per']
                    nepochs = np.round(phase)
                    newtmid = self.lc_data[i]['priors']['tmid'] + nepochs * self.lc_data[i]['priors']['per']
                    err = np.diff(mybounds['tmid'])[0]/2.
                    mybounds['tmid'] = [newtmid - err, newtmid + err ]

                # fit individual light curve
                myfit = lc_fitter(
                    self.lc_data[i]['time'],
                    self.lc_data[i]['flux'],
                    self.lc_data[i]['ferr'],
                    self.lc_data[i]['airmass'],
                    self.lc_data[i]['priors'],
                    mybounds
                )

                # check stdev_cutoff and residuals
                if myfit.res_stdev > self.stdev_cutoff:
                    print(f"WARNING: Stdev of residuals is large! {myfit.res_stdev:.3f} > {self.stdev_cutoff:.3f}")
                    #raise ValueError(f"Stdev of residuals is too large, please remove id: {self.lc_data[i]['name']}

                # copy data over for individual fits
                self.lc_data[i]['individual'] = myfit.parameters.copy()
                self.lc_data[i]['individual_err'] = myfit.errors.copy()
                self.lc_data[i]['res_stdev'] = myfit.res_stdev
                self.lc_data[i]['quality'] = myfit.quality

                ti = sum([len(self.local_bounds[k]) for k in range(i)])
                # update local priors
                for j, key in enumerate(self.local_bounds[i].keys()):

                    boundarray[j+ti+len(gfreekeys),0] = myfit.parameters[key] - 5*myfit.errors[key]
                    boundarray[j+ti+len(gfreekeys),1] = myfit.parameters[key] + 5*myfit.errors[key]

                    if key == 'rprs':
                        boundarray[j+ti+len(gfreekeys),0] = max(0,myfit.parameters[key] - 5*myfit.errors[key])

                # print name and stdev of residuals
                mint = np.min(self.lc_data[i]['time'])
                maxt = np.max(self.lc_data[i]['time'])
                try:
                    print(f"{self.lc_data[i]['name']} & {Time(mint,format='jd').isot} & {Time(maxt,format='jd').isot} & {np.std(myfit.residuals)} & {len(self.lc_data[i]['time'])}")
                except:
                    print(f"{self.lc_data[i]['name']} & {mint} & {maxt} & {np.std(myfit.residuals)} & {len(self.lc_data[i]['time'])}")

                del(myfit)

        # transform unit cube to prior volume
        bounddiff = np.diff(boundarray,1).reshape(-1)
        def prior_transform(upars):
            return (boundarray[:,0] + bounddiff*upars)

        def loglike(pars):
            chi2 = 0

            # for each light curve
            for i in range(nobs):

                # global keys
                for j, key in enumerate(gfreekeys):
                    self.lc_data[i]['priors'][key] = pars[j]

                # local keys
                ti = sum([len(self.local_bounds[k]) for k in range(i)])
                for j, key in enumerate(lfreekeys[i]):
                    self.lc_data[i]['priors'][key] = pars[j+ti+len(gfreekeys)]

                # compute model
                model = transit(self.lc_data[i]['time'], self.lc_data[i]['priors'])
                model *= airmass_trend(
                    self.lc_data[i]['priors'].get('a2', 0),
                    self.lc_data[i]['airmass'],
                )
                if has_explicit_flux_baseline(self.global_bounds) or has_explicit_flux_baseline(self.local_bounds[i]):
                    model *= get_flux_baseline(self.lc_data[i]['priors'])
                else:
                    model *= solve_flux_baseline(model, self.lc_data[i]['flux'], self.lc_data[i]['ferr'])

                # add to chi2
                chi2 += np.sum( ((self.lc_data[i]['flux']-model)/self.lc_data[i]['ferr'])**2 )

            # maximization metric for nested sampling
            return -0.5*chi2

        freekeys = []+gfreekeys
        for n in range(nobs):
            for k in lfreekeys[n]:
                #clean_name = self.lc_data[n].get('name', n).replace(' ','_').replace('(','').replace(')','').replace('[','').replace(']','').replace('-','_').split('-')[0]
                freekeys.append(f"local_{k}_{n}")

        sampler = ReactiveNestedSampler(freekeys, loglike, prior_transform)
        self.results = run_reactive_sampler(
            sampler,
            run_kwargs={"max_ncalls": int(1e6)},
            verbose=self.verbose,
        )

        self.quantiles = {}
        self.errors = {}
        self.parameters = self.lc_data[0]['priors'].copy()

        for i, key in enumerate(freekeys):
            self.parameters[key] = self.results['maximum_likelihood']['point'][i]
            #self.errors[key] = self.results['posterior']['median'][i]

            self.errors[key] = self.results['posterior']['stdev'][i]
            self.quantiles[key] = [
                self.results['posterior']['errlo'][i],
                self.results['posterior']['errup'][i]]

        # create an average Rp/Rs if it is not in global keys
        # check if 'rprs' is in lfreekeys
        rprs_in_local = False
        for i in range(nobs):
            if 'rprs' in lfreekeys[i]:
                rprs_in_local = True
                break

        if rprs_in_local:
            local_rprs = [] # used for creating an average value
            local_rprs_err = []

        # loop over observations
        for n in range(nobs):
            self.lc_data[n]['errors'] = {}
            
            # set global parameters without overwriting everything
            for gk in gfreekeys:
                self.lc_data[n]['priors'][gk] = self.parameters[gk]
                self.lc_data[n]['errors'][gk] = self.errors[gk]

            # loop over local keys and save best fit values
            for k in lfreekeys[n]:

                # create key to get results
                pkey = f"local_{k}_{n}"
                
                # overwrite priors with best fit value
                self.lc_data[n]['priors'][k] = self.parameters[pkey]
                self.lc_data[n]['errors'][k] = self.errors[pkey]

                # update key for final bestfit plot if needed
                if k == 'rprs':
                    local_rprs.append(self.lc_data[n]['priors'][k])
                    local_rprs_err.append(self.lc_data[n]['errors'][k])

            # solve for the local baseline flux scale
            model = transit(self.lc_data[n]['time'], self.lc_data[n]['priors'])
            airmass = airmass_trend(
                self.lc_data[n]['priors'].get('a2', 0),
                self.lc_data[n]['airmass'],
            )
            if has_explicit_flux_baseline(self.global_bounds) or has_explicit_flux_baseline(self.local_bounds[n]):
                flux_scale = get_flux_baseline(self.lc_data[n]['priors'])
                flux_scale_err = self.lc_data[n]['errors'].get('a0', self.lc_data[n]['errors'].get('a1', 0))
            else:
                flux_scale = solve_flux_baseline(model * airmass, self.lc_data[n]['flux'], self.lc_data[n]['ferr'])
                flux_scale_err = solve_flux_baseline_uncertainty(model * airmass, self.lc_data[n]['ferr'])
            self.lc_data[n]['priors']['a0'] = flux_scale
            self.lc_data[n]['priors']['a1'] = flux_scale
            self.lc_data[n]['errors']['a0'] = flux_scale_err
            self.lc_data[n]['errors']['a1'] = flux_scale_err
            self.lc_data[n]['residuals'] = self.lc_data[n]['flux'] - model * airmass * flux_scale
            self.lc_data[n]['detrend'] = self.lc_data[n]['flux'] / (airmass * flux_scale)

            # phase
            plot_time_range = normalize_time_range(self.lc_data[n].get('plot_time_range'))
            if plot_time_range is None:
                plot_time_range = normalize_time_range(self.lc_data[n]['time'])
            self.lc_data[n]['plot_time_range'] = plot_time_range
            self.lc_data[n]['phase'] = get_plot_phase(
                self.lc_data[n]['time'],
                self.lc_data[n]['priors']['per'],
                self.lc_data[n]['priors']['tmid'],
                plot_time_range,
            )
            self.lc_data[n]['time_upsample'] = np.linspace(plot_time_range[0], plot_time_range[1], 1000)
            self.lc_data[n]['phase_upsample'] = get_plot_phase(
                self.lc_data[n]['time_upsample'],
                self.lc_data[n]['priors']['per'],
                self.lc_data[n]['priors']['tmid'],
                plot_time_range,
            )
            self.lc_data[n]['transit_upsample'] = transit(self.lc_data[n]['time_upsample'], self.lc_data[n]['priors'])

        # create an average value from all the local fits, used for plotting final best fit
        if rprs_in_local:
            self.parameters['rprs'] = np.mean(local_rprs)
            self.errors['rprs'] = np.std(local_rprs)


    def plot_bestfits(self):
        nrows = len(self.lc_data)//4+1
        # make sure there isn't an extra row
        if len(self.lc_data)%4 == 0:
            nrows -= 1

        fig,ax = plt.subplots(nrows, 4, figsize=(5+5*nrows, 5*nrows))

        # turn off all axes
        for i in range(nrows*4):
            ri = int(i/4)
            ci = i%4
            if ax.ndim == 1:
                ax[i].axis('off')
            else:
                ax[ri,ci].axis('off')

        # cycle the colors and markers
        markers = cycle(['o','v','^','<','>','s','*','h','H','D','d','P','X'])
        colors = cycle(['black','blue','green','orange','purple','grey','magenta','cyan','lime'])

        # plot observations
        for i in range(len(self.lc_data)):
            ri = int(i/4)
            ci = i%4
            ncolor = next(colors)
            nmarker = next(markers)

            model = transit(self.lc_data[i]['time'], self.lc_data[i]['priors'])
            airmass = airmass_trend(
                self.lc_data[i]['priors'].get('a2', 0),
                self.lc_data[i]['airmass'],
            )
            detrend = self.lc_data[i]['flux'] / (model * airmass)

            if ax.ndim == 1:
                ax[i].axis('on')
                ax[i].errorbar(self.lc_data[i]['time'], self.lc_data[i]['flux']/airmass/detrend.mean(), yerr=self.lc_data[i]['ferr']/airmass/detrend.mean(), 
                                ls='none', marker=nmarker, color=ncolor, alpha=0.5, zorder=1)
                
                ax[i].plot(self.lc_data[i]['time_upsample'], self.lc_data[i]['transit_upsample'], 'r-', zorder=2)
                ax[i].set_xlabel("Time [BJD]", fontsize=14)
                ax[i].set_ylabel("Relative Flux", fontsize=14)
                ax[i].set_title(f"{self.lc_data[i].get('name','')}", fontsize=16)
            else:
                ax[ri,ci].axis('on')
                ax[ri,ci].errorbar(self.lc_data[i]['time'], self.lc_data[i]['flux']/airmass/detrend.mean(), yerr=self.lc_data[i]['ferr']/airmass/detrend.mean(), 
                                   ls='none', marker=nmarker, color=ncolor, alpha=0.5, zorder=1)
                ax[ri,ci].plot(self.lc_data[i]['time_upsample'], self.lc_data[i]['transit_upsample'], 'r-', zorder=2)
                ax[ri,ci].set_xlabel("Time[BJD]", fontsize=14)
                ax[ri,ci].set_ylabel("Relative Flux", fontsize=14)
                ax[ri,ci].set_title(f"{self.lc_data[i].get('name','')}", fontsize=16)

        plt.tight_layout()
        return fig

    def plot_bestfit(self, title="", bin_dt=30./(60*24), alpha=0.05, ylim_sigma=5, phase_limits='median', show_legend=True, limit_legend=False, show_individual_fits=False):
        """
        Plot the best fit model and residuals

        Parameters
        ----------
        title : str
            Title for the plot

        bin_dt : float
            Bin size for plotting the residuals

        alpha : float
            Alpha value for plotting the data

        ylim_sigma : float
            Number of sigma to plot the residuals

        phase_limits : str
            'median' or 'all' to set the phase limits

        show_legend : bool
            Show the legend

        limit_legend : bool
            Limit the legend to 3 entries
        """
        f = plt.figure(figsize=(15,12))
        f.subplots_adjust(top=0.92,bottom=0.09,left=0.1,right=0.98, hspace=0)
        ax_lc = plt.subplot2grid((4,5), (0,0), colspan=5,rowspan=3)
        ax_res = plt.subplot2grid((4,5), (3,0), colspan=5, rowspan=1)
        axs = [ax_lc, ax_res]

        axs[0].set_title(title, fontsize=18)
        axs[0].set_ylabel("Relative Flux", fontsize=14)
        axs[0].grid(True,ls='--')

        try:
            rprs2 = self.parameters['rprs']**2
            rprs2err = 2*self.parameters['rprs']*self.errors['rprs']
        except:
            rprs2 = self.lc_data[0]['priors']['rprs']**2
            rprs2err = 2*self.lc_data[0]['priors']['rprs']*self.lc_data[0]['errors']['rprs']

        rprs2_text, rprs2err_text = format_value_error_for_plot(rprs2, rprs2err)
        lclabel1 = r"$(R_{p}/R_{s})^{2}$ = %s $\pm$ %s" %(
            rprs2_text,
            rprs2err_text,
        )
        
        tmid_text, tmid_error_text = format_value_error_for_plot(
            self.parameters['tmid'],
            self.errors.get('tmid',0),
        )
        lclabel2 = r"$T_{mid}$ = %s $\pm$ %s BJD$_{TDB}$" %(
            tmid_text,
            tmid_error_text,
        )

        lclabel = lclabel1 + "\n" + lclabel2
        minp = 1
        maxp = 0

        min_std = 1
        # cycle the colors and markers
        markers = cycle(['o','v','^','<','>','s','*','h','H','D','d','P','X'])
        colors = cycle(['black','blue','green','orange','purple','grey','magenta','cyan','lime'])

        alldata = {
            'time': [],
            'phase': [],
            'flux': [],
            'detrend': [],
            'ferr': [],
            'residuals': [],
        }

        for n in range(len(self.lc_data)):
            ncolor = next(colors)
            nmarker = next(markers)
            alldata['time'].extend(self.lc_data[n]['time'].tolist())
            alldata['phase'].extend(self.lc_data[n]['phase'].tolist())
            alldata['detrend'].extend(self.lc_data[n]['detrend'].tolist())
            alldata['flux'].extend(self.lc_data[n]['flux'].tolist())
            alldata['ferr'].extend(self.lc_data[n]['ferr'].tolist())
            alldata['residuals'].extend(self.lc_data[n]['residuals'].tolist())
            
            phase = self.lc_data[n]['phase']
            si = np.argsort(phase)
            #bt2, br2, _ = time_bin(phase[si]*self.parameters['per'], self.lc_data[n]['residuals'][si]/np.median(self.lc_data[n]['flux'])*1e2, bin_dt)

            # plot data
            with np.errstate(divide='ignore', invalid='ignore'):
                normalized_uncertainties = np.abs(
                    np.asarray(self.lc_data[n].get('ferr'), dtype=float)
                    * np.asarray(self.lc_data[n]['detrend'], dtype=float)
                    / np.asarray(self.lc_data[n].get('flux'), dtype=float)
                )
            point_uncertainties = _pointwise_plot_uncertainties(
                self.lc_data[n]['detrend'],
                normalized_uncertainties,
                residuals=self.lc_data[n].get('residuals'),
                reference=self.lc_data[n].get('flux'),
            )
            axs[0].errorbar(phase, self.lc_data[n]['detrend'], yerr=point_uncertainties,
                            ls='none', marker=nmarker, color=ncolor, zorder=1, alpha=alpha)

            # plot residuals
            axs[1].plot(phase, self.lc_data[n]['residuals']/np.median(self.lc_data[n]['flux'])*1e2, color=ncolor, marker=nmarker, ls='none',
                         alpha=0.2)

            # plot binned data
            bt2, bf2, bs = time_bin(phase[si]*self.lc_data[n]['priors']['per'], self.lc_data[n]['detrend'][si], bin_dt)

            if limit_legend:
                axs[0].errorbar(bt2/self.lc_data[n]['priors']['per'],bf2,yerr=bs,alpha=1,zorder=2,color=ncolor,ls='none',marker=nmarker)
            else:
                axs[0].errorbar(bt2/self.lc_data[n]['priors']['per'],bf2,yerr=bs,alpha=1,zorder=2,color=ncolor,ls='none',marker=nmarker,
                                label=r'{}: {:.2f} %'.format(self.lc_data[n].get('name',''),np.std(self.lc_data[n]['residuals']/np.median(self.lc_data[n]['flux'])*1e2)))

            # replace min and max for upsampled lc model
            minp = min(minp, min(self.lc_data[n]['phase_upsample']))
            maxp = max(maxp, max(self.lc_data[n]['phase_upsample']))
            min_std = min(min_std, np.std(self.lc_data[n]['residuals']/np.median(self.lc_data[n]['flux'])))

            # plot individual best fit models
            if show_individual_fits:
                axs[0].plot(self.lc_data[n]['phase_upsample'], self.lc_data[n]['transit_upsample'], color=ncolor, zorder=3, alpha=0.5)

        # create binned plot for all the data
        for k in alldata.keys():
            alldata[k] = np.array(alldata[k])
            
        phase = alldata['phase']
        si = np.argsort(phase)
        bt, br, _ = time_bin(phase[si]*self.parameters['per'], alldata['residuals'][si]/np.median(alldata['flux']), 2*bin_dt)
        bt, bf, bs = time_bin(phase[si]*self.parameters['per'], alldata['detrend'][si], 2*bin_dt)

        axs[0].errorbar(bt/self.parameters['per'],bf,yerr=bs,alpha=1,zorder=2,color='white',ls='none',marker='o',ms=15,
                        markeredgecolor='black',
                        ecolor='black',
                        label=r'Binned Data: {:.2f} %'.format(np.std(br)*1e2))

        axs[1].plot(bt/self.parameters['per'],br*1e2,color='white',ls='none',marker='o',ms=11,markeredgecolor='black')

        # best fit model
        self.phase_upsample = np.linspace(minp, maxp, 10000)
        self.time_upsample = self.parameters['tmid'] + self.phase_upsample * self.parameters['per']
        self.transit_upsample = transit(self.time_upsample, self.parameters)
        axs[0].plot(self.phase_upsample, self.transit_upsample, 'r-', zorder=3, label=lclabel, lw=3)

        # set up axes limits
        axs[0].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
        axs[0].set_xlabel("Phase ", fontsize=14)
        axs[0].set_ylim([1-self.parameters['rprs']**2-ylim_sigma*min_std, 1+ylim_sigma*min_std])
        axs[1].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
        axs[1].set_xlabel("Phase", fontsize=14)
        axs[1].set_ylim(residual_plot_limits(np.concatenate([
            lc['residuals'] / np.median(lc['flux']) * 1e2 for lc in self.lc_data
        ])))

        # compute average min and max for all the data
        mins = []; maxs = []
        for n in range(len(self.lc_data)):
            mins.append(min(self.lc_data[n]['phase_upsample']))
            maxs.append(max(self.lc_data[n]['phase_upsample']))

        # set up phase limits
        if isinstance(phase_limits, str):
            if phase_limits == "minmax":
                axs[0].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
                axs[1].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
            elif phase_limits == "median":
                axs[0].set_xlim([np.median(mins), np.median(maxs)])
                axs[1].set_xlim([np.median(mins), np.median(maxs)])
            else:
                axs[0].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
                axs[1].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
        elif isinstance(phase_limits, list):
            axs[0].set_xlim([phase_limits[0], phase_limits[1]])
            axs[1].set_xlim([phase_limits[0], phase_limits[1]])
        elif isinstance(phase_limits, tuple):
            axs[0].set_xlim([phase_limits[0], phase_limits[1]])
            axs[1].set_xlim([phase_limits[0], phase_limits[1]])
        else:
            axs[0].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
            axs[1].set_xlim([min(self.phase_upsample), max(self.phase_upsample)])

        axs[0].get_xaxis().set_visible(False)
        if _add_differential_hours_axis(axs[1], self.parameters.get('per')) is not None:
            f.subplots_adjust(hspace=0.55)
        axs[1].set_ylabel("Residuals [%]", fontsize=14)
        axs[1].grid(True,ls='--',axis='y')
    
        if show_legend:
            axs[0].legend(loc='best',ncol=len(self.lc_data)//7+1)
    
        return f,axs

    def plot_stack(self, title="", bin_dt=30./(60*24), dy=0.02):
        f, ax = plt.subplots(1,figsize=(9,12))
        
        ax.set_title(title)
        ax.set_ylabel("Relative Flux", fontsize=14)
        ax.grid(True,ls='--')

        rprs2 = self.parameters['rprs']**2
        rprs2err = 2*self.parameters['rprs']*self.errors['rprs']
        rprs2_text, rprs2err_text = format_value_error_for_plot(rprs2, rprs2err)
        lclabel1 = r"$(R_{p}/R_{s})^{2}$ = %s $\pm$ %s" %(
            rprs2_text,
            rprs2err_text,
        )
        
        tmid_text, tmid_error_text = format_value_error_for_plot(
            self.parameters['tmid'],
            self.errors.get('tmid',0),
        )
        lclabel2 = r"$T_{mid}$ = %s $\pm$ %s BJD$_{TDB}$" %(
            tmid_text,
            tmid_error_text,
        )

        lclabel = lclabel1 + "\n" + lclabel2
        minp = 1
        maxp = 0

        min_std = 1
        # cycle the colors and markers
        markers = cycle(['o','v','^','<','>','s','*','h','H','D','d','P','X'])
        colors = cycle(['black','blue','green','orange','purple','grey','magenta','cyan','lime'])
        for n in range(len(self.lc_data)):
            ncolor = next(colors)
            nmarker = next(markers)

            phase = self.lc_data[n]['phase']
            si = np.argsort(phase)
            bt2, br2, _ = time_bin(phase[si]*self.parameters['per'], self.lc_data[n]['residuals'][si]/np.median(self.lc_data[n]['flux'])*1e2, bin_dt)
            
            # plot data
            with np.errstate(divide='ignore', invalid='ignore'):
                normalized_uncertainties = np.abs(
                    np.asarray(self.lc_data[n].get('ferr'), dtype=float)
                    * np.asarray(self.lc_data[n]['detrend'], dtype=float)
                    / np.asarray(self.lc_data[n].get('flux'), dtype=float)
                )
            point_uncertainties = _pointwise_plot_uncertainties(
                self.lc_data[n]['detrend'],
                normalized_uncertainties,
                residuals=self.lc_data[n].get('residuals'),
                reference=self.lc_data[n].get('flux'),
            )
            ax.errorbar(phase, self.lc_data[n]['detrend']-n*dy, yerr=point_uncertainties,
                            ls='none', marker=nmarker, color=ncolor, zorder=1, alpha=0.25)
        
            # plot binned data
            bt2, bf2, bs = time_bin(phase[si]*self.lc_data[n]['priors']['per'], self.lc_data[n]['detrend'][si]-n*dy, bin_dt)
            ax.errorbar(bt2/self.lc_data[n]['priors']['per'],bf2,yerr=bs,alpha=1,zorder=2,color=ncolor,ls='none',marker=nmarker)

            # replace min and max for upsampled lc model
            minp = min(minp, min(self.lc_data[n]['phase_upsample']))
            maxp = max(maxp, max(self.lc_data[n]['phase_upsample']))
            min_std = min(min_std, np.std(self.lc_data[n]['residuals']/np.median(self.lc_data[n]['flux'])))

            # best fit model
            self.phase_upsample = np.linspace(minp, maxp, 10000)
            self.time_upsample = self.parameters['tmid'] + self.phase_upsample * self.parameters['per']
            self.transit_upsample = transit(self.time_upsample, self.parameters)
            ax.plot(self.phase_upsample, self.transit_upsample-n*dy, ls='-', color=ncolor, zorder=3, label=self.lc_data[n].get('name',''))

        ax.set_xlim([min(self.phase_upsample), max(self.phase_upsample)])
        ax.set_xlabel("Phase ", fontsize=14)
        ax.set_ylim([1-self.parameters['rprs']**2-5*min_std-n*dy, 1+5*min_std])
        ax.get_xaxis().set_visible(False)
        ax.legend(loc='best')
        return f,ax


if __name__ == "__main__":

    prior = {
        'rprs': 0.02,  # Rp/Rs
        'ars': 14.25,  # a/Rs
        'per': 3.33,  # Period [day]
        'inc': 88.5,  # Inclination [deg]
        'u0': 0, 'u1': 0, 'u2': 0, 'u3': 0,  # limb darkening (nonlinear)
        'ecc': 0.5,  # Eccentricity
        'omega': 120,  # Arg of periastron
        'tmid': 0.75,  # Time of mid transit [day],
        'a0': 50,  # Baseline flux normalization
        'a2': 0.,  # trend = a0 * np.exp(a2 * (airmass - mean(airmass)))

        'teff': 5000,
        'tefferr': 50,
        'met': 0,
        'meterr': 0,
        'logg': 3.89,
        'loggerr': 0.01
    }

    # example generating LD coefficients
    from pylightcurve import exotethys

    u0, u1, u2, u3 = exotethys(prior['logg'], prior['teff'], prior['met'], 'TESS', method='claret',
                               stellar_model='phoenix')

    prior['u0'], prior['u1'], prior['u2'], prior['u3'] = u0, u1, u2, u3

    time = np.linspace(0.7, 0.8, 1000)  # [day]

    # simulate extinction from airmass
    stime = time - time[0]
    alt = 90 * np.cos(4 * stime - np.pi / 6)
    # airmass = 1./np.cos(np.deg2rad(90-alt))
    airmass = np.zeros(time.shape[0])

    # GENERATE NOISY DATA
    data = transit(time, prior) * prior['a0'] * airmass_trend(prior['a2'], airmass)
    data += np.random.normal(0, prior['a0'] * 250e-6, len(time))
    dataerr = np.random.normal(300e-6, 50e-6, len(time)) + np.random.normal(300e-6, 50e-6, len(time))

    # add bounds for free parameters only
    mybounds = {
        'rprs': [0, 0.1],
        'tmid': [prior['tmid'] - 0.01, prior['tmid'] + 0.01],
        'ars': [13, 15],
        # 'a0': [0.95 * prior['a0'], 1.05 * prior['a0']],  # optional explicit baseline offset
        # 'a2': [0, 0.3] # uncomment if you want to fit for airmass
        # if a0 is omitted, the normalization is solved analytically during the fit
        # never list both 'a0' and 'a1' in bounds because they are the same scale term
    }

    myfit = lc_fitter(time, data, dataerr, airmass, prior, mybounds, mode='ns')

    for k in myfit.bounds.keys():
        print(f"{myfit.parameters[k]:.6f} +- {myfit.errors[k]}")

    fig, axs = myfit.plot_bestfit()
    plt.tight_layout()
    plt.show()

    fig = myfit.plot_triangle()
    plt.tight_layout()
    plt.show()
