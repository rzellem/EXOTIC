# ########################################################################### #
#    Copyright (c) 2019-2020, California Institute of Technology.
#    All rights reserved.  Based on Government Sponsored Research under
#    contracts NNN12AA01C, NAS7-1407 and/or NAS7-03001.
#
#    Redistribution and use in source and binary forms, with or without
#    modification, are permitted provided that the following conditions
#    are met:
#      1. Redistributions of source code must retain the above copyright
#         notice, this list of conditions and the following disclaimer.
#      2. Redistributions in binary form must reproduce the above copyright
#         notice, this list of conditions and the following disclaimer in
#         the documentation and/or other materials provided with the
#         distribution.
#      3. Neither the name of the California Institute of
#         Technology (Caltech), its operating division the Jet Propulsion
#         Laboratory (JPL), the National Aeronautics and Space
#         Administration (NASA), nor the names of its contributors may be
#         used to endorse or promote products derived from this software
#         without specific prior written permission.
#
#    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE CALIFORNIA
#    INSTITUTE OF TECHNOLOGY BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
#    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
#    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
#    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
#    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# ########################################################################### #
#    EXOplanet Transit Interpretation Code (EXOTIC)
#    # NOTE: See companion file version.py for version info.
# ########################################################################### #
import ldtk
from ldtk.ldmodel import LinearModel, QuadraticModel, NonlinearModel
import lmfit as lm
import logging
import matplotlib.pyplot as plt
import numpy as np
import os
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import quote
from urllib.parse import unquote

import requests

log = logging.getLogger(__name__)

_LDTK_HTTP_FALLBACK_BASE_URLS = (
    "https://ftp.gwdg.de/pub/misc/phoenix",
    "https://downloads.nextastro.org/PHOENIX",
)
_LDTK_HTTP_FALLBACK_ENV = "EXOTIC_LDTK_FALLBACK_BASE_URL"
_LDTK_DOWNLOAD_TIMEOUT = (10, 120)
_LDTK_INDEX_TIMEOUT = (10, 60)
_LDTK_ORIGINAL_GET_SERVER_FILE_LIST = None
_LDTK_ORIGINAL_DOWNLOAD_UNCACHED_FILES = None


class LDPSet(ldtk.LDPSet):
    """
    A. NIESSNER: INLINE HACK TO ldtk.LDPSet
    """
    @staticmethod
    def is_mime(): return True

    @property
    def profile_mu(self): return self._mu
    pass


setattr(ldtk, 'LDPSet', LDPSet)
setattr(ldtk.ldtk, 'LDPSet', LDPSet)


def _ldtk_http_fallback_base_urls():
    configured_urls = os.environ.get(_LDTK_HTTP_FALLBACK_ENV)
    if configured_urls is None:
        return [url.rstrip("/") for url in _LDTK_HTTP_FALLBACK_BASE_URLS]
    return [url.strip().rstrip("/") for url in configured_urls.split(",") if url.strip()]


def _quote_url_path(*parts):
    segments = []
    for part in parts:
        segments.extend(segment for segment in str(part).strip("/").split("/") if segment)
    return "/".join(quote(segment, safe="") for segment in segments)


def _ldtk_http_fallback_url(base_url, client, ldtk_file):
    path = _quote_url_path(client.edir, ldtk_file._zstr, ldtk_file.name)
    return f"{base_url}/{path}"


def _ldtk_http_fallback_index_url(base_url, *parts):
    path = _quote_url_path(*parts)
    if path:
        return f"{base_url}/{path}/"
    return f"{base_url}/"


class _HrefParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.hrefs = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        for name, value in attrs:
            if name.lower() == "href" and value:
                self.hrefs.append(value)
                return


def _http_index_names(url):
    response = requests.get(url, timeout=_LDTK_INDEX_TIMEOUT)
    try:
        response.raise_for_status()
        parser = _HrefParser()
        parser.feed(response.text)
    finally:
        response.close()

    names = []
    for href in parser.hrefs:
        href = unquote(href.split("?", 1)[0].split("#", 1)[0]).strip("/")
        if not href or href in (".", "..") or "/" in href:
            continue
        names.append(href)
    return names


def _get_ldtk_server_file_list_from_http_mirror(client, base_url):
    root_url = _ldtk_http_fallback_index_url(base_url, client.edir)
    zdirs = sorted(name for name in _http_index_names(root_url) if ".txt" not in name.lower())
    if not zdirs:
        raise RuntimeError(f"No PHOENIX metallicity directories found at {root_url}")

    log.warning(
        "Trying PHOENIX HTTP fallback index at %s for %d metallicity directories.",
        base_url,
        len(zdirs),
    )

    files_in_server = {}
    for zdir in zdirs:
        zdir_url = _ldtk_http_fallback_index_url(base_url, client.edir, zdir)
        files_in_server[zdir] = sorted(
            name for name in _http_index_names(zdir_url) if ".txt" not in name.lower()
        )
    return files_in_server


def _get_ldtk_server_file_list_from_http(client):
    base_urls = _ldtk_http_fallback_base_urls()
    if not base_urls:
        raise RuntimeError(
            f"LDTk FTP file listing failed and {_LDTK_HTTP_FALLBACK_ENV} is empty, "
            "so EXOTIC cannot try the HTTP PHOENIX fallback."
        )

    log.warning(
        "LDTk FTP file listing failed; trying PHOENIX HTTP fallback mirrors in order: %s",
        ", ".join(base_urls),
    )

    last_error = None
    for base_url in base_urls:
        try:
            return _get_ldtk_server_file_list_from_http_mirror(client, base_url)
        except Exception as mirror_error:
            last_error = mirror_error
            log.warning("PHOENIX HTTP fallback index failed at %s: %s", base_url, mirror_error)

    raise RuntimeError("All PHOENIX HTTP fallback indexes failed.") from last_error


def _download_file(url, local_path):
    local_path = Path(local_path)
    local_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = local_path.with_name(f"{local_path.name}.download")
    try:
        response = requests.get(url, stream=True, timeout=_LDTK_DOWNLOAD_TIMEOUT)
        try:
            response.raise_for_status()
            with open(temporary_path, "wb") as local_file:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        local_file.write(chunk)
        finally:
            response.close()
        os.replace(temporary_path, local_path)
    except Exception:
        if temporary_path.exists():
            temporary_path.unlink()
        raise


def _ldtk_files_to_download(client, force=False):
    return [ldtk_file for ldtk_file in client.files if force or not ldtk_file.local_exists]


def _download_ldtk_uncached_files_from_http_mirror(client, base_url, force=False):
    files_to_download = _ldtk_files_to_download(client, force=force)
    if not files_to_download:
        return False

    log.warning(
        "Trying PHOENIX HTTP fallback at %s for %d file(s).",
        base_url,
        len(files_to_download),
    )

    downloaded_paths = []
    for ldtk_file in files_to_download:
        url = _ldtk_http_fallback_url(base_url, client, ldtk_file)
        _download_file(url, ldtk_file.local_path)
        downloaded_paths.append(ldtk_file.local_path)
        if client.not_cached > 0 and not force:
            client.not_cached -= 1

    if client.check_file_corruption(downloaded_paths):
        raise RuntimeError("Downloaded PHOENIX files failed LDTk's FITS corruption check.")
    return False


def _download_ldtk_uncached_files_from_http(client, force=False):
    base_urls = _ldtk_http_fallback_base_urls()
    if not base_urls:
        raise RuntimeError(
            f"LDTk FTP download failed and {_LDTK_HTTP_FALLBACK_ENV} is empty, "
            "so EXOTIC cannot try the HTTP PHOENIX fallback."
        )

    log.warning(
        "LDTk FTP download failed; trying PHOENIX HTTP fallback mirrors in order: %s",
        ", ".join(base_urls),
    )

    last_error = None
    for base_url in base_urls:
        try:
            return _download_ldtk_uncached_files_from_http_mirror(client, base_url, force=force)
        except Exception as mirror_error:
            last_error = mirror_error
            log.warning("PHOENIX HTTP fallback mirror failed at %s: %s", base_url, mirror_error)

    raise RuntimeError("All PHOENIX HTTP fallback mirrors failed.") from last_error


def _install_ldtk_http_fallback():
    global _LDTK_ORIGINAL_GET_SERVER_FILE_LIST
    global _LDTK_ORIGINAL_DOWNLOAD_UNCACHED_FILES

    try:
        from ldtk.client import Client
    except Exception:
        return

    if not getattr(Client.get_server_file_list, "_exotic_http_fallback", False):
        _LDTK_ORIGINAL_GET_SERVER_FILE_LIST = Client.get_server_file_list

        def get_server_file_list_with_http_fallback(self):
            try:
                return _LDTK_ORIGINAL_GET_SERVER_FILE_LIST(self)
            except Exception as ftp_error:
                try:
                    log.warning("LDTk FTP file listing failed with %s", ftp_error)
                    return _get_ldtk_server_file_list_from_http(self)
                except Exception as fallback_error:
                    raise RuntimeError(
                        "LDTk could not list PHOENIX files from the default FTP server "
                        "or the EXOTIC HTTP fallback."
                    ) from fallback_error

        get_server_file_list_with_http_fallback._exotic_http_fallback = True
        Client.get_server_file_list = get_server_file_list_with_http_fallback

    if getattr(Client.download_uncached_files, "_exotic_http_fallback", False):
        return

    _LDTK_ORIGINAL_DOWNLOAD_UNCACHED_FILES = Client.download_uncached_files

    def download_uncached_files_with_http_fallback(self, force=False):
        try:
            return _LDTK_ORIGINAL_DOWNLOAD_UNCACHED_FILES(self, force=force)
        except Exception as ftp_error:
            try:
                log.warning("LDTk FTP download failed with %s", ftp_error)
                return _download_ldtk_uncached_files_from_http(self, force=force)
            except Exception as fallback_error:
                raise RuntimeError(
                    "LDTk could not download PHOENIX files from the default FTP server "
                    "or the EXOTIC HTTP fallback."
                ) from fallback_error

    download_uncached_files_with_http_fallback._exotic_http_fallback = True
    Client.download_uncached_files = download_uncached_files_with_http_fallback


_install_ldtk_http_fallback()


def createldgrid(minmu, maxmu, orbp,
                 ldmodel='nonlinear', phoenixmin=1e-1,
                 segmentation=int(10), verbose=False):
    """
    G. ROUDIER: Wrapper around LDTK downloading tools
    LDTK: Parviainen et al. https://github.com/hpparvi/ldtk
    """
    tstar = orbp['T*']
    terr = np.sqrt(abs(orbp['T*_uperr']*orbp['T*_lowerr']))
    fehstar = orbp['FEH*']
    feherr = np.sqrt(abs(orbp['FEH*_uperr']*orbp['FEH*_lowerr']))
    loggstar = orbp['LOGG*']
    loggerr = np.sqrt(abs(orbp['LOGG*_uperr']*orbp['LOGG*_lowerr']))
    log.warning(f">-- Temperature: {tstar} +/- {terr}")
    log.warning(f">-- Metallicity: {fehstar} +/- {feherr}")
    log.warning(f">-- Surface Gravity: {loggstar} +/- {loggerr}")
    niter = int(len(minmu)/segmentation) + 1
    allcl = None
    allel = None
    out = {}
    hybrid4_profiles = []
    avmu = [np.mean([mm, xm]) for mm, xm in zip(minmu, maxmu)]
    for i in np.arange(niter):
        loweri = i*segmentation
        upperi = (i+1)*segmentation
        if i == (niter-1):
            upperi = len(avmu)
        munm = 1e3*np.array(avmu[loweri:upperi])
        munmmin = 1e3*np.array(minmu[loweri:upperi])
        munmmax = 1e3*np.array(maxmu[loweri:upperi])
        filters = [ldtk.BoxcarFilter(str(mue), mun, mux)
                   for mue, mun, mux in zip(munm, munmmin, munmmax)]
        sc = ldtk.LDPSetCreator(teff=(tstar, terr), logg=(loggstar, loggerr),
                           z=(fehstar, feherr), filters=filters)
        ps = sc.create_profiles(nsamples=int(1e4))
        itpfail = False
        for testprof in ps.profile_averages:
            if np.all(~np.isfinite(testprof)):
                itpfail = True
            pass
        nfail = 1e0
        while itpfail:
            nfail *= 2
            sc = ldtk.LDPSetCreator(teff=(tstar, nfail*terr), logg=(loggstar, loggerr),
                               z=(fehstar, feherr), filters=filters)
            ps = sc.create_profiles(nsamples=int(1e4))
            itpfail = False
            for testprof in ps.profile_averages:
                if np.all(~np.isfinite(testprof)):
                    itpfail = True
                pass
            pass
        cl, el = ldx(ps.profile_mu, ps.profile_averages, ps.profile_uncertainties,
                     mumin=phoenixmin, debug=verbose, model=ldmodel)
        if ldmodel == 'nonlinear':
            try:
                from .hybrid_ld import fit_hybrid4_profiles
            except ImportError:
                from hybrid_ld import fit_hybrid4_profiles
            try:
                shared_profiles = fit_hybrid4_profiles(
                    ps.profile_mu, ps.profile_averages, ps.profile_uncertainties,
                    mumin=phoenixmin,
                )
            except Exception as exc:
                log.exception('hybrid4 atmosphere fit failed: %s', exc)
                shared_profiles = [
                    {'status': 'failed', 'reason': str(exc), 'error_type': type(exc).__name__}
                    for _ in cl
                ]
            for profile, lower, upper, coefficients, errors in zip(
                shared_profiles, munmmin, munmmax, cl, el,
            ):
                profile['wavelength_min_nm'] = float(lower)
                profile['wavelength_max_nm'] = float(upper)
                profile['stellar_parameters'] = dict(orbp)
                profile['claret_coefficients'] = np.asarray(coefficients, dtype=float).tolist()
                profile['claret_coefficient_errors'] = np.asarray(errors, dtype=float).tolist()
                profile['claret_profile_fit_constraint'] = 'gamma4 = 1 - gamma1 - gamma2 - gamma3 (existing Claret fit)'
            hybrid4_profiles.extend(shared_profiles)
        if allcl is None:
            allcl = cl
        else:
            allcl = np.concatenate((allcl, cl), axis=0)
        if allel is None:
            allel = el
        else:
            allel = np.concatenate((allel, el), axis=0)
        pass
    allel[allel > 1.] = 0.
    allel[~np.isfinite(allel)] = 0.
    out['MU'] = avmu
    out['LD'] = allcl.T
    out['ERR'] = allel.T
    out['HYBRID4_PROFILES'] = hybrid4_profiles
    for i in range(0, len(allcl.T)):
        ld_value = np.ravel(np.asarray(allcl.T[i], dtype=float))
        err_value = np.ravel(np.asarray(allel.T[i], dtype=float))
        if ld_value.size == 0 or err_value.size == 0:
            continue
        log.warning(f">-- LD{int(i)}: {float(ld_value[0])} +/- {float(err_value[0])}")
        pass
    return out


def ldx(psmu, psmean, psstd, mumin=1e-1, debug=False, model='nonlinear'):
    """
    G. ROUDIER: Limb darkening coefficient retrievial on PHOENIX GRID models,
    OPTIONAL mumin set up on HAT-P-41 stellar class
    """
    mup = np.array(psmu).copy()
    prfs = np.array(psmean).copy()
    sprfs = np.array(psstd).copy()
    nwave = prfs.shape[0]
    select = (mup > mumin)
    fitmup = mup[select]
    fitprfs = prfs[:, select]
    fitsprfs = sprfs[:, select]
    cl = []
    el = []
    params = lm.Parameters()
    params.add('gamma1', value=1e-1)
    params.add('gamma2', value=5e-1)
    params.add('gamma3', value=1e-1)
    params.add('gamma4', expr='1 - gamma1 - gamma2 - gamma3')

    if debug:
        plt.figure()
    for iwave in np.arange(nwave):
        select = fitsprfs[iwave] == 0e0
        if True in select:
            fitsprfs[iwave][select] = 1e-10
        if model == 'linear':
            params['gamma1'].value = 0
            params['gamma1'].vary = False
            params['gamma3'].value = 0
            params['gamma3'].vary = False
            params['gamma4'].value = 0
            params['gamma4'].vary = False
            out = lm.minimize(ln_ldx, params,
                              args=(fitmup, fitprfs[iwave], fitsprfs[iwave]))
            cl.append([out.params['gamma1'].value])
            el.append([out.params['gamma1'].stderr])
            pass
        if model == 'quadratic':
            params['gamma1'].value = 0
            params['gamma1'].vary = False
            params['gamma3'].value = 0
            params['gamma3'].vary = False
            out = lm.minimize(qd_ldx, params,
                              args=(mup, prfs[iwave], sprfs[iwave]))
            cl.append([out.params['gamma2'].value, out.params['gamma4'].value])
            el.append([out.params['gamma2'].stderr, out.params['gamma4'].stderr])
            pass
        if model == 'nonlinear':
            out = lm.minimize(nl_ldx, params,
                              args=(fitmup, fitprfs[iwave], fitsprfs[iwave]))
            cl.append([out.params['gamma1'].value, out.params['gamma2'].value,
                       out.params['gamma3'].value, out.params['gamma4'].value])
            el.append([out.params['gamma1'].stderr, out.params['gamma2'].stderr,
                       out.params['gamma3'].stderr, out.params['gamma4'].stderr])
            pass
        if debug:
            plt.plot(mup, prfs[iwave], 'k^')
            plt.errorbar(fitmup, fitprfs[iwave], yerr=fitsprfs[iwave], ls='None')
            if model == 'linear':
                plt.plot(fitmup, ln_ldx(out.params, fitmup))
            if model == 'quadratic':
                plt.plot(fitmup, qd_ldx(out.params, fitmup))
            if model == 'nonlinear':
                plt.plot(fitmup, nl_ldx(out.params, fitmup))
            pass
        pass
    if debug:
        plt.ylabel('$I(\\mu)$')
        plt.xlabel('$\\mu$')
        plt.title(model)
        plt.show()
        pass
    return np.array(cl), np.array(el)


def ln_ldx(params, x, data=None, weights=None):
    """
    G. ROUDIER: Linear law
    """
    gamma1 = params['gamma1'].value
    model = LinearModel.evaluate(x, np.array(gamma1))
    if data is None:
        return model
    if weights is None:
        return data - model
    return (data - model)/weights


def qd_ldx(params, x, data=None, weights=None):
    """
    G. ROUDIER: Quadratic law
    """
    gamma1 = params['gamma2'].value
    gamma2 = params['gamma4'].value
    model = QuadraticModel.evaluate(x, np.array((gamma1, gamma2)))
    if data is None:
        return model
    if weights is None:
        return data - model
    return (data - model)/weights


def nl_ldx(params, x, data=None, weights=None):
    """
    G. ROUDIER: Non Linear law
    """
    gamma1 = params['gamma1'].value
    gamma2 = params['gamma2'].value
    gamma3 = params['gamma3'].value
    gamma4 = params['gamma4'].value
    model = NonlinearModel.evaluate(x, np.array((gamma1, gamma2, gamma3, gamma4)))
    if data is None:
        return model
    if weights is None:
        return data - model
    return (data - model)/weights
