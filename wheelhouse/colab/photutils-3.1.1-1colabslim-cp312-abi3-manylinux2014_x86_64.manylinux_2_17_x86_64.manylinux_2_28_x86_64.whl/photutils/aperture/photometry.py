# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Tools for performing aperture photometry.
"""

from functools import cached_property

import astropy.units as u
import numpy as np
from astropy.nddata import NDData
from astropy.table import QTable

from photutils.aperture._common import (SCALAR_COLLAPSE_TYPES,
                                        collapse_scalar_value, unpack_nddata,
                                        validate_array, validate_mask_method)
from photutils.aperture._segmentation import process_segmentation_inputs
from photutils.aperture.core import (Aperture, SkyAperture, _aperture_metadata,
                                     _update_method_subpixels_docstring)
from photutils.aperture.flags import decode_aperture_flags
from photutils.aperture.region_converters import region_to_aperture
from photutils.utils._deprecation import (create_empty_deprecated_qtable,
                                          deprecated_positional_kwargs)
from photutils.utils._misc import _get_meta
from photutils.utils._parameters import validate_table_columns
from photutils.utils._quantity_helpers import process_quantities
from photutils.utils._repr import make_repr

__all__ = ['AperturePhotometry', 'aperture_photometry']


# Remove in 4.0
_DEPRECATED_COLUMNS: dict = {
    'xcenter': 'x_center',
    'ycenter': 'y_center',
}


# Public attributes that are never collapsed to a scalar for a scalar
# instance because they are not per-position output values (see
# ``AperturePhotometry.__getattribute__``). ``segmentation_image`` and
# ``labels`` are the inputs echoed back to the user, and the others
# describe the whole object. Any new public attribute that is a list,
# tuple, ndarray, or SkyCoord but is not a per-position value must be
# added here, otherwise a length-1 value will be silently collapsed to
# its first element for a scalar instance.
_SCALAR_EXCLUDE = frozenset({'default_columns', 'isscalar', 'labels',
                             'n_positions', 'segmentation_image'})


@_update_method_subpixels_docstring
class AperturePhotometry:
    # numpydoc ignore: PR01,PR02,PR04,PR07
    """
    Class to perform aperture photometry on 2D data.

    This class sums the (weighted) input ``data`` values within the
    given aperture(s) and provides the aperture fluxes, uncertainties,
    unmasked overlap areas, and bitwise quality flags as lazily-computed
    attributes. Use `to_table` to obtain the results as an
    `~astropy.table.QTable`.

    Note that this class returns the sum of the (weighted) input
    ``data`` values within the aperture. It does not convert data in
    surface brightness units to flux or counts. Conversion from
    surface-brightness units should be performed before using this
    class.

    Parameters
    ----------
    data : array_like, `~astropy.units.Quantity`, `~astropy.nddata.NDData`
        The 2D array on which to perform photometry. ``data`` should be
        background-subtracted. If ``data`` is a `~astropy.units.Quantity`
        array, then ``error`` (if input) must also be a
        `~astropy.units.Quantity` array with the same units. Nonfinite
        ``data`` values (NaN and inf) are automatically masked. See the
        Notes section below for more information about
        `~astropy.nddata.NDData` input.

    apertures : `~photutils.aperture.Aperture`, supported `regions.Region`, \
        list of `~photutils.aperture.Aperture` or `regions.Region`
        The aperture(s) to use for the photometry. If ``apertures`` is
        a list of `~photutils.aperture.Aperture` or `regions.Region`,
        then they all must have the same position(s). A tuple or
        `~numpy.ndarray` of them is also accepted. The list must not
        be empty. If ``apertures`` contains a
        `~photutils.aperture.SkyAperture` or `~regions.SkyRegion`
        object, then a WCS must be input using the ``wcs`` keyword.
        Region objects are converted to aperture objects.

    error : array_like or `~astropy.units.Quantity`, optional
        The pixel-wise Gaussian 1-sigma errors of the input
        ``data``. ``error`` is assumed to include *all* sources
        of error, including the Poisson error of the sources (see
        `~photutils.utils.calc_total_error`). ``error`` must have the
        same shape as the input ``data``. If a `~astropy.units.Quantity`
        array, then ``data`` must also be a `~astropy.units.Quantity`
        array with the same units.

    mask : array_like (bool), optional
        A boolean mask with the same shape as ``data`` where a `True`
        value indicates the corresponding element of ``data`` is masked.
        Masked data are excluded from all calculations. Nonfinite
        values (NaN and inf) in the input ``data`` are automatically
        masked.

    wcs : WCS object, optional
        A world coordinate system (WCS) transformation that
        supports the `astropy shared interface for WCS
        <https://docs.astropy.org/en/stable/wcs/wcsapi.html>`_ (e.g.,
        `astropy.wcs.WCS`, `gwcs.wcs.WCS`). If provided, the `sky_center`
        attribute and the ``'sky_center'`` column of `to_table` will
        contain the sky coordinates of the input aperture center(s).
        This keyword is required if the input ``apertures`` contains a
        `SkyAperture` or `~regions.SkyRegion`.

    <method_subpixels_descriptions>

    <segmentation_descriptions>

    n_threads : int, optional
        The number of threads to use to compute the aperture sums.
        The default is 1 (no multithreading). When ``n_threads`` > 1,
        the aperture positions are divided into chunks and processed
        concurrently. The per-position results are independent, so
        they are identical to the single-threaded computation. The
        underlying kernels release the Python global interpreter
        lock (GIL), so multithreading can significantly speed up the
        photometry for many aperture positions. Multithreading is
        used only for apertures and input arrays supported by the
        fast batch code path. Otherwise, the computation is serial.

    See Also
    --------
    photutils.aperture.ApertureStats : Per-source statistics (e.g.,
        centroid, min, max, median, standard deviation, and
        morphological properties) of the pixels within an aperture.

    Notes
    -----
    `~regions.Region` objects are converted to `Aperture` objects using
    the :func:`region_to_aperture` function.

    If the input ``data`` is a `~astropy.nddata.NDData` object, then
    its ``mask``, ``wcs``, unit, and uncertainty are used. The
    ``error``, ``mask``, and ``wcs`` keywords are then ignored, and an
    `~astropy.utils.exceptions.AstropyUserWarning` is issued for each
    one that is input. The uncertainty is used as ``error`` only if it
    is a `~astropy.nddata.StdDevUncertainty`. Any other uncertainty
    type is ignored.

    The measured `flux`, `flux_err`, `area`, and `flags` attributes
    (as well as `id`, `x_center`, `y_center`, and `sky_center`) are
    scalars if a single scalar aperture position is input (e.g.,
    ``CircularAperture((10, 20), r=5)``). They are 1D arrays with
    one element per position if multiple positions are input (e.g.,
    ``CircularAperture([(10, 20)], r=5)`` or ``CircularAperture([(10,
    20), (30, 40)], r=5)``). If a list of apertures is input, the
    `flux`, `flux_err`, `area`, and `flags` attributes gain a trailing
    aperture axis, giving shape ``(n_apertures,)`` for a single scalar
    position and ``(n_positions, n_apertures)`` otherwise.

    Nonfinite ``data`` values (NaN and inf) are automatically masked.
    Such pixels are excluded from the `flux`, `flux_err`, and `area`
    calculations and are indicated by the ``non_finite_data`` quality
    flag (see `~photutils.aperture.decode_aperture_flags`).

    This class should be treated as immutable after
    initialization (aside from the internal lazily-computed
    `functools.cached_property` cache), so a single instance can be
    safely shared across threads. Do not reassign its attributes after
    construction.

    One caveat applies to apertures that are not supported by the
    compiled batch code path (e.g., a `~photutils.aperture.Aperture`
    subclass that overrides ``to_mask``). That path suppresses warnings
    using `warnings.catch_warnings`, which mutates process-global
    warning-filter state, so concurrent calls can transiently affect
    the warning filters seen by other threads. On free-threaded Python
    builds the warning filters are context-aware, so this does not
    apply.

    Examples
    --------
    >>> import numpy as np
    >>> from photutils.datasets import make_4gaussians_image
    >>> from photutils.aperture import AperturePhotometry, CircularAperture
    >>> data = make_4gaussians_image()
    >>> error = 0.1 * np.ones(data.shape)  # simple background-only error
    >>> aper = CircularAperture([(25, 40), (90, 60), (150, 25)], r=8)
    >>> phot = AperturePhotometry(data, aper, error=error)
    >>> print(phot.flux)
    [ 5853.59627292 28440.27461471  9286.70920641]
    >>> print(phot.flux_err)
    [1.38553058 1.38553058 1.38553058]
    >>> print(phot.to_table(columns=['id', 'flux', 'flux_err']))
     id        flux             flux_err
    --- ------------------ ------------------
      1  5853.596272924398 1.3855305772442865
      2 28440.274614708058 1.3855305772442865
      3  9286.709206410273 1.3855305772442865
    """

    _repr_params = ('method', 'subpixels', 'mask_method', 'n_threads')

    def __init__(self, data, apertures, *, error=None, mask=None, wcs=None,
                 method='exact', subpixels=5, segmentation_image=None,
                 labels=None, mask_method='none', n_threads=1):

        if isinstance(data, NDData):
            data, error, mask, wcs = unpack_nddata(data, error, mask, wcs)

        (data, error), unit = process_quantities(
            (data, error), ('data', 'error'))
        self._data = validate_array(data, 'data')
        self._data_unit = unit
        data_shape = self._data.shape
        self._error = validate_array(error, 'error', shape=data_shape)
        self._mask = validate_array(mask, 'mask', shape=data_shape)
        self._wcs = wcs

        # Validate the mask-method keywords here so that an invalid
        # value is reported at construction rather than at the first
        # access of a measured attribute, far from its cause.
        validate_mask_method(method, subpixels, method_name='method')
        self.method = method
        self.subpixels = subpixels
        self.mask_method = mask_method

        if (isinstance(n_threads, bool)
                or not isinstance(n_threads, (int, np.integer))
                or n_threads < 1):
            msg = 'n_threads must be a positive integer'
            raise ValueError(msg)
        self.n_threads = int(n_threads)

        single_aperture = False
        if not isinstance(apertures, (list, tuple, np.ndarray)):
            single_aperture = True
            apertures = (apertures,)
        elif len(apertures) == 0:
            msg = 'apertures must not be empty'
            raise ValueError(msg)
        self._single_aperture = single_aperture

        # Create table metadata using the input apertures, not the
        # converted ones
        aper_meta = {}
        for i, aperture in enumerate(apertures):
            idx = '' if single_aperture else i
            aper_meta.update(_aperture_metadata(aperture, index=idx))

        # Convert regions to apertures if necessary
        apertures = [region_to_aperture(aper)
                     if not isinstance(aper, Aperture) else aper
                     for aper in apertures]

        # Convert sky to pixel apertures
        self._skyaper = False
        self._sky_positions = None
        if isinstance(apertures[0], SkyAperture):
            if wcs is None:
                msg = ('A WCS transform must be defined by the input data '
                       'or the wcs keyword when using a SkyAperture object.')
                raise ValueError(msg)
            self._skyaper = True
            self._sky_positions = apertures[0].positions
            apertures = [aper.to_pixel(wcs) for aper in apertures]

        # Compare positions in pixels to avoid comparing SkyCoord objects
        positions = apertures[0].positions
        for aper in apertures[1:]:
            if not np.array_equal(aper.positions, positions):
                msg = 'Input apertures must all have identical positions'
                raise ValueError(msg)
        self._pixel_apertures = apertures

        # Validate the segmentation-masking inputs up front and keep
        # the resolved per-aperture source labels for slicing
        self.segmentation_image = segmentation_image
        self.labels = labels
        seg_positions = np.atleast_2d(apertures[0].positions)
        _, self._seg_labels = process_segmentation_inputs(
            segmentation_image, labels, mask_method, seg_positions,
            self._data.shape)

        # Define output table metadata
        self.meta = _get_meta()
        calling_args = (f"method='{method}', subpixels={subpixels}, "
                        f"mask_method='{mask_method}', "
                        f'n_threads={self.n_threads}')
        self.meta['aperture_photometry_args'] = calling_args
        self.meta.update(aper_meta)

        default_columns = ['id', 'x_center', 'y_center']
        if self._wcs is not None or self._skyaper:
            default_columns.append('sky_center')
        default_columns += ['flux', 'flux_err', 'area', 'flags']
        self.default_columns = default_columns

    def __repr__(self):
        return make_repr(self, self._repr_params)

    def __str__(self):
        return make_repr(self, self._repr_params, long=True)

    def __getattribute__(self, name):
        # Collapse the leading position axis of the public array-valued
        # output attributes to a scalar when a single scalar aperture
        # position is input (e.g., ``CircularAperture((10, 20), r=5)``).
        # The scalar conversion is applied centrally here instead of
        # being repeated on each individual property. Public attributes
        # that are not per-position outputs are excluded, so that, for
        # example, the input ``segmentation_image`` is not reduced to
        # its first row.
        value = super().__getattribute__(name)
        if (not name.startswith('_')
                and name not in _SCALAR_EXCLUDE
                and isinstance(value, SCALAR_COLLAPSE_TYPES)
                and self.isscalar):
            return collapse_scalar_value(value)
        return value

    def _array(self, name):
        """
        Return the full (never scalar-collapsed) array for a public
        output attribute, regardless of whether the instance is scalar.

        This bypasses the scalar conversion performed in
        ``__getattribute__`` so that the table-building and
        flag-decoding machinery always operates on arrays.
        """
        return object.__getattribute__(self, name)

    @cached_property
    def isscalar(self):
        """
        Whether the instance is scalar (i.e., a single scalar
        aperture position such as ``CircularAperture((10, 20), r=5)``,
        not a length-1 list of positions).
        """
        return self._pixel_apertures[0].isscalar

    @cached_property
    def _photometry_results(self):
        """
        The per-aperture photometry result objects, one for each input
        aperture.
        """
        return [aper._photometry(
            self._data, error=self._error, mask=self._mask,
            method=self.method, subpixels=self.subpixels,
            segmentation_image=self.segmentation_image,
            labels=self._seg_labels, mask_method=self.mask_method,
            mask_nonfinite=True, n_threads=self.n_threads)
            for aper in self._pixel_apertures]

    @cached_property
    def _positions(self):
        """
        The aperture positions in pixels, always as a 2D array.
        """
        return np.atleast_2d(self._pixel_apertures[0].positions)

    @cached_property
    def n_positions(self):
        """
        The number of aperture positions.
        """
        return self._positions.shape[0]

    @cached_property
    def id(self):
        """
        The aperture identification number(s).
        """
        return np.arange(self.n_positions) + 1

    @cached_property
    def x_center(self):
        """
        The ``x`` pixel coordinate(s) of the aperture center(s).
        """
        return self._positions[:, 0]

    @cached_property
    def y_center(self):
        """
        The ``y`` pixel coordinate(s) of the aperture center(s).
        """
        return self._positions[:, 1]

    @cached_property
    def sky_center(self):
        """
        The sky coordinates of the aperture center(s), or `None` if no
        ``wcs`` was input.
        """
        if self._skyaper:
            pos = self._sky_positions
            if pos.isscalar:
                # Return a length-1 SkyCoord array
                return pos.reshape((-1,))
            return pos
        if self._wcs is not None:
            return self._wcs.pixel_to_world(*np.transpose(self._positions))
        return None

    def _stack(self, attr):
        """
        Stack a per-aperture result attribute into a 1D array (single
        aperture) or a 2D ``(n_positions, n_apertures)`` array (list of
        apertures).
        """
        values = [getattr(result, attr)
                  for result in self._photometry_results]
        if self._single_aperture:
            return values[0]
        return np.stack(values, axis=1)

    @cached_property
    def flux(self):
        """
        The sum of the (weighted) values within the aperture(s).

        The values are always float64, regardless of the input ``data``
        dtype (a `~astropy.units.Quantity` if ``data`` has units).

        The value is NaN where the aperture does not overlap the data
        (the ``'no_overlap'`` flag).
        """
        values = self._stack('flux')
        if self._data_unit is not None:
            values <<= self._data_unit
        return values

    @cached_property
    def flux_err(self):
        """
        The uncertainty in the `flux` values.

        The values are always float64, regardless of the input ``error``
        dtype (a `~astropy.units.Quantity` if ``data`` has units). If the
        input ``error`` is `None`, this is filled with NaN values.
        """
        values = self._stack('flux_err')
        if self._data_unit is not None:
            values <<= self._data_unit
        return values

    @cached_property
    def area(self):
        """
        The total unmasked overlap area of the aperture(s) (in
        ``pix**2``).

        This takes into account the aperture mask method, masked
        data pixels (``mask`` keyword), segmentation masking, and
        partial/no overlap of the aperture with the data. The value is
        NaN where the aperture does not overlap the data (the
        ``'no_overlap'`` flag).
        """
        values = [result.area for result in self._photometry_results]
        if self._single_aperture:
            return values[0]
        stacked = np.stack([value.value for value in values], axis=1)
        return u.Quantity(stacked, u.pix**2)

    @cached_property
    def flags(self):
        """
        The bitwise quality flags for the aperture(s).

        See `~photutils.aperture.decode_aperture_flags` for decoding
        flag values.
        """
        return self._stack('flags')

    @deprecated_positional_kwargs(since='3.1', until='4.0')
    def to_table(self, *, columns=None):
        """
        Create a `~astropy.table.QTable` of the aperture photometry
        results.

        Parameters
        ----------
        columns : str, list or tuple of str, or `None`, optional
            Names of columns, in order, to include in the output
            `~astropy.table.QTable`. The allowed column names are
            ``'id'``, ``'x_center'``, ``'y_center'``, ``'sky_center'``,
            ``'flux'``, ``'flux_err'``, ``'area'``, and ``'flags'``. If
            ``columns`` is `None`, then a default list of columns will
            be used (the ``default_columns`` attribute). If a list of
            apertures was input, then the ``'flux'``, ``'flux_err'``,
            ``'area'``, and ``'flags'`` columns will have a ``'_i'``
            suffix (e.g., ``'flux_0'``), where ``i`` is the index of the
            aperture in the input list.

        Returns
        -------
        table : `~astropy.table.QTable`
            A table of the aperture photometry results with one row per
            aperture position.

        Raises
        ------
        ValueError
            If any name in ``columns`` is not a valid column name, or if
            ``'sky_center'`` is requested but no WCS was input.
        """
        allowed_columns = ('id', 'x_center', 'y_center', 'sky_center',
                           'flux', 'flux_err', 'area', 'flags')
        if columns is None:
            table_columns = self.default_columns
        else:
            table_columns = validate_table_columns(columns, allowed_columns)

        if ('sky_center' in table_columns
                and self._array('sky_center') is None):
            msg = ("the 'sky_center' column requires a WCS, which must "
                   'be defined by the input data or the wcs keyword')
            raise ValueError(msg)

        tbl = QTable()
        tbl.meta.update(self.meta)

        per_aperture = ('flux', 'flux_err', 'area', 'flags')
        for column in table_columns:
            values = self._array(column)
            if column in per_aperture and not self._single_aperture:
                for i in range(len(self._pixel_apertures)):
                    name = f'{column}_{i}'
                    tbl[name] = values[:, i]
            else:
                tbl[column] = values
        return tbl

    def decode_flags(self, *, return_bit_values=False):
        """
        Decode the aperture quality flags into individual components.

        This is a convenience method that calls
        `~photutils.aperture.decode_aperture_flags` with the `flags`
        attribute.

        Parameters
        ----------
        return_bit_values : bool, optional
            If `True`, return the decoded bit flags (integers) instead
            of the flag names (strings).

        Returns
        -------
        decoded : dict
            A dictionary mapping each aperture position `id` to its
            decoded flags. For a single input aperture, each value is
            the list of active flag names (or bit values) for that
            position. If a list of apertures was input (2D `flags`),
            each value is a list with one entry per aperture, so
            ``decoded[id][j]`` gives the active flags for position
            ``id`` and aperture ``j``. The entries follow the position
            order.

        See Also
        --------
        photutils.aperture.decode_aperture_flags
        """
        decoded = decode_aperture_flags(self._array('flags'),
                                        return_bit_values=return_bit_values)
        return {int(id_): flags
                for id_, flags in zip(self._array('id'), decoded,
                                      strict=True)}


@_update_method_subpixels_docstring
@deprecated_positional_kwargs(since='3.0', until='4.0')
def aperture_photometry(data, apertures, error=None, mask=None,
                        method='exact', subpixels=5, wcs=None):
    # numpydoc ignore: PR01,PR02,PR04,PR07
    """
    Perform aperture photometry on the input data by summing the flux
    within the given aperture(s).

    .. note::
        This is a legacy function. It is not deprecated,
        but new features are no longer added to it. The
        :class:`~photutils.aperture.AperturePhotometry` class is the
        recommended tool for aperture photometry. It provides additional
        outputs (e.g., aperture areas, quality flags) and options (e.g.,
        segmentation-based neighbor masking).

    This function returns the sum of the (weighted) input ``data``
    values within the aperture. It does not convert data in
    surface brightness units to flux or counts. Conversion from
    surface-brightness units should be performed before using this
    function.

    Parameters
    ----------
    data : array_like, `~astropy.units.Quantity`, `~astropy.nddata.NDData`
        The 2D array on which to perform photometry. ``data``
        should be background-subtracted. If ``data`` is a
        `~astropy.units.Quantity` array, then ``error`` (if input)
        must also be a `~astropy.units.Quantity` array with the same
        units. Nonfinite ``data`` values (NaN and inf) are not masked
        automatically. An aperture that contains one has a nonfinite
        sum. See the Notes section below for more information about
        `~astropy.nddata.NDData` input.

    apertures : `~photutils.aperture.Aperture`, supported `regions.Region`, \
        list of `~photutils.aperture.Aperture` or `regions.Region`
        The aperture(s) to use for the photometry. If ``apertures`` is
        a list of `~photutils.aperture.Aperture` or `regions.Region`,
        then they all must have the same position(s). A tuple or
        `~numpy.ndarray` of them is also accepted. If ``apertures``
        contains a `~photutils.aperture.SkyAperture` or
        `~regions.SkyRegion` object, then a WCS must be input using
        the ``wcs`` keyword. Region objects are converted to aperture
        objects.

    error : array_like or `~astropy.units.Quantity`, optional
        The pixel-wise Gaussian 1-sigma errors of the input
        ``data``. ``error`` is assumed to include *all* sources
        of error, including the Poisson error of the sources (see
        `~photutils.utils.calc_total_error`). ``error`` must have the
        same shape as the input ``data``. If a `~astropy.units.Quantity`
        array, then ``data`` must also be a `~astropy.units.Quantity`
        array with the same units.

    mask : array_like (bool), optional
        A boolean mask with the same shape as ``data`` where a `True`
        value indicates the corresponding element of ``data`` is masked.
        Masked data are excluded from all calculations.

    <method_subpixels_descriptions>

    wcs : WCS object, optional
        A world coordinate system (WCS) transformation that
        supports the `astropy shared interface for WCS
        <https://docs.astropy.org/en/stable/wcs/wcsapi.html>`_ (e.g.,
        `astropy.wcs.WCS`, `gwcs.wcs.WCS`). If provided, the output
        table will include a ``'sky_center'`` column with the sky
        coordinates of the input aperture center(s). This keyword is
        required if the input ``apertures`` contains a `SkyAperture` or
        `~regions.SkyRegion`.

    Returns
    -------
    table : `~astropy.table.QTable`
        A table of the photometry with the following columns:

        * ``'id'``:
          The source ID.

        * ``'x_center'``, ``'y_center'``:
          The ``x`` and ``y`` pixel coordinates of the input aperture
          center(s).

          .. deprecated:: 3.0
              The ``'xcenter'`` and ``'ycenter'`` column names are
              deprecated aliases of ``'x_center'`` and ``'y_center'``.
              They emit a deprecation warning when used and will be
              removed in version 4.0.

        * ``'sky_center'``:
          The sky coordinates of the input aperture center(s). Returned
          if a ``wcs`` is input.

        * ``'aperture_sum'``:
          The sum of the values within the aperture(s). The values
          are always float64, regardless of the input ``data`` dtype
          (a `~astropy.units.Quantity` with float64 values if ``data``
          has units).

        * ``'aperture_sum_err'``:
          The corresponding uncertainty in the ``'aperture_sum'`` values
          (always float64). Returned only if the input ``error`` is not
          `None`.

        If a list of apertures is input (even a list with one
        aperture), the ``'aperture_sum'`` and ``'aperture_sum_err'``
        columns will have a ``'_i'`` suffix (e.g.,
        ``'aperture_sum_0'``), where ``i`` is the index of the aperture
        in the input list.

        The table metadata includes the date, the version numbers of
        Python, Photutils, and its dependencies, the ``method`` and
        ``subpixels`` calling arguments, and the class name and shape
        parameters of each input aperture.

    Raises
    ------
    ValueError
        If ``apertures`` contains a `~photutils.aperture.SkyAperture`
        or `~regions.SkyRegion` and no WCS is input, or if the input
        apertures do not all have identical positions.

    Notes
    -----
    `~regions.Region` objects are converted to `Aperture` objects using
    the :func:`region_to_aperture` function.

    If the input ``data`` is a `~astropy.nddata.NDData` object, then
    its ``mask``, ``wcs``, unit, and uncertainty are used. The
    ``error``, ``mask``, and ``wcs`` keywords are then ignored, and an
    `~astropy.utils.exceptions.AstropyUserWarning` is issued for each
    one that is input. The uncertainty is used as ``error`` only if it
    is a `~astropy.nddata.StdDevUncertainty`. Any other uncertainty
    type is ignored.
    """
    if isinstance(data, NDData):
        data, error, mask, wcs = unpack_nddata(data, error, mask, wcs)
        return aperture_photometry(data, apertures, error=error, mask=mask,
                                   method=method, subpixels=subpixels,
                                   wcs=wcs)

    # The aperture-list handling, sky-to-pixel conversion, and
    # position-equality checking below duplicate the equivalent code in
    # AperturePhotometry.__init__. The duplication is intentional. This
    # function is frozen and must not gain new behavior, so it must not
    # be refactored to share the class logic.
    single_aperture = False
    if not isinstance(apertures, (list, tuple, np.ndarray)):
        single_aperture = True
        apertures = (apertures,)

    # Create table metadata using the input apertures, not the converted
    # ones
    aper_meta = {}
    for i, aperture in enumerate(apertures):
        i = '' if single_aperture else i
        aper_meta.update(_aperture_metadata(aperture, index=i))

    # Convert regions to apertures if necessary
    apertures = [region_to_aperture(aper)
                 if not isinstance(aper, Aperture) else aper
                 for aper in apertures]

    # Convert sky to pixel apertures
    skyaper = False
    if isinstance(apertures[0], SkyAperture):
        if wcs is None:
            msg = ('A WCS transform must be defined by the input data or '
                   'the wcs keyword when using a SkyAperture object.')
            raise ValueError(msg)

        # Include SkyCoord position in the output table
        skyaper = True
        skycoord_pos = apertures[0].positions

        apertures = [aper.to_pixel(wcs) for aper in apertures]

    # Compare positions in pixels to avoid comparing SkyCoord objects
    positions = apertures[0].positions
    for aper in apertures[1:]:
        if not np.array_equal(aper.positions, positions):
            msg = 'Input apertures must all have identical positions'
            raise ValueError(msg)

    # Define output table meta data
    meta = _get_meta()
    calling_args = f"method='{method}', subpixels={subpixels}"
    meta['aperture_photometry_args'] = calling_args
    meta.update(aper_meta)

    # Replace with QTable in 4.0
    tbl = create_empty_deprecated_qtable(
        _DEPRECATED_COLUMNS, since='3.0', until='4.0')

    tbl.meta.update(meta)  # keep tbl.meta type

    positions = np.atleast_2d(apertures[0].positions)
    tbl['id'] = np.arange(positions.shape[0], dtype=int) + 1

    xypos_pixel = np.transpose(positions)
    tbl['x_center'] = xypos_pixel[0]
    tbl['y_center'] = xypos_pixel[1]

    if skyaper:
        if skycoord_pos.isscalar:
            # Create length-1 SkyCoord array
            tbl['sky_center'] = skycoord_pos.reshape((-1,))
        else:
            tbl['sky_center'] = skycoord_pos

    if wcs is not None and not skyaper:
        tbl['sky_center'] = wcs.pixel_to_world(*np.transpose(positions))

    for i, aper in enumerate(apertures):
        result = aper._photometry(
            data, error=error, mask=mask, method=method, subpixels=subpixels)

        # Legacy column names
        sum_key = 'aperture_sum'
        sum_err_key = 'aperture_sum_err'

        if not single_aperture:
            sum_key += f'_{i}'
            sum_err_key += f'_{i}'

        tbl[sum_key] = result.flux
        if error is not None:
            tbl[sum_err_key] = result.flux_err

    return tbl
