# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
IRAFStarFinder class.
"""

import warnings
from functools import cached_property

import numpy as np

from photutils.detection.core import (_DEPR_DEFAULT, StarFinderBase,
                                      StarFinderCatalogBase,
                                      _handle_deprecated_range,
                                      _StarFinderKernel, _validate_n_brightest,
                                      _validate_xycoords_bounds)
from photutils.utils._convolution import _filter_data
from photutils.utils._deprecation import (deprecated_positional_kwargs,
                                          deprecated_renamed_argument)
from photutils.utils._quantity_helpers import check_units, isscalar
from photutils.utils._repr import make_repr
from photutils.utils.exceptions import (NoDetectionsWarning,
                                        PhotutilsDeprecationWarning)

__all__ = ['IRAFStarFinder']


class IRAFStarFinder(StarFinderBase):
    """
    Detect stars in an image using IRAF's "starfind" algorithm.

    `IRAFStarFinder` searches images for local density maxima that
    have a peak amplitude greater than ``threshold`` above the local
    background and have a PSF full width at half maximum similar to the
    input ``fwhm``. The objects' centroid, roundness (ellipticity), and
    sharpness are calculated using image moments.

    The image is convolved with a circular Gaussian kernel that has a
    positive core and negative wings, and that sums to zero. This
    convolution is equivalent to a linear least-squares fit, at every
    pixel, of the amplitude of the Gaussian centered on that pixel
    plus a constant local background. Each pixel of the convolved
    image is therefore the height of the best-fitting Gaussian at that
    position, in the units of the input ``data``. Because the local
    background is fitted, the convolved image does not depend on the
    background level. The ``threshold`` is applied directly to this
    fitted height. The local background is fitted using only the pixels
    within the kernel footprint, so a larger ``sigma_radius`` gives a
    less noisy fitted height.

    Parameters
    ----------
    threshold : float or 2D `~numpy.ndarray`
        The absolute image value above which to select sources. If
        ``threshold`` is a 2D array, it must have the same shape as the
        input ``data``. If the star finder is run on an image that is a
        `~astropy.units.Quantity` array, then ``threshold`` must have
        the same units.

    fwhm : float
        The full width at half maximum (FWHM) of the 2D circular
        Gaussian kernel in units of pixels.

    sigma_radius : float, optional
        The truncation radius of the Gaussian kernel in units of sigma
        (standard deviation) (:math:`\\sigma = \\mbox{FWHM} / (2
        \\sqrt{2 \\log(2)})`).

    minsep_fwhm : float, optional
        The separation (in units of ``fwhm``) for detected objects. The
        minimum separation is calculated as ``int((fwhm * minsep_fwhm) +
        0.5)`` and is clipped to a minimum value of 2. This value
        is ignored if ``min_separation`` is input. Note that large
        values may result in long run times.

        .. deprecated:: 3.0
            This keyword is deprecated and will be removed in version
            4.0. Use ``min_separation`` instead.

    sharplo : float, optional
        The lower bound on sharpness for object detection.

        .. deprecated:: 3.0
            This keyword is deprecated and will be removed in version
            4.0. Use ``sharpness_range=(lower, upper)`` instead.

    sharphi : float, optional
        The upper bound on sharpness for object detection.

        .. deprecated:: 3.0
            This keyword is deprecated and will be removed in version
            4.0. Use ``sharpness_range=(lower, upper)`` instead.

    roundlo : float, optional
        The lower bound on roundness for object detection.

        .. deprecated:: 3.0
            This keyword is deprecated and will be removed in version
            4.0. Use ``roundness_range=(lower, upper)`` instead.

    roundhi : float, optional
        The upper bound on roundness for object detection.

        .. deprecated:: 3.0
            This keyword is deprecated and will be removed in version
            4.0. Use ``roundness_range=(lower, upper)`` instead.

    exclude_border : bool, optional
        Set to `True` to exclude sources found within half the size of
        the convolution kernel from the image borders. The default is
        `False`, which is the mode used by starfind.

    n_brightest : int, None, optional
        The number of brightest objects to keep after sorting the source
        list by flux. If ``n_brightest`` is set to `None`, all objects
        will be selected.

    peak_max : float, None, optional
        The maximum allowed peak pixel value in an object. Objects with
        peak pixel values greater than ``peak_max`` will be rejected.
        The peak value is measured after the local sky is subtracted.
        This keyword may be used, for example, to exclude saturated
        sources. If the star finder is run on an image that is a
        `~astropy.units.Quantity` array, then ``peak_max`` must have the
        same units. If ``peak_max`` is set to `None`, then no peak pixel
        value filtering will be performed.

    xycoords : `None` or Nx2 array_like, optional
        The (x, y) pixel coordinates of the approximate centroid
        positions of identified sources. If ``xycoords`` are input,
        the algorithm will skip the source-finding step, and
        ``threshold``, ``min_separation``, ``exclude_border``, and the
        ``mask`` input to ``find_stars`` are not used to select the
        sources. The positions are rounded to the nearest pixel and
        must be within the bounds of the input ``data``.

    min_separation : `None` or float, optional
        The minimum separation (in pixels) for detected objects. If
        `None` (default) then the minimum separation is calculated as
        ``2.5 * fwhm``. If 0, a local peak is required only within the
        kernel footprint. Note that large values may result in long run
        times.

        .. versionchanged:: 3.0
            The default ``min_separation`` changed from ``max(2,
            int(fwhm * 2.5 + 0.5))`` to ``2.5 * fwhm``. To recover the
            previous behavior, set ``min_separation=max(2, int(fwhm *
            2.5 + 0.5))``.

    sharpness_range : tuple of 2 floats or `None`, optional
        The ``(lower, upper)`` inclusive bounds on sharpness for object
        detection. Objects with sharpness outside this range will be
        rejected. If `None`, no sharpness filtering is performed. The
        default is ``(0.5, 2.0)``.

    roundness_range : tuple of 2 floats or `None`, optional
        The ``(lower, upper)`` inclusive bounds on roundness for object
        detection. Objects with roundness outside this range will be
        rejected. If `None`, no roundness filtering is performed. The
        default is ``(0.0, 0.2)``.

    min_n_pixels : int, optional
        The minimum number of positive sky-subtracted pixels within
        the kernel footprint that a source must have. Sources with
        fewer such pixels are rejected. The default is 5, which is the
        default and the minimum value of the ``npixmin`` parameter in
        IRAF's starfind.

    See Also
    --------
    DAOStarFinder

    Notes
    -----
    If the star finder is run on an image that is a
    `~astropy.units.Quantity` array, then ``threshold`` and ``peak_max``
    must have the same units as the image.

    For the convolution step, this routine sets pixels beyond the image
    borders to 0.0. The equivalent parameters in IRAF's starfind are
    ``boundary='constant'`` and ``constant=0.0``.

    IRAF's starfind uses ``hwhmpsf``, ``fradius``, and ``sepmin`` as
    input parameters. The equivalent input values for `IRAFStarFinder`
    are:

    * ``fwhm = hwhmpsf * 2``
    * ``sigma_radius = fradius * sqrt(2.0 * log(2.0))``
    * ``min_separation = max(2, int((fwhm * sepmin) + 0.5))``
    * ``min_n_pixels = npixmin``

    As in IRAF's starfind, sources whose centroid is outside of the
    image are rejected.

    The main differences between `~photutils.detection.DAOStarFinder`
    and `~photutils.detection.IRAFStarFinder` are:

    * `~photutils.detection.IRAFStarFinder` always uses a 2D circular
      Gaussian kernel, while `~photutils.detection.DAOStarFinder` can use
      an elliptical Gaussian kernel.

    * `~photutils.detection.IRAFStarFinder` internally calculates a
      local "sky" background level for each source as the mean of the
      pixels in the kernel array that lie outside the kernel footprint,
      and subtracts it before computing the source properties. If
      the kernel footprint covers the entire kernel array, the sky is
      the central data value minus the central value of the convolved
      data.

    * `~photutils.detection.IRAFStarFinder` calculates the objects'
      centroid, roundness, and sharpness using image moments.

    This routine differs from IRAF's starfind for pixels of the
    convolved image that have identical values, which are uncommon
    for floating-point data (a saturated star usually has none).
    For a positive ``min_separation``, such pixels that are
    within ``min_separation`` of each other give only one source (see
    `~photutils.detection.find_peaks`). IRAF's starfind keeps every
    pixel that is tied for the maximum within ``sepmin``, except for
    those that follow a detected pixel within ``sepmin`` along the same
    image line. With ``min_separation=0``, this routine keeps every
    pixel that is tied for the maximum within the kernel footprint.
    """

    @deprecated_positional_kwargs(since='3.0', until='4.0')
    @deprecated_renamed_argument('brightest', 'n_brightest', '3.0',
                                 until='4.0')
    @deprecated_renamed_argument('peakmax', 'peak_max', '3.0', until='4.0')
    def __init__(self, threshold, fwhm, sigma_radius=1.5,
                 minsep_fwhm=_DEPR_DEFAULT,
                 sharplo=_DEPR_DEFAULT, sharphi=_DEPR_DEFAULT,
                 roundlo=_DEPR_DEFAULT, roundhi=_DEPR_DEFAULT,
                 exclude_border=False, n_brightest=None, peak_max=None,
                 xycoords=None, min_separation=None, *,
                 sharpness_range=(0.5, 2.0),
                 roundness_range=(0.0, 0.2), min_n_pixels=5):

        # Validate the units, but do not strip them
        inputs = (threshold, peak_max)
        names = ('threshold', 'peak_max')
        check_units(inputs, names)

        if not isscalar(fwhm):
            msg = 'fwhm must be a scalar value'
            raise TypeError(msg)

        sharpness_range = _handle_deprecated_range(
            sharplo, sharphi, sharpness_range,
            'sharp', 'sharpness_range', (0.5, 2.0))
        roundness_range = _handle_deprecated_range(
            roundlo, roundhi, roundness_range,
            'round', 'roundness_range', (0.0, 0.2))

        if sharpness_range is not None:
            if np.ndim(sharpness_range) != 1 or np.size(sharpness_range) != 2:
                msg = ('sharpness_range must be a 2-element (lower, upper) '
                       'tuple or None')
                raise ValueError(msg)
            sharpness_range = tuple(sharpness_range)

        if roundness_range is not None:
            if np.ndim(roundness_range) != 1 or np.size(roundness_range) != 2:
                msg = ('roundness_range must be a 2-element (lower, upper) '
                       'tuple or None')
                raise ValueError(msg)
            roundness_range = tuple(roundness_range)

        # Handle deprecated minsep_fwhm parameter
        if minsep_fwhm is not _DEPR_DEFAULT:
            msg = ("The 'minsep_fwhm' parameter is deprecated "
                   'and will be removed in version 4.0. Use '
                   "'min_separation' instead.")
            warnings.warn(msg, PhotutilsDeprecationWarning)
            if minsep_fwhm < 0:
                msg = 'minsep_fwhm must be >= 0'
                raise ValueError(msg)
            if min_separation is None:
                # Use the deprecated minsep_fwhm calculation to set the
                # min_separation
                min_separation = max(2, int((fwhm * minsep_fwhm) + 0.5))

        self.threshold = threshold
        self.fwhm = fwhm
        self.sigma_radius = sigma_radius
        self.sharpness_range = sharpness_range
        self.roundness_range = roundness_range
        self.exclude_border = exclude_border
        self.n_brightest = _validate_n_brightest(n_brightest)
        self.peak_max = peak_max

        if min_n_pixels < 1:
            msg = 'min_n_pixels must be >= 1'
            raise ValueError(msg)
        self.min_n_pixels = min_n_pixels

        if xycoords is not None:
            xycoords = np.asarray(xycoords)
            if xycoords.ndim != 2 or xycoords.shape[1] != 2:
                msg = 'xycoords must be shaped as an Nx2 array'
                raise ValueError(msg)
        self.xycoords = xycoords

        self.kernel = _StarFinderKernel(self.fwhm, ratio=1.0, theta=0.0,
                                        sigma_radius=self.sigma_radius)

        if min_separation is not None:
            if min_separation < 0:
                msg = 'min_separation must be >= 0'
                raise ValueError(msg)
            self.min_separation = min_separation
        else:
            self.min_separation = 2.5 * self.fwhm

    def _repr_str_params(self):
        params = ('threshold', 'fwhm', 'sigma_radius',
                  'sharpness_range', 'roundness_range',
                  'exclude_border', 'n_brightest', 'peak_max', 'xycoords',
                  'min_separation', 'min_n_pixels')
        overrides = {}
        if not isscalar(self.threshold):
            overrides['threshold'] = (
                f'<array; shape={np.shape(self.threshold)}>')
        if self.xycoords is not None:
            overrides['xycoords'] = f'<array; shape={self.xycoords.shape}>'
        return params, overrides

    def __repr__(self):
        params, overrides = self._repr_str_params()
        return make_repr(self, params, overrides=overrides)

    def __str__(self):
        params, overrides = self._repr_str_params()
        return make_repr(self, params, overrides=overrides, long=True)

    def _get_raw_catalog(self, data, *, mask=None):
        """
        Get the raw catalog of sources from the input data.

        Parameters
        ----------
        data : 2D `~numpy.ndarray`
            The 2D image array. The image should be
            background-subtracted.

        mask : 2D bool array, optional
            A boolean mask with the same shape as ``data``, where a
            `True` value indicates the corresponding element of ``data``
            is masked. Masked pixels are ignored when searching for
            stars.

        Returns
        -------
        cat : `_IRAFStarFinderCatalog` or `None`
            A catalog of sources found in the input data. `None` is
            returned if no sources are found.
        """
        convolved_data = _filter_data(data, self.kernel.data, mode='constant',
                                      fill_value=0.0,
                                      check_normalization=False)

        if self.xycoords is None:
            # _find_stars returns the integer peak pixel positions.
            # The subpixel centroids are computed later in the catalog.
            xypos = self._find_stars(convolved_data, self.kernel,
                                     self.threshold,
                                     min_separation=self.min_separation,
                                     mask=mask,
                                     exclude_border=self.exclude_border)
        else:
            _validate_xycoords_bounds(self.xycoords, data.shape)
            xypos = self.xycoords

        if xypos is None:
            msg = 'No sources were found.'
            warnings.warn(msg, NoDetectionsWarning)
            return None

        return _IRAFStarFinderCatalog(data,
                                      convolved_data,
                                      xypos,
                                      self.kernel,
                                      sharpness_range=self.sharpness_range,
                                      roundness_range=self.roundness_range,
                                      n_brightest=self.n_brightest,
                                      peak_max=self.peak_max,
                                      min_n_pixels=self.min_n_pixels)

    @deprecated_positional_kwargs(since='3.0', until='4.0')
    def find_stars(self, data, mask=None):
        """
        Find stars in an astronomical image.

        Parameters
        ----------
        data : 2D `~numpy.ndarray` or `~astropy.units.Quantity`
            The 2D image array. The image should be
            background-subtracted.

        mask : 2D bool array, optional
            A boolean mask with the same shape as ``data``, where a
            `True` value indicates the corresponding element of ``data``
            is masked. Masked pixels are ignored when searching for
            stars.

        Returns
        -------
        table : `~astropy.table.QTable` or `None`
            A table of found stars. `None` is returned if no stars are
            found. The table contains the following parameters:

            * ``id``: unique object identification number.
            * ``x_centroid, y_centroid``: object centroid.
            * ``fwhm``: object FWHM.
            * ``sharpness``: object sharpness.
            * ``roundness``: object roundness.
            * ``orientation``: the angle between the x-axis and the
              major axis of the source, measured counterclockwise, in
              the range (-90, 90] degrees.
            * ``n_pixels``: the total number of (positive) unmasked
              pixels.
            * ``peak``: the peak sky-subtracted pixel value of the
              object within the kernel footprint.
            * ``flux``: the object instrumental flux calculated as the
              sum of the positive sky-subtracted data values within the
              kernel footprint.
            * ``mag``: the object instrumental magnitude calculated as
              ``-2.5 * log10(flux)``.
        """
        inputs = (data, self.threshold, self.peak_max)
        names = ('data', 'threshold', 'peak_max')
        check_units(inputs, names)

        cat = self._get_raw_catalog(data, mask=mask)
        if cat is None:
            return None

        # Apply all selection filters
        cat = cat.apply_all_filters()
        if cat is None:
            return None

        # Create the output table
        return cat.to_table()


class _IRAFStarFinderCatalog(StarFinderCatalogBase):
    """
    Class to create a catalog of the properties of each detected star,
    as defined by IRAF's ``starfind`` task.

    Parameters
    ----------
    data : 2D `~numpy.ndarray`
        The 2D image. The image should be background-subtracted.

    convolved_data : 2D `~numpy.ndarray`
        The convolved 2D image. If ``data`` is a
        `~astropy.units.Quantity` array, then ``convolved_data`` must
        have the same units.

    xypos : Nx2 `~numpy.ndarray`
        An Nx2 array of (x, y) pixel coordinates denoting the central
        positions of the stars.

    kernel : `_StarFinderKernel`
        The convolution kernel. This kernel must match the kernel used
        to create the ``convolved_data``.

    sharpness_range : tuple of 2 floats or `None`, optional
        The ``(lower, upper)`` inclusive bounds on sharpness for object
        detection. Objects with sharpness outside this range will be
        rejected. If `None`, no sharpness filtering is performed. The
        default is ``(0.5, 2.0)``.

    roundness_range : tuple of 2 floats or `None`, optional
        The ``(lower, upper)`` inclusive bounds on roundness for object
        detection. Objects with roundness outside this range will be
        rejected. If `None`, no roundness filtering is performed. The
        default is ``(0.0, 0.2)``.

    n_brightest : int, None, optional
        The number of brightest objects to keep after sorting the source
        list by flux. If ``n_brightest`` is set to `None`, all objects
        will be selected.

    peak_max : float, None, optional
        The maximum allowed peak pixel value in an object. Objects with
        peak pixel values greater than ``peak_max`` will be rejected.
        This keyword may be used, for example, to exclude saturated
        sources. If the star finder is run on an image that is a
        `~astropy.units.Quantity` array, then ``peak_max`` must have the
        same units. If ``peak_max`` is set to `None`, then no peak pixel
        value filtering will be performed.

    min_n_pixels : int, optional
        The minimum number of positive sky-subtracted pixels within
        the kernel footprint that a source must have. The default is 5.
    """

    def __init__(self, data, convolved_data, xypos, kernel, *,
                 sharpness_range=(0.5, 2.0), roundness_range=(0.0, 0.2),
                 n_brightest=None, peak_max=None, min_n_pixels=5):

        # Validate the units, but do not strip them
        inputs = (data, convolved_data, peak_max)
        names = ('data', 'convolved_data', 'peak_max')
        check_units(inputs, names)

        super().__init__(data, xypos, kernel,
                         n_brightest=n_brightest,
                         peak_max=peak_max)

        self.convolved_data = convolved_data
        self.sharpness_range = sharpness_range
        self.roundness_range = roundness_range
        self.min_n_pixels = min_n_pixels

        self.default_columns = ('id', 'x_centroid', 'y_centroid', 'fwhm',
                                'sharpness', 'roundness', 'orientation',
                                'n_pixels', 'peak', 'flux', 'mag')

    def _get_init_attributes(self):
        """
        Return a tuple of attribute names to copy during slicing.
        """
        return ('data', 'unit', 'convolved_data', 'kernel',
                'sharpness_range', 'roundness_range', 'n_brightest',
                'peak_max', 'min_n_pixels', 'cutout_shape',
                'default_columns')

    @cached_property
    def sky(self):
        """
        Calculate the sky background level.

        The local sky level is roughly estimated using the IRAF
        starfind calculation as the average value of the pixels in the
        kernel array that are outside the kernel footprint. If there
        are no such pixels, the sky is the central data value minus the
        central convolved data value.
        """
        skymask = ~self.kernel.mask.astype(bool)  # True=sky, False=obj
        n_sky = np.count_nonzero(skymask)
        if n_sky == 0:
            # The kernel footprint covers the entire kernel array, so
            # there are no sky pixels. As in IRAF starfind, the sky is
            # then the central data value minus the central convolved
            # data value (the best-fitting Gaussian amplitude).
            ycen, xcen = (size // 2 for size in self.cutout_shape)
            cutout_conv = self.make_cutouts(self.convolved_data)
            return (self.cutout_data_nosub[:, ycen, xcen]
                    - cutout_conv[:, ycen, xcen])

        axis = (1, 2)
        sky = np.sum(self.cutout_data_nosub * skymask, axis=axis) / n_sky

        if self.unit is not None:
            sky <<= self.unit

        return sky

    @cached_property
    def cutout_data_nosub(self):
        """
        The cutout data without sky subtraction or masking.
        """
        return self.make_cutouts(self.data)

    @cached_property
    def cutout_data(self):
        """
        The cutout data with sky subtraction and masking applied.
        """
        # This is a freshly computed array, so in-place modification is
        # safe.
        data = ((self.cutout_data_nosub - self.sky[:, np.newaxis, np.newaxis])
                * self.kernel.mask)
        # IRAF starfind discards negative pixels
        data[data < 0] = 0.0
        return data

    @cached_property
    def n_pixels(self):
        """
        The total number of (positive) unmasked pixels in the cutout
        data.
        """
        return np.count_nonzero(self.cutout_data, axis=(1, 2))

    @cached_property
    def cutout_xorigin(self):
        """
        The x pixel coordinate of the cutout origin.
        """
        return np.transpose(self.xypos)[0] - self.kernel.x_radius

    @cached_property
    def cutout_yorigin(self):
        """
        The y pixel coordinate of the cutout origin.
        """
        return np.transpose(self.xypos)[1] - self.kernel.y_radius

    @cached_property
    def x_centroid(self):
        """
        The x pixel coordinate of the object centroid.
        """
        return self.cutout_x_centroid + self.cutout_xorigin

    @cached_property
    def y_centroid(self):
        """
        The y pixel coordinate of the object centroid.
        """
        return self.cutout_y_centroid + self.cutout_yorigin

    @cached_property
    def sharpness(self):
        """
        The sharpness of the object.
        """
        return self.fwhm / self.kernel.fwhm

    def apply_filters(self):
        """
        Filter the catalog.
        """
        attrs = ('x_centroid', 'y_centroid', 'sharpness', 'roundness',
                 'orientation', 'sky', 'peak', 'flux')
        initial_mask = self.n_pixels >= self.min_n_pixels
        newcat = self._filter_finite(attrs, initial_mask=initial_mask)
        if newcat is None:
            return None

        bounds = [
            ('sharpness', self.sharpness_range),
            ('roundness', self.roundness_range),
        ]

        # As in IRAF starfind, reject sources with a centroid outside the
        # image
        ny, nx = newcat.data.shape
        mask = ((newcat.x_centroid >= -0.5)
                & (newcat.x_centroid <= nx - 0.5)
                & (newcat.y_centroid >= -0.5)
                & (newcat.y_centroid <= ny - 0.5))
        return newcat._filter_bounds(bounds, initial_mask=mask)
