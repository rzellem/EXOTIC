# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Tools for generating radial profiles.
"""

import warnings
from functools import cached_property

import numpy as np
from astropy.modeling.fitting import TRFLSQFitter
from astropy.modeling.models import Gaussian1D, Moffat1D
from astropy.stats import gaussian_sigma_to_fwhm
from astropy.utils.exceptions import AstropyUserWarning

from photutils.aperture.core import _update_method_subpixels_docstring
from photutils.profiles.core import ProfileBase

__all__ = ['RadialProfile']


@_update_method_subpixels_docstring
class RadialProfile(ProfileBase):
    """
    Class to create a radial profile using concentric circular annulus
    apertures.

    The radial profile represents the azimuthally-averaged flux in
    circular annulus apertures as a function of radius.

    For this class, the input radii represent the edges of the radial
    bins. This differs from the `CurveOfGrowth` class, where the input
    radii are the radii of the circular apertures used to compute the
    cumulative flux.

    The output `radius` attribute represents the bin centers.

    Parameters
    ----------
    data : 2D `~numpy.ndarray` or `~astropy.units.Quantity`
        The 2D data array. The data should be background-subtracted.
        Nonfinite values (e.g., NaN or inf) in the ``data`` or
        ``error`` array are automatically masked.

    xycen : tuple of 2 floats
        The ``(x, y)`` pixel coordinate of the source center.

    radii : 1D array_like of float
        An array of radii defining the *edges* of the radial bins.
        ``radii`` must be strictly increasing with a minimum value
        greater than or equal to zero, and contain at least 2 values.
        The radial spacing does not need to be constant. ``radii`` must
        be in pixels and cannot be a `~astropy.units.Quantity`. The
        output `radius` attribute will be defined at the bin centers.

    error : 2D `~numpy.ndarray` or `~astropy.units.Quantity`, optional
        The 1-sigma errors of the input ``data``. ``error`` is assumed
        to include all sources of error, including the Poisson error of
        the sources (see `~photutils.utils.calc_total_error`). ``error``
        must have the same shape as the input ``data``. If ``data`` is a
        `~astropy.units.Quantity`, then ``error`` must have the same
        units. Nonfinite values (e.g., NaN or inf) in the ``data`` or
        ``error`` array are automatically masked.

    mask : 2D bool `~numpy.ndarray`, optional
        A boolean mask with the same shape as ``data`` where a `True`
        value indicates the corresponding element of ``data`` is masked.
        Masked data are excluded from all calculations.

    <method_subpixels_descriptions>

    Raises
    ------
    TypeError
        If ``radii`` is a `~astropy.units.Quantity`.

    ValueError
        If ``data`` is not a 2D array, if ``radii`` is not a 1D array
        with at least two values, has a negative value, or is not
        strictly increasing, if ``error`` or ``mask`` does not have the
        same shape as ``data``, if ``data`` and ``error`` do not have
        the same units, or if ``method`` or ``subpixels`` is invalid.

    Warns
    -----
    `~astropy.utils.exceptions.AstropyUserWarning`
        If the ``data`` or ``error`` array contains nonfinite values
        that are not already masked by ``mask``.

    See Also
    --------
    CurveOfGrowth

    Notes
    -----
    If the minimum of ``radii`` is zero, then a circular aperture
    with radius equal to ``radii[1]`` will be used for the innermost
    aperture.

    A radial bin whose pixels are all masked has zero unmasked area,
    and its profile and profile error values are NaN.

    Examples
    --------
    >>> import numpy as np
    >>> from astropy.modeling.models import Gaussian2D
    >>> from photutils.centroids import centroid_2dg
    >>> from photutils.datasets import make_noise_image
    >>> from photutils.profiles import RadialProfile

    Create an artificial single source. Note that this image does not
    have any background.

    >>> gmodel = Gaussian2D(42.1, 47.8, 52.4, 4.7, 4.7, 0)
    >>> yy, xx = np.mgrid[0:100, 0:100]
    >>> data = gmodel(xx, yy)
    >>> bkg_sig = 2.1
    >>> noise = make_noise_image(data.shape, mean=0., stddev=bkg_sig, seed=0)
    >>> data += noise
    >>> error = np.zeros_like(data) + bkg_sig

    Create the radial profile.

    >>> xycen = centroid_2dg(data)
    >>> edge_radii = np.arange(25)
    >>> rp = RadialProfile(data, xycen, edge_radii, error=error)

    >>> print(rp.radius)
    [ 0.5  1.5  2.5  3.5  4.5  5.5  6.5  7.5  8.5  9.5 10.5 11.5 12.5 13.5
     14.5 15.5 16.5 17.5 18.5 19.5 20.5 21.5 22.5 23.5]

    >>> print(rp.profile)
    [ 4.30187860e+01  4.02502046e+01  3.57758011e+01  3.16071235e+01
      2.61511082e+01  2.10539746e+01  1.63701300e+01  1.16674718e+01
      8.12828014e+00  5.78962699e+00  3.59342666e+00  2.35353336e+00
      1.20355937e+00  7.67093923e-01  4.24650784e-01  8.67989701e-02
      5.11484374e-02 -9.82041768e-02  2.37482124e-02 -3.66602855e-02
      6.84802299e-02  1.72239596e-01 -3.86056497e-02  7.30423743e-02]

    >>> print(rp.profile_error)
    [0.9901437  0.64531698 0.51234751 0.43720335 0.38782635 0.35176132
     0.32440232 0.3025968  0.28456077 0.26947982 0.25644723 0.24531375
     0.23540592 0.2266079  0.21875692 0.21164247 0.20525699 0.19930521
     0.19389598 0.18892207 0.18429087 0.1800127  0.17593986 0.17221504]

    Plot the radial profile, including the raw data profile.

    .. plot::

        import matplotlib.pyplot as plt
        import numpy as np
        from astropy.modeling.models import Gaussian2D

        from photutils.centroids import centroid_2dg
        from photutils.datasets import make_noise_image
        from photutils.profiles import RadialProfile

        # Create an artificial single source
        gmodel = Gaussian2D(42.1, 47.8, 52.4, 4.7, 4.7, 0)
        yy, xx = np.mgrid[0:100, 0:100]
        data = gmodel(xx, yy)
        bkg_sig = 2.1
        noise = make_noise_image(data.shape, mean=0., stddev=bkg_sig, seed=0)
        data += noise
        error = np.zeros_like(data) + bkg_sig

        # Find the source centroid
        xycen = centroid_2dg(data)

        # Create the radial profile
        edge_radii = np.arange(25)
        rp = RadialProfile(data, xycen, edge_radii, error=error)

        # Plot the radial profile
        fig, ax = plt.subplots(figsize=(8, 6))
        rp.plot(ax=ax, color='C0')
        rp.plot_error(ax=ax)
        ax.scatter(rp.data_radius, rp.data_profile, s=1, color='C1')

    Normalize the profile and plot the normalized radial profile.

    .. plot::

        import matplotlib.pyplot as plt
        import numpy as np
        from astropy.modeling.models import Gaussian2D

        from photutils.centroids import centroid_2dg
        from photutils.datasets import make_noise_image
        from photutils.profiles import RadialProfile

        # Create an artificial single source
        gmodel = Gaussian2D(42.1, 47.8, 52.4, 4.7, 4.7, 0)
        yy, xx = np.mgrid[0:100, 0:100]
        data = gmodel(xx, yy)
        bkg_sig = 2.1
        noise = make_noise_image(data.shape, mean=0., stddev=bkg_sig, seed=0)
        data += noise
        error = np.zeros_like(data) + bkg_sig

        # Find the source centroid
        xycen = centroid_2dg(data)

        # Create the radial profile
        edge_radii = np.arange(25)
        rp = RadialProfile(data, xycen, edge_radii, error=error)

        # Plot the radial profile
        rp.normalize()
        fig, ax = plt.subplots(figsize=(8, 6))
        rp.plot(ax=ax)
        rp.plot_error(ax=ax)

    Plot three of the annulus apertures on the data.

    .. plot::

        import matplotlib.pyplot as plt
        import numpy as np
        from astropy.modeling.models import Gaussian2D
        from astropy.visualization import simple_norm

        from photutils.centroids import centroid_2dg
        from photutils.datasets import make_noise_image
        from photutils.profiles import RadialProfile

        # Create an artificial single source
        gmodel = Gaussian2D(42.1, 47.8, 52.4, 4.7, 4.7, 0)
        yy, xx = np.mgrid[0:100, 0:100]
        data = gmodel(xx, yy)
        bkg_sig = 2.1
        noise = make_noise_image(data.shape, mean=0., stddev=bkg_sig, seed=0)
        data += noise
        error = np.zeros_like(data) + bkg_sig

        # Find the source centroid
        xycen = centroid_2dg(data)

        # Create the radial profile
        edge_radii = np.arange(25)
        rp = RadialProfile(data, xycen, edge_radii, error=error)

        norm = simple_norm(data, 'sqrt')
        fig, ax = plt.subplots(figsize=(5, 5))
        ax.imshow(data, norm=norm, origin='lower')
        rp.apertures[5].plot(ax=ax, color='C0', lw=2)
        rp.apertures[10].plot(ax=ax, color='C1', lw=2)
        rp.apertures[15].plot(ax=ax, color='C3', lw=2)

    Fit 1D Gaussian and Moffat models to the normalized radial profile.

    >>> rp.normalize()
    >>> rp.gaussian_fit
    <Gaussian1D(amplitude=0.98231087, mean=0., stddev=4.67512787)>
    >>> rp.moffat_fit
    <Moffat1D(amplitude=..., x_0=0., gamma=..., alpha=...)>
    >>> print(rp.gaussian_fwhm)
    11.009084813327853
    >>> print(rp.moffat_fwhm)
    10.868426520785151

    Plot the fitted 1D Gaussian and Moffat models on the radial profile.

    .. plot::

        import matplotlib.pyplot as plt
        import numpy as np
        from astropy.modeling.models import Gaussian2D

        from photutils.centroids import centroid_2dg
        from photutils.datasets import make_noise_image
        from photutils.profiles import RadialProfile

        # Create an artificial single source
        gmodel = Gaussian2D(42.1, 47.8, 52.4, 4.7, 4.7, 0)
        yy, xx = np.mgrid[0:100, 0:100]
        data = gmodel(xx, yy)
        bkg_sig = 2.1
        noise = make_noise_image(data.shape, mean=0., stddev=bkg_sig, seed=0)
        data += noise
        error = np.zeros_like(data) + bkg_sig

        # Find the source centroid
        xycen = centroid_2dg(data)

        # Create the radial profile
        edge_radii = np.arange(25)
        rp = RadialProfile(data, xycen, edge_radii, error=error)

        # Plot the radial profile
        rp.normalize()
        fig, ax = plt.subplots(figsize=(8, 6))
        rp.plot(ax=ax, label='Radial Profile')
        rp.plot_error(ax=ax)
        ax.plot(rp.radius, rp.gaussian_profile, label='Gaussian Fit')
        ax.plot(rp.radius, rp.moffat_profile, label='Moffat Fit')
        ax.legend()
    """

    # Define y-axis label used by `~photutils.profiles.ProfileBase.plot`
    _ylabel = 'Radial Profile'

    @cached_property
    def radius(self):
        """
        The profile radius (bin centers) in pixels as a 1D
        `~numpy.ndarray`.

        The returned radius values are defined as the arithmetic means
        of the input radial-bin edges (``radii``).

        For logarithmically-spaced input ``radii``, one could instead
        use a radius array defined using the geometric mean of the bin
        edges, i.e., ``np.sqrt(radii[:-1] * radii[1:])``.
        """
        # Define the radial bin centers from the radial bin edges
        return (self.radii[:-1] + self.radii[1:]) / 2

    @cached_property
    def apertures(self):
        """
        A list of the circular annulus apertures used to measure the
        radial profile, as `~photutils.aperture.CircularAnnulus`
        objects.

        If the minimum of ``radii`` is zero, then the innermost element
        will be a `~photutils.aperture.CircularAperture` with radius
        equal to ``radii[1]``.
        """
        # Prevent circular imports
        from photutils.aperture import CircularAnnulus, CircularAperture

        apertures = []
        for i in range(len(self.radii) - 1):
            try:
                aperture = CircularAnnulus(self.xycen, self.radii[i],
                                           self.radii[i + 1])
            except ValueError:  # zero radius
                aperture = CircularAperture(self.xycen,
                                            self.radii[i + 1])
            apertures.append(aperture)

        return apertures

    @cached_property
    def _flux(self):
        """
        The flux in each circular annulus (or aperture) as a 1D array.
        """
        return np.diff(self._photometry[0])

    @cached_property
    def _flux_err(self):
        """
        The flux error in each circular annulus (or aperture) as a 1D
        array.
        """
        return np.sqrt(np.diff(self._photometry[1] ** 2))

    @cached_property
    def area(self):
        """
        The unmasked area in each circular annulus (or aperture) as a
        function of radius as a 1D `~numpy.ndarray`.
        """
        return np.diff(self._photometry[2])

    @cached_property
    def _raw_profile(self):
        """
        The raw (unnormalized) radial profile as a 1D `~numpy.ndarray`,
        or a `~astropy.units.Quantity` if the input ``data`` has units.
        """
        # Ignore divide-by-zero RuntimeWarning
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', RuntimeWarning)
            return self._flux / self.area

    @cached_property
    def _raw_profile_error(self):
        """
        The raw (unnormalized) radial profile errors as a 1D
        `~numpy.ndarray`, or a `~astropy.units.Quantity` if the input
        ``data`` has units.

        If no ``error`` array was provided, an empty array with shape
        ``(0,)`` is returned.
        """
        if self.error is None:
            return self._flux_err

        # Ignore divide-by-zero RuntimeWarning
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', RuntimeWarning)
            return self._flux_err / self.area

    @cached_property
    def _profile_nanmask(self):
        return np.isfinite(self._raw_profile)

    def _normalize_fit(self, raw_fit):
        """
        Return a copy of a raw fit with its amplitude divided by the
        current profile normalization.
        """
        fit = raw_fit.copy()
        # The amplitude has units if the input data has units
        amplitude = raw_fit.amplitude.quantity
        if amplitude is None:
            amplitude = raw_fit.amplitude.value
        fit.amplitude = amplitude / self.normalization_value
        return fit

    @cached_property
    def _raw_gaussian_fit(self):
        """
        The 1D Gaussian fitted to the raw (unnormalized) radial profile,
        or `None` if the profile is entirely nonfinite or masked.
        """
        profile = self._raw_profile[self._profile_nanmask]
        radius = self.radius[self._profile_nanmask]

        if len(profile) == 0:
            msg = ('The radial profile is entirely nonfinite or masked. '
                   'Cannot fit a Gaussian.')
            warnings.warn(msg, AstropyUserWarning)
            return None

        amplitude = np.max(profile)
        sum_profile = np.sum(profile)
        if sum_profile == 0:
            msg = ('The profile sum is zero, so the Gaussian fit initial '
                   'guess may be inaccurate.')
            warnings.warn(msg, AstropyUserWarning)
            std = 1.0  # fallback to avoid zero initial guess
        else:
            std = np.sqrt(abs(np.sum(profile * radius**2) / sum_profile))
            std = max(std, 1.0)  # guard against near-zero initial guess
        g_init = Gaussian1D(amplitude=amplitude, mean=0.0, stddev=std)
        g_init.mean.fixed = True
        fitter = TRFLSQFitter()
        gaussian_fit = fitter(g_init, radius, profile)

        if radius.min() > 0.3 * gaussian_fit.stddev.value:
            msg = ('Gaussian fit may be unreliable because the smallest '
                   'radius with a finite profile value is larger than '
                   '0.3 times the fitted standard deviation.')
            warnings.warn(msg, AstropyUserWarning)

        return gaussian_fit

    @property
    def gaussian_fit(self):
        """
        The fitted 1D Gaussian to the radial profile as a
        `~astropy.modeling.functional_models.Gaussian1D` model.

        The model amplitude reflects the current profile normalization
        (the Gaussian amplitude scales linearly with the profile
        values). The mean and standard deviation are independent of the
        normalization.

        The fit uses only the finite profile values, and the Gaussian
        mean is fixed at zero (the source center).

        Returns `None` if the profile is entirely nonfinite or masked.

        Warns
        -----
        `~astropy.utils.exceptions.AstropyUserWarning`
            If the profile is entirely nonfinite or masked, if the sum
            of the profile is zero, or if the smallest bin center with a
            finite profile value is larger than 0.3 times the fitted
            standard deviation (e.g., the input radii do not extend
            close to the source center or the inner bins are masked).
            The fitter can also emit its own warning if the fit may not
            have converged.
        """
        raw_fit = self._raw_gaussian_fit
        if raw_fit is None:
            return None
        return self._normalize_fit(raw_fit)

    @property
    def gaussian_profile(self):
        """
        The fitted 1D Gaussian profile to the radial profile as a 1D
        `~numpy.ndarray`, or a `~astropy.units.Quantity` if the input
        ``data`` has units.

        The values reflect the current profile normalization.

        Returns `None` if the profile is entirely nonfinite or masked.
        """
        if self._raw_gaussian_profile is None:
            return None
        return self._raw_gaussian_profile / self.normalization_value

    @cached_property
    def _raw_gaussian_profile(self):
        """
        The raw-fit 1D Gaussian evaluated at the profile radii, or
        `None` if the profile is entirely nonfinite or masked.
        """
        if self._raw_gaussian_fit is None:
            return None
        return self._raw_gaussian_fit(self.radius)

    @property
    def gaussian_fwhm(self):
        """
        The full width at half maximum (FWHM) in pixels of the 1D
        Gaussian fitted to the radial profile.

        The FWHM is independent of the profile normalization.

        Returns `None` if the profile is entirely nonfinite or masked.
        """
        if self._raw_gaussian_fit is None:
            return None
        return self._raw_gaussian_fit.stddev.value * gaussian_sigma_to_fwhm

    @cached_property
    def _raw_moffat_fit(self):
        """
        The 1D Moffat fitted to the raw (unnormalized) radial profile,
        or `None` if the profile is entirely nonfinite or masked.
        """
        profile = self._raw_profile[self._profile_nanmask]
        radius = self.radius[self._profile_nanmask]

        if len(profile) == 0:
            msg = ('The radial profile is entirely nonfinite or masked. '
                   'Cannot fit a Moffat.')
            warnings.warn(msg, AstropyUserWarning)
            return None

        amplitude = np.max(profile)
        sum_profile = np.sum(profile)
        if sum_profile == 0:
            msg = ('The profile sum is zero, so the Moffat fit initial '
                   'guess may be inaccurate.')
            warnings.warn(msg, AstropyUserWarning)
            gamma = 1.0  # fallback to avoid zero initial guess
        else:
            # Estimate gamma from the half-max radius
            half_max = amplitude / 2.0
            above = profile >= half_max
            gamma = (max(np.max(radius[above]), 1.0)
                     if np.any(above) else 1.0)

        m_init = Moffat1D(amplitude=amplitude, x_0=0.0, gamma=gamma,
                          alpha=2.5)
        m_init.x_0.fixed = True
        m_init.gamma.bounds = (0, None)
        m_init.alpha.bounds = (1, 25)
        fitter = TRFLSQFitter()
        return fitter(m_init, radius, profile)

    @property
    def moffat_fit(self):
        """
        The fitted 1D Moffat to the radial profile as a
        `~astropy.modeling.functional_models.Moffat1D` model.

        The model amplitude reflects the current profile normalization
        (the Moffat amplitude scales linearly with the profile
        values). The core width and power index are independent of the
        normalization.

        The fit uses only the finite profile values. The Moffat ``x_0``
        is fixed at zero (the source center) and ``alpha`` is bounded to
        the range [1, 25].

        Returns `None` if the profile is entirely nonfinite or masked.

        Warns
        -----
        `~astropy.utils.exceptions.AstropyUserWarning`
            If the profile is entirely nonfinite or masked, or if the
            sum of the profile is zero. The fitter can also emit its own
            warning if the fit may not have converged.
        """
        raw_fit = self._raw_moffat_fit
        if raw_fit is None:
            return None
        return self._normalize_fit(raw_fit)

    @property
    def moffat_profile(self):
        """
        The fitted 1D Moffat profile to the radial profile as a 1D
        `~numpy.ndarray`, or a `~astropy.units.Quantity` if the input
        ``data`` has units.

        The values reflect the current profile normalization.

        Returns `None` if the profile is entirely nonfinite or masked.
        """
        if self._raw_moffat_profile is None:
            return None
        return self._raw_moffat_profile / self.normalization_value

    @cached_property
    def _raw_moffat_profile(self):
        """
        The raw-fit 1D Moffat evaluated at the profile radii, or
        `None` if the profile is entirely nonfinite or masked.
        """
        if self._raw_moffat_fit is None:
            return None
        return self._raw_moffat_fit(self.radius)

    @property
    def moffat_fwhm(self):
        """
        The full width at half maximum (FWHM) in pixels of the 1D Moffat
        fitted to the radial profile.

        The FWHM is independent of the profile normalization.

        Returns `None` if the profile is entirely nonfinite or masked.
        """
        if self._raw_moffat_fit is None:
            return None
        return self._raw_moffat_fit.fwhm

    @cached_property
    def _data_profile(self):
        """
        The raw (unnormalized) data profile returned as 1D arrays
        of radii (`~numpy.ndarray`) and data values (`~numpy.ndarray`,
        or `~astropy.units.Quantity` if the input ``data`` has units).

        Returns the radii and values of the unmasked data points between
        the minimum and maximum radii defined by the input radii. Pixels
        flagged in ``self.mask`` (including auto-masked nonfinite
        values) are excluded.
        """
        shape = self.data.shape
        min_radius = np.min(self.radii)
        max_radius = np.max(self.radii)
        # The bounding box must include the pixels whose centers lie
        # exactly at max_radius, so the (exclusive) upper slice bounds
        # are floor(center + max_radius) + 1
        x_min = int(max(np.floor(self.xycen[0] - max_radius), 0))
        x_max = int(min(np.floor(self.xycen[0] + max_radius) + 1, shape[1]))
        y_min = int(max(np.floor(self.xycen[1] - max_radius), 0))
        y_max = int(min(np.floor(self.xycen[1] + max_radius) + 1, shape[0]))
        yidx, xidx = np.indices((y_max - y_min, x_max - x_min))
        xidx += x_min
        yidx += y_min

        # Calculate the radii of the pixels from the center and select
        # those between the minimum and maximum radii defined by the
        # input radii
        radii = np.hypot(xidx - self.xycen[0], yidx - self.xycen[1])
        within = (radii >= min_radius) & (radii <= max_radius)
        radii = radii[within]
        yidx_sub = yidx[within]
        xidx_sub = xidx[within]

        # Exclude masked pixels (user mask and auto-masked nonfinite
        # values)
        valid = ~self.mask[yidx_sub, xidx_sub]
        radii = radii[valid]
        data_values = self.data[yidx_sub[valid], xidx_sub[valid]]
        if self.unit is not None:
            data_values = data_values << self.unit

        return radii, data_values

    @cached_property
    def data_radius(self):
        """
        The radial distances in pixels of the raw data points from the
        source center as a 1D `~numpy.ndarray`.

        All unmasked pixels whose centers lie between the minimum and
        maximum of the input ``radii``, inclusive, are included.
        """
        return self._data_profile[0]

    @property
    def data_profile(self):
        """
        The raw data values of the pixels at `data_radius` as a 1D
        `~numpy.ndarray`, or a `~astropy.units.Quantity` if the input
        ``data`` has units.

        The values reflect the current profile normalization. If
        `~photutils.profiles.ProfileBase.normalize` has been called, the
        raw data values are divided by the same normalization applied to
        ``profile``.
        """
        return self._data_profile[1] / self.normalization_value
