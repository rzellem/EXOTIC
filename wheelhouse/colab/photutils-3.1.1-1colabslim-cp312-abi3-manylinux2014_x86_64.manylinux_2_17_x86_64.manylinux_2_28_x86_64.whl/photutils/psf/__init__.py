# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Subpackage containing tools for performing point-spread-function (PSF)
photometry.
"""

from .epsf_builder import *  # noqa: F401, F403
from .epsf_stars import *  # noqa: F401, F403
from .flags import *  # noqa: F401, F403
from .functional_models import *  # noqa: F401, F403
from .gridded_models import *  # noqa: F401, F403
from .groupers import *  # noqa: F401, F403
from .image_models import *  # noqa: F401, F403
from .iterative import *  # noqa: F401, F403
from .model_helpers import *  # noqa: F401, F403
from .model_io import *  # noqa: F401, F403
from .model_plotting import *  # noqa: F401, F403
from .photometry import *  # noqa: F401, F403
from .simulation import *  # noqa: F401, F403
from .utils import *  # noqa: F401, F403


def __getattr__(name):
    # EPSFBuildResult was renamed to EPSFBuildResults in 3.1.
    if name == 'EPSFBuildResult':
        import warnings

        from photutils.utils.exceptions import PhotutilsDeprecationWarning

        from .epsf_builder import EPSFBuildResults

        msg = ('EPSFBuildResult is deprecated and will be removed in '
               'version 4.0. Use EPSFBuildResults instead.')
        warnings.warn(msg, PhotutilsDeprecationWarning, stacklevel=2)
        return EPSFBuildResults

    msg = f'module {__name__!r} has no attribute {name!r}'
    raise AttributeError(msg)
