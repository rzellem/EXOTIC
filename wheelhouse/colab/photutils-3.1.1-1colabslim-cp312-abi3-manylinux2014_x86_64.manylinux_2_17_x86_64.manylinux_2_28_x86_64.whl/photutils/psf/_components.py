# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Private implementation classes for PSF photometry components.

This is a private module. Its classes and functions are implementation
details of the PSF photometry classes and are not intended for direct
public use.
"""

import contextlib
import warnings
from copy import deepcopy

import astropy.units as u
import numpy as np
from astropy.modeling import Fittable2DModel, Parameter
from astropy.modeling.fitting import TRFLSQFitter
from astropy.nddata import NDData, NoOverlapError
from astropy.table import QTable, Table, hstack, join
from astropy.utils.exceptions import AstropyUserWarning

from photutils.aperture import AperturePhotometry, CircularAperture
from photutils.datasets import make_model_image as _make_model_image
from photutils.utils._deprecation import DeprecatedColumnQTable
from photutils.utils._flags import update_flag_docstring
from photutils.utils._misc import _get_meta
from photutils.utils._overlap import overlap_slices

from .flags import PSF_FLAGS

__all__ = ['PSFDataProcessor', 'PSFFitter', 'PSFResultsAssembler']


def _apply_bounds_to_param(model, param_name, param_value, bound_value):
    """
    Apply bounds to a specific model parameter.

    This is a general helper function for applying symmetric bounds
    around a parameter value.

    Parameters
    ----------
    model : `~astropy.modeling.Model`
        The model containing the parameter.

    param_name : str
        Name of the parameter to apply bounds to.

    param_value : float
        Current value of the parameter.

    bound_value : float or None
        The bound offset (parameter will be bounded to
        [param_value - bound_value, param_value + bound_value]). If
        None, no bounds are applied.
    """
    if bound_value is not None:
        param_obj = getattr(model, param_name)
        param_obj.bounds = (param_value - bound_value,
                            param_value + bound_value)


def _update_flags_docstring(func):
    """
    Decorator to insert the PSF flag descriptions into a docstring.

    The ``<flag_descriptions>`` placeholder in the function docstring is
    replaced with a bullet list generated from ``PSF_FLAGS``.

    Parameters
    ----------
    func : function
        The function to decorate.

    Returns
    -------
    func : function
        The decorated function with an updated docstring.
    """
    return update_flag_docstring(func, PSF_FLAGS, indent=None)


def _create_flat_model_class(n_sources, psf_model):
    """
    Create a new flat model class for the given number of sources.

    This function creates a dynamically-generated flat model class that
    avoids CompoundModel by creating a custom model class where all
    parameters are top-level (e.g., x_0_0, y_0_0, flux_0, x_0_1, y_0_1,
    flux_1, etc., which is each base parameter name followed by the
    source index) rather than nested. This eliminates the parameter tree
    traversal and nested structure overhead of CompoundModel.

    The dynamic flat model class directly evaluates each PSF and sums them,
    providing much better performance for large groups.

    Each flat parameter copies the default value, fixed status, and
    bounds from the base PSF model parameter. Tied constraints are not
    propagated to grouped fits.

    Parameters
    ----------
    n_sources : int
        Number of sources in the group.

    psf_model : `~astropy.modeling.Model`
        Base PSF model to be used for all sources.

    Returns
    -------
    model_class : type
        Dynamically created flat model class for the specified number
        of sources.
    """
    base_param_names = list(psf_model.param_names)
    base_psf_model = psf_model.copy()

    # Create class attributes dictionary
    class_attrs = {}

    # Add parameters as class attributes (with default values)
    for i in range(n_sources):
        for base_param in base_param_names:
            flat_param_name = f'{base_param}_{i}'
            # Use default value, fixed status, and bounds from the
            # base PSF model. Note that tied constraints are not
            # propagated to grouped fits.
            base_param_obj = getattr(base_psf_model, base_param)
            default_value = base_param_obj.value
            is_fixed = base_param_obj.fixed
            param = Parameter(default=default_value, fixed=is_fixed,
                              bounds=base_param_obj.bounds)
            class_attrs[flat_param_name] = param

    # Add methods
    def model_init(self, **kwargs):
        super(type(self), self).__init__(**kwargs)
        self.n_sources = n_sources
        # All instances share this single model copy. This is safe
        # only because evaluate() is stateless.
        self.base_psf_model = base_psf_model
        self.base_param_names = base_param_names

    def evaluate(self, x, y, *params):
        """
        Evaluate the flat PSF group model.

        This efficiently evaluates each PSF with its parameters and sums
        the results, avoiding CompoundModel overhead.
        """
        result = np.zeros_like(x, dtype=float)

        # Evaluate each source's PSF contribution
        for i in range(self.n_sources):
            # Extract parameters for this source
            source_params = []
            for j, _ in enumerate(self.base_param_names):
                param_idx = i * len(self.base_param_names) + j
                source_params.append(params[param_idx])

            # Evaluate this source's PSF and add to result
            result += self.base_psf_model.evaluate(x, y, *source_params)

        return result

    class_attrs['__init__'] = model_init
    class_attrs['evaluate'] = evaluate
    class_attrs['__doc__'] = (f'Cached flat PSF model for '
                              f'{n_sources} sources.')

    # Create the dynamic class with descriptive name
    class_name = f'FlatPSFGroupModel_{n_sources}'
    return type(class_name, (Fittable2DModel,), class_attrs)


def _instantiate_flat_model(model_class, sources, psf_model, param_mapper, *,
                            xy_bounds=None):
    """
    Create an instance of a flat model class with source-specific
    parameter values and bounds.

    Parameters
    ----------
    model_class : type
        Flat model class created by `_create_flat_model_class`.

    sources : `~astropy.table.Table` or list of `~astropy.table.Row`
        List of source rows from the sources table for the group.

    psf_model : `~astropy.modeling.Model`
        Base PSF model used for parameter defaults.

    param_mapper : object
        Parameter mapper for handling column name mappings and model
        parameters. Must have ``alias_to_model_param`` and
        ``init_colnames`` attributes.

    xy_bounds : 2-element sequence of float or None, or None, optional
        Bounds for x and y position parameters as (x_bound, y_bound).
        If provided, fitting positions will be constrained to within
        these bounds of the initial values. An element of `None` means
        no bound along that axis.

    Returns
    -------
    model : `~astropy.modeling.Model`
        Instance of the flat model with parameter values set from sources
        and bounds applied.
    """
    alias_map = param_mapper.alias_to_model_param
    init_colnames = param_mapper.init_colnames

    # Create model instance
    model = model_class()

    # Set source-specific parameter values and bounds
    for i, source in enumerate(sources):
        for base_param in psf_model.param_names:
            flat_param_name = f'{base_param}_{i}'

            # Get initial value from source
            init_value = None
            for alias, col_name in init_colnames.items():
                if alias_map[alias] == base_param:
                    init_value = source[col_name]
                    if isinstance(init_value, u.Quantity):
                        init_value = init_value.value
                    break

            if init_value is None:
                init_value = getattr(psf_model, base_param).value

            # Set parameter value
            setattr(model, flat_param_name, init_value)

            # Apply xy bounds if needed
            if (xy_bounds is not None and base_param == alias_map.get('x')
                    and xy_bounds[0] is not None):
                _apply_bounds_to_param(model, flat_param_name, init_value,
                                       xy_bounds[0])
            elif (xy_bounds is not None and base_param == alias_map.get('y')
                  and xy_bounds[1] is not None):
                _apply_bounds_to_param(model, flat_param_name, init_value,
                                       xy_bounds[1])

    return model


def _get_flat_model(sources, psf_model, param_mapper, *, xy_bounds=None,
                    class_cache=None):
    """
    Get or create a flat model for a group of sources.

    The dynamically-generated flat model classes can be cached to
    avoid recreating them for groups with the same number of sources,
    improving performance when processing many groups.

    A cached class captures a copy of ``psf_model`` (including its
    parameter values, fixed flags, and bounds), so a given cache dict is
    valid only for a single, fixed ``psf_model``. The caller owns the
    cache dict and must not share it between different PSF models.

    Parameters
    ----------
    sources : `~astropy.table.Table` or list of `~astropy.table.Row`
        List of source rows from the sources table for the group.

    psf_model : `~astropy.modeling.Model`
        Base PSF model to be used for all sources.

    param_mapper : object
        Parameter mapper for handling column name mappings and model
        parameters.

    xy_bounds : 2-element sequence of float or None, or None, optional
        Bounds for x and y position parameters as (x_bound, y_bound).
        An element of `None` means no bound along that axis.

    class_cache : dict or None, optional
        Cache of flat model classes keyed on the number of sources. If
        `None`, a new class is always created.

    Returns
    -------
    model : `~astropy.modeling.Model`
        Flat model instance for the group of sources with parameters
        set from the sources and bounds applied.
    """
    n_sources = len(sources)
    if class_cache is None:
        model_class = _create_flat_model_class(n_sources, psf_model)
    else:
        model_class = class_cache.get(n_sources)
        if model_class is None:
            model_class = _create_flat_model_class(n_sources,
                                                   psf_model)
            class_cache[n_sources] = model_class

    # Create instance with source-specific parameter values
    return _instantiate_flat_model(model_class, sources, psf_model,
                                   param_mapper, xy_bounds=xy_bounds)


class PSFDataProcessor:
    """
    Helper class to handle data validation, preprocessing, and cutout
    extraction for PSF photometry.

    This class encapsulates all data-related operations including
    validation, source finding, initial parameter estimation, and cutout
    extraction.

    Parameters
    ----------
    param_mapper : _PSFParameterMapper
        Parameter mapper for handling column name mappings and model
        parameters.

    fit_shape : tuple of int
        The shape of the PSF fitting region as a (ny, nx) tuple.

    finder : object, optional
        Source finder instance for detecting sources if ``init_params``
        is not provided. Must have a ``__call__`` method that accepts
        data and mask arrays and returns a table of detected sources.

    aperture_radius : float, optional
        Radius in pixels of circular apertures for initial flux
        estimation when flux values are not provided in ``init_params``.

    local_bkg_estimator : object, optional
        Local background estimator for determining background levels
        around sources. Must have a ``__call__`` method.
    """

    def __init__(self, param_mapper, fit_shape, *, finder=None,
                 aperture_radius=None, local_bkg_estimator=None):
        self.param_mapper = param_mapper
        self.fit_shape = fit_shape
        self.finder = finder
        self.aperture_radius = aperture_radius
        self.local_bkg_estimator = local_bkg_estimator
        self.data_unit = None
        self.finder_results = None

        # Cache for offset grids
        self._cached_offsets = None

    def validate_array(self, array, name, *, data_shape=None):
        """
        Validate input arrays (data, error, mask).

        Parameters
        ----------
        array : array-like or None
            Input array to validate. Can be None for optional arrays.

        name : str
            Name of the array, used in error messages (e.g., 'data',
            'error', 'mask'). If 'mask', `numpy.ma.nomask` is converted
            to None and the array is converted to bool.

        data_shape : tuple of int, optional
            Expected shape of the array. If provided, validates that
            the array shape matches this shape.

        Returns
        -------
        array : `~numpy.ndarray` or None
            Validated 2D array or None if input was None.

        Raises
        ------
        ValueError
            If the array is not 2D or if the shape doesn't match
            ``data_shape`` when provided.
        """
        if name == 'mask' and array is np.ma.nomask:
            array = None
        if array is not None:
            array = np.asanyarray(array)
            if array.ndim != 2:
                msg = f'{name} must be a 2D array'
                raise ValueError(msg)
            if data_shape is not None and array.shape != data_shape:
                msg = f'data and {name} must have the same shape'
                raise ValueError(msg)
            if name == 'mask':
                # Coerce to bool so integer masks (e.g., 0/1 DQ
                # arrays) cannot be misused as fancy indices
                array = array.astype(bool)
        return array

    def normalize_init_units(self, init_params, colname):
        """
        Normalize the units of a column in the input init_params table
        to match the input data units.

        Parameters
        ----------
        init_params : `~astropy.table.Table`
            Table containing initial parameters for PSF fitting.

        colname : str
            Name of the column to normalize units for.

        Returns
        -------
        init_params : `~astropy.table.Table`
            The input table with normalized units for the specified
            column.

        Raises
        ------
        ValueError
            If there are unit compatibility issues between the column
            and the data units.
        """
        values = init_params[colname]

        # Convert a plain Column carrying a unit attribute (e.g., from
        # a Table instead of a QTable) to a Quantity
        if (not isinstance(values, u.Quantity)
                and getattr(values, 'unit', None) is not None):
            values = u.Quantity(values)

        if isinstance(values, u.Quantity):
            if self.data_unit is None:
                msg = (f'init_params {colname} column has units, but the '
                       'input data does not have units')
                raise ValueError(msg)
            try:
                init_params[colname] = values.to(self.data_unit)
            except u.UnitConversionError as exc:
                msg = (f'init_params {colname} column has units that are '
                       'incompatible with the input data units')
                raise ValueError(msg) from exc
        elif self.data_unit is not None:
            msg = (f'The input data has units, but the init_params '
                   f'{colname} column does not. It must be a Quantity '
                   'column (e.g., use a QTable).')
            raise ValueError(msg)
        return init_params

    def validate_init_params(self, init_params):
        """
        Validate the input init_params table and rename columns to
        expected format.

        Parameters
        ----------
        init_params : `~astropy.table.Table` or None
            Table containing initial parameters for PSF fitting. Must
            contain columns for x and y positions. May contain flux
            and local_bkg columns.

        Returns
        -------
        init_params : `~astropy.table.Table` or None
            Validated table with renamed columns matching expected
            format, or None if input was None.

        Raises
        ------
        TypeError
            If ``init_params`` is not an astropy Table.

        ValueError
            If required position columns are missing, or if the units
            of the flux or local_bkg column are not consistent with the
            data units (only one of them has units, or the units are
            incompatible).
        """
        if init_params is None:
            return init_params

        if not isinstance(init_params, Table):
            msg = 'init_params must be an astropy Table'
            raise TypeError(msg)

        # Copy to preserve the input init_params
        init_params = self.param_mapper.rename_table_columns(
            init_params.copy())

        if (self.param_mapper.init_colnames['x'] not in init_params.colnames
                or self.param_mapper.init_colnames['y'] not in
                init_params.colnames):
            msg = ('init_params must contain valid column names for the '
                   'x and y source positions')
            raise ValueError(msg)

        flux_col = self.param_mapper.init_colnames['flux']
        if flux_col in init_params.colnames:
            init_params = self.normalize_init_units(init_params, flux_col)

        if 'local_bkg' in init_params.colnames:
            # Nonfinite local_bkg will not be subtracted, and a flag
            # will be set in the results.
            init_params = self.normalize_init_units(init_params, 'local_bkg')

        return init_params

    def get_aper_fluxes(self, data, mask, init_params, *, local_bkg=None):
        """
        Estimate aperture fluxes at the initial (x, y) positions.

        Parameters
        ----------
        data : `~numpy.ndarray`
            2D image data array.

        mask : `~numpy.ndarray` or None
            2D boolean mask array with the same shape as ``data``, where
            ``True`` indicates masked pixels.

        init_params : `~astropy.table.Table`
            Table containing initial source positions with validated
            column names.

        local_bkg : `~numpy.ndarray` or None, optional
            The per-pixel local background level of each source. If
            input, each finite value times the unmasked aperture area
            within the image is subtracted from the aperture flux.

        Returns
        -------
        flux : `~numpy.ndarray`
            Array of aperture flux estimates for each source.
        """
        x_pos = init_params[self.param_mapper.init_colnames['x']]
        y_pos = init_params[self.param_mapper.init_colnames['y']]
        apertures = CircularAperture(zip(x_pos, y_pos, strict=True),
                                     r=self.aperture_radius)
        phot = AperturePhotometry(data, apertures, mask=mask)
        flux = phot.flux
        if local_bkg is not None:
            bkg_flux = local_bkg * phot.area.value
            finite_mask = np.isfinite(bkg_flux)
            flux = flux.copy()
            flux[finite_mask] -= bkg_flux[finite_mask]
        return flux

    def find_sources_if_needed(self, data, mask, init_params):
        """
        Find sources using the finder if initial positions are not
        provided.

        Parameters
        ----------
        data : `~numpy.ndarray`
            2D image data array.

        mask : `~numpy.ndarray` or None
            2D boolean mask array with the same shape as ``data``.

        init_params : `~astropy.table.Table` or None
            Table containing initial source parameters. If provided,
            an 'id' column is added if missing. If None, sources are
            found using the finder.

        Returns
        -------
        sources : `~astropy.table.Table` or None
            Table containing source information with required columns
            for PSF fitting, or None if no sources were found.

        Raises
        ------
        ValueError
            If ``init_params`` is None and no finder was provided.
        """
        if init_params is not None:
            if 'id' not in init_params.colnames:
                init_params['id'] = np.arange(len(init_params)) + 1
            return init_params

        if self.finder is None:
            msg = 'finder must be defined if init_params is not input'
            raise ValueError(msg)

        if self.data_unit is not None:
            sources = self.finder(data << self.data_unit, mask=mask)
        else:
            sources = self.finder(data, mask=mask)

        self.finder_results = sources
        if sources is None or len(sources) == 0:
            return None

        return self._convert_finder_to_init(sources)

    def _convert_finder_to_init(self, sources):
        """
        Convert the output table of the finder to a table with initial
        (x, y) position column names.

        Parameters
        ----------
        sources : `~astropy.table.Table`
            Table returned by the source finder containing detected
            source positions.

        Returns
        -------
        init_params : `~astropy.table.QTable`
            Table with standardized column names suitable for PSF
            fitting initialization.

        Raises
        ------
        ValueError
            If the sources table does not contain valid x and y
            coordinate columns.
        """
        # Find the first valid column names for x and y
        x_name_found = self.param_mapper.find_column(sources, 'x')
        y_name_found = self.param_mapper.find_column(sources, 'y')
        if x_name_found is None or y_name_found is None:
            msg = ("The table returned by the 'finder' must contain columns "
                   'for x and y coordinates. Valid column names are: '
                   f"x: {self.param_mapper.VALID_INIT_COLNAMES['x']}, "
                   f"y: {self.param_mapper.VALID_INIT_COLNAMES['y']}")
            raise ValueError(msg)

        # Create a new table with only the needed columns
        init_params = QTable()
        init_params['id'] = np.arange(len(sources)) + 1
        x_col = self.param_mapper.init_colnames['x']
        y_col = self.param_mapper.init_colnames['y']
        init_params[x_col] = sources[x_name_found]
        init_params[y_col] = sources[y_name_found]

        return init_params

    def estimate_flux_and_bkg_if_needed(self, data, mask, init_params):
        """
        Estimate initial fluxes and backgrounds if not provided.

        Parameters
        ----------
        data : `~numpy.ndarray`
            2D image data array.

        mask : `~numpy.ndarray` or None
            2D boolean mask array with the same shape as ``data``.

        init_params : `~astropy.table.Table`
            Table containing initial source parameters. Will be modified
            in place to add flux and/or local_bkg columns if missing.

        Returns
        -------
        init_params : `~astropy.table.Table`
            The input table with added flux and local_bkg columns if
            they were missing.

        Raises
        ------
        ValueError
            If aperture_radius is None when flux estimation is needed.
        """
        x_col = self.param_mapper.init_colnames['x']
        y_col = self.param_mapper.init_colnames['y']
        flux_col = self.param_mapper.init_colnames['flux']

        if 'local_bkg' not in init_params.colnames:
            if self.local_bkg_estimator is None:
                local_bkg = np.zeros(len(init_params))
            else:
                local_bkg = self.local_bkg_estimator(
                    data, init_params[x_col],
                    init_params[y_col], mask=mask)
            if self.data_unit is not None:
                local_bkg <<= self.data_unit
            init_params['local_bkg'] = local_bkg

        if flux_col not in init_params.colnames:
            # Check for aperture_radius before attempting to use it
            if self.aperture_radius is None:
                msg = ('aperture_radius must be defined if a flux column is '
                       'not in init_params')
                raise ValueError(msg)

            # Only finite local_bkg values are subtracted
            local_bkg = np.asarray(init_params['local_bkg'].value)
            flux = self.get_aper_fluxes(data, mask, init_params,
                                        local_bkg=local_bkg)
            if self.data_unit is not None:
                flux <<= self.data_unit

            init_params[flux_col] = flux

        return init_params

    def get_fit_offsets(self):
        """
        Return cached (y_offsets, x_offsets) arrays for fit_shape.

        Returns
        -------
        offsets : `~numpy.ndarray`
            Array of shape ``(2, ny, nx)``, where ``(ny, nx)`` is
            ``fit_shape``, that unpacks into the (y_offsets, x_offsets)
            arrays of coordinate offsets from the origin.
        """
        # fit_shape is fixed at construction, so compute only once
        if self._cached_offsets is None:
            ny, nx = self.fit_shape
            self._cached_offsets = np.mgrid[0:ny, 0:nx]

        return self._cached_offsets

    def should_skip_source(self, row, data_shape):
        """
        Quick validation to skip obviously invalid sources early.

        Parameters
        ----------
        row : `~astropy.table.Row`
            Row from the sources table containing source parameters.

        data_shape : tuple of int
            Shape of the input data array as (ny, nx).

        Returns
        -------
        should_skip : bool
            True if the source should be skipped, False otherwise.

        reason : str or None
            Reason for skipping ('invalid_position', 'non_finite_flux',
            'no_overlap') or None if not skipping.
        """
        x_cen = row[self.param_mapper.init_colnames['x']]
        y_cen = row[self.param_mapper.init_colnames['y']]
        flux_init = row[self.param_mapper.init_colnames['flux']]

        # Check for nonfinite positions
        if not (np.isfinite(x_cen) and np.isfinite(y_cen)):
            return True, 'invalid_position'

        # Check for nonfinite flux
        if not np.isfinite(flux_init):
            return True, 'non_finite_flux'

        # Sources that are clearly beyond any possible overlap
        half_fit = max(self.fit_shape) // 2
        clear_margin = half_fit + 1  # a bit beyond the fit region
        if (x_cen < -clear_margin or y_cen < -clear_margin
                or x_cen >= data_shape[1] + clear_margin
                or y_cen >= data_shape[0] + clear_margin):
            return True, 'no_overlap'

        return False, None

    def get_source_cutout_data(self, row, data, mask, y_offsets, x_offsets):
        """
        Extract per-source pixel indices and cutout data.

        Parameters
        ----------
        row : `~astropy.table.Row`
            Row from the sources table containing source parameters
            including position and local background.

        data : `~numpy.ndarray`
            2D image data array.

        mask : `~numpy.ndarray` or None
            2D boolean mask array with the same shape as ``data``.

        y_offsets, x_offsets : `~numpy.ndarray`
            2D array of y- and x-coordinate offsets from
            ``get_fit_offsets()``.

        Returns
        -------
        cutout_data : dict
            Dictionary containing cutout information:

            - 'valid' : bool, whether the cutout is valid
            - 'reason' : str or None, reason if invalid ('no_overlap'
              or 'fully_masked')
            - 'xx' : 1D array or None, x pixel indices of the unmasked
              cutout pixels
            - 'yy' : 1D array or None, y pixel indices of the unmasked
              cutout pixels
            - 'cutout' : 1D array or None, data values of the unmasked
              cutout pixels, with the local background subtracted if
              it is finite
            - 'n_pixels' : int, number of unmasked pixels in the cutout
            - 'cen_index' : int or nan, index in the 1D arrays of the
              pixel containing the source center, or nan if that pixel
              is masked or outside the image

            If the cutout is not valid, 'xx', 'yy', and 'cutout' are
            None, 'n_pixels' is 0, and 'cen_index' is nan.
        """
        x_cen = row[self.param_mapper.init_colnames['x']]
        y_cen = row[self.param_mapper.init_colnames['y']]

        try:
            slc_lg, _ = overlap_slices(data.shape, self.fit_shape,
                                       (y_cen, x_cen), mode='trim')
        except NoOverlapError:
            return {'valid': False,
                    'reason': 'no_overlap',
                    'xx': None,
                    'yy': None,
                    'cutout': None,
                    'n_pixels': 0,
                    'cen_index': np.nan,
                    }

        y_start = slc_lg[0].start
        x_start = slc_lg[1].start
        ny_cutout = slc_lg[0].stop - y_start
        nx_cutout = slc_lg[1].stop - x_start
        trimmed_y_offsets = y_offsets[:ny_cutout, :nx_cutout]
        trimmed_x_offsets = x_offsets[:ny_cutout, :nx_cutout]
        yy = trimmed_y_offsets + y_start
        xx = trimmed_x_offsets + x_start

        if mask is not None:
            inv_mask = ~mask[yy, xx]
            if np.count_nonzero(inv_mask) == 0:
                return {'valid': False,
                        'reason': 'fully_masked',
                        'xx': None,
                        'yy': None,
                        'cutout': None,
                        'n_pixels': 0,
                        'cen_index': np.nan,
                        }

            yy_flat = yy[inv_mask]
            xx_flat = xx[inv_mask]
        else:
            yy_flat = yy.ravel()
            xx_flat = xx.ravel()

        cutout = data[yy_flat, xx_flat]

        # Local background subtraction (local_bkg = 0 if not provided).
        # Only subtract if the local_bkg is finite (not NaN or inf).
        local_bkg = row['local_bkg']
        if np.any(local_bkg != 0):
            if isinstance(local_bkg, u.Quantity):
                local_bkg_value = local_bkg.value
            else:
                local_bkg_value = local_bkg

            # Only subtract if local_bkg is finite. The subtraction
            # is not done in place so that integer-dtype data works
            # with a float local_bkg (the fancy index above already
            # returned a copy).
            if np.isfinite(local_bkg_value):
                cutout = cutout - local_bkg_value

        # Center pixel index (before trimming)
        x_cen_idx = np.ceil(x_cen - 0.5).astype(int)
        y_cen_idx = np.ceil(y_cen - 0.5).astype(int)
        cen_match = np.where((xx_flat == x_cen_idx)
                             & (yy_flat == y_cen_idx))[0]
        cen_index = cen_match[0] if len(cen_match) > 0 else np.nan

        return {'valid': True,
                'reason': None,
                'xx': xx_flat,
                'yy': yy_flat,
                'cutout': cutout,
                'n_pixels': len(xx_flat),
                'cen_index': cen_index,
                }


class PSFFitter:
    """
    Helper class to handle PSF model fitting operations.

    This class encapsulates all fitting-related operations including
    model creation, fitting execution, and parameter extraction.

    Parameters
    ----------
    psf_model : `~astropy.modeling.Model`
        PSF model to be fit to sources. This model will be copied for
        each source and fitted parameters will be set.

    param_mapper : _PSFParameterMapper
        Parameter mapper for handling column name mappings and model
        parameters.

    fitter : `~astropy.modeling.fitting.Fitter`, optional
        Astropy fitter instance to use for PSF fitting. If None,
        defaults to `~astropy.modeling.fitting.TRFLSQFitter`.

    fitter_maxiters : int or None, optional
        Maximum number of fitting iterations. Default is 100. If None,
        the default of the fitter is used.

    xy_bounds : 2-element sequence of float or None, or None, optional
        Bounds for x and y position parameters as (x_bound, y_bound).
        An element of `None` means no bound along that axis. If
        provided, fitting positions will be constrained to within
        these bounds of the initial values.
    """

    def __init__(self, psf_model, param_mapper, *, fitter=None,
                 fitter_maxiters=100, xy_bounds=None):
        self.psf_model = psf_model
        self.param_mapper = param_mapper
        self.fitter = fitter if fitter is not None else TRFLSQFitter()
        self.fitter_maxiters = fitter_maxiters
        self.xy_bounds = xy_bounds

        # Cache of flat model classes keyed on the number of sources.
        # The cache is per-instance because the cached classes capture
        # a copy of psf_model.
        self._flat_model_classes = {}

    def make_psf_model(self, sources):
        """
        Create a single PSF model or a flat model for a group of
        sources.

        This method avoids CompoundModel by creating a custom model
        class where all parameters are top-level (e.g., x_0_0, y_0_0,
        flux_0, x_0_1, y_0_1, flux_1, etc., which is each base parameter
        name followed by the source index) rather than nested. This
        eliminates the parameter tree traversal and nested structure
        overhead of CompoundModel.

        The dynamic flat model class directly evaluates each PSF and
        sums them, providing much better performance for large groups.

        Flat model classes are cached per PSFFitter instance based on
        the number of sources to improve performance for repeated group
        sizes.

        Parameters
        ----------
        sources : `~astropy.table.Table` or list of `~astropy.table.Row`
            Source rows from the sources table for the group.

        Returns
        -------
        model : `~astropy.modeling.Model`
            PSF model for the group of sources, either a single PSF
            model or a flat model for multiple sources.
        """
        n_sources = len(sources)
        if n_sources == 1:
            # For single sources, just use the PSF model directly
            source = sources[0]
            model = self.psf_model.copy()
            alias_map = self.param_mapper.alias_to_model_param
            init_colnames = self.param_mapper.init_colnames

            for alias, col_name in init_colnames.items():
                model_param = alias_map[alias]
                value = source[col_name]
                if isinstance(value, u.Quantity):
                    # PSF model parameters must be unitless to be fit
                    value = value.value
                setattr(model, model_param, value)

            # Set the model name to the source ID if available
            if 'id' in source.colnames:
                model.name = source['id']

            self._apply_xy_bounds(model, alias_map)
            return model

        # For multiple sources, use cached flat model class
        return _get_flat_model(sources, self.psf_model, self.param_mapper,
                               xy_bounds=self.xy_bounds,
                               class_cache=self._flat_model_classes)

    def _apply_xy_bounds(self, model, alias_map):
        """
        Apply xy_bounds to a model.
        """
        if self.xy_bounds is not None:
            if self.xy_bounds[0] is not None:
                x_param_name = alias_map['x']
                x_param = getattr(model, x_param_name)
                _apply_bounds_to_param(model, x_param_name,
                                       x_param.value, self.xy_bounds[0])
            if self.xy_bounds[1] is not None:
                y_param_name = alias_map['y']
                y_param = getattr(model, y_param_name)
                _apply_bounds_to_param(model, y_param_name,
                                       y_param.value, self.xy_bounds[1])

    def run_fitter(self, psf_model, xi, yi, cutout, error):
        """
        Fit the PSF model to the input cutout data.

        Parameters
        ----------
        psf_model : `~astropy.modeling.Model`
            PSF model to fit, typically created by ``make_psf_model``.

        xi, yi : `~numpy.ndarray`
            1D array of x and y pixel coordinates for the cutout.

        cutout : `~numpy.ndarray`
            1D array of data values corresponding to the pixel
            coordinates.

        error : `~numpy.ndarray` or None
            2D error array for computing fit weights. If provided,
            weights are computed as 1/error for the cutout pixels.

        Returns
        -------
        fit_model : `~astropy.modeling.Model`
            Fitted PSF model with optimized parameters.

        fit_info : dict
            Dictionary containing fit information including parameter
            covariance, convergence status, and error messages.

        Raises
        ------
        ValueError
            If the error array contains nonpositive or nonfinite
            values at the fit pixels.
        """
        kwargs = {'inplace': True}

        if self.fitter_maxiters is not None:
            kwargs.update({'maxiter': self.fitter_maxiters})

        weights = None
        if error is not None:
            # Extract cutout weights from full error array. Weights are
            # (1 / error), yielding residuals (objective function) of
            # (data - model) / error. The fitter minimizes the squared
            # residuals. If errors are input, the residuals returned by
            # the fitter are scaled by the errors, i.e., the objective
            # function is equivalent to chi2. If errors are not input,
            # the residuals are just (data - model), and the objective
            # function is a sum-of-squares. Note that the residuals
            # returned by astropy fitters are reversed in sign from the
            # definition here (model - data).
            err = error[yi, xi]
            if np.any(err <= 0) or np.any(~np.isfinite(err)):
                msg = ('Error array contains nonpositive or nonfinite '
                       'values within the fit region centered near '
                       f'x={np.mean(xi):.1f}, y={np.mean(yi):.1f}. '
                       'Cannot compute fit weights.')
                raise ValueError(msg)
            weights = 1.0 / err

        # Keep fit-info entries (but exclude residual vectors)
        fit_info_keys = ('param_cov', 'ierr', 'message', 'status')

        with warnings.catch_warnings():
            warnings.simplefilter('ignore', AstropyUserWarning)
            fit_model = self.fitter(psf_model, xi, yi, cutout,
                                    weights=weights, **kwargs)

            # Clear any model cache, if supported by the model
            with contextlib.suppress(AttributeError):
                fit_model.clear_cache()

            fit_info = {key: self.fitter.fit_info.get(key) for key in
                        fit_info_keys if self.fitter.fit_info.get(key)
                        is not None}

        return fit_model, fit_info

    @staticmethod
    def extract_source_covariances(group_cov, n_sources, n_fit_params):
        """
        Extract individual source covariance matrices from group
        covariance.

        The group covariance matrix is assumed to be ordered by source,
        with ``n_fit_params`` consecutive rows and columns for each
        source. Only the diagonal block of each source is extracted.
        The covariances between different sources are not included.

        Parameters
        ----------
        group_cov : `~numpy.ndarray`
            2D covariance matrix for the entire group of sources.

        n_sources : int
            Number of sources in the group.

        n_fit_params : int
            Number of fitted parameters per source.

        Returns
        -------
        source_covs : list of `~numpy.ndarray`
            List of 2D covariance matrices, one for each source in
            the group.
        """
        source_covs = []
        for i in range(n_sources):
            start = i * n_fit_params
            end = (i + 1) * n_fit_params
            source_cov = group_cov[start:end, start:end]
            source_covs.append(source_cov)

        return source_covs

    def split_flat_model(self, flat_model, n_sources):
        """
        Split a flat model into individual source models.

        For flat models, create individual PSF models with parameters
        extracted from the flat model's parameter values.

        Parameters
        ----------
        flat_model : `~astropy.modeling.Model`
            The flat model containing parameters for all sources.

        n_sources : int
            Number of sources in the flat model.

        Returns
        -------
        source_models : list of `~astropy.modeling.Model`
            List of individual PSF models, one for each source.
        """
        source_models = []
        # Fixed parameters are copied as well because their per-source
        # values are stored only in the flat model
        param_names = self.psf_model.param_names

        for i in range(n_sources):
            # Create a copy of the base PSF model
            source_model = self.psf_model.copy()

            # Extract parameter values and bounds for this source from
            # the flat model
            for param_name in param_names:
                flat_param_name = f'{param_name}_{i}'
                if hasattr(flat_model, flat_param_name):
                    flat_param = getattr(flat_model, flat_param_name)
                    setattr(source_model, param_name, flat_param.value)
                    getattr(source_model,
                            param_name).bounds = flat_param.bounds

            source_models.append(source_model)

        return source_models


class PSFResultsAssembler:
    """
    Helper class to handle results table assembly and quality metrics
    calculation.

    This class encapsulates all operations related to assembling final
    results tables, calculating quality metrics, and generating flags.

    Parameters
    ----------
    param_mapper : _PSFParameterMapper
        Parameter mapper for handling column name mappings and model
        parameters.

    fit_shape : tuple of int
        The shape of the PSF fitting region as a (ny, nx) tuple.
    """

    def __init__(self, param_mapper, fit_shape):
        self.param_mapper = param_mapper
        self.fit_shape = fit_shape

    def get_fit_error_indices(self, fit_info):
        """
        Get the indices of fits that did not converge.

        Parameters
        ----------
        fit_info : list of dict
            List of fit information dictionaries from the fitter,
            containing 'ierr' or 'status' keys for convergence info.

        Returns
        -------
        bad_indices : `~numpy.ndarray`
            Array of integer indices for fits that did not converge.
        """
        # 1, 2, 3, and 4 are the "good" convergence values for both
        # the leastsq and least_squares optimizers. None means the
        # key was not present in the fit info.
        bad = [idx for idx, info in enumerate(fit_info)
               if any(info.get(key) not in (None, 1, 2, 3, 4)
                      for key in ('ierr', 'status'))]
        return np.array(bad, dtype=int)

    def param_errors_to_table(self, fit_param_errs, data_unit):
        """
        Convert the fitter's parameter errors to an astropy Table.

        Parameters
        ----------
        fit_param_errs : `~numpy.ndarray`
            2D array of parameter errors with shape (n_sources, n_params).

        data_unit : `~astropy.units.Unit` or None
            Unit of the input data, used to apply appropriate units
            to flux error columns.

        Returns
        -------
        table : `~astropy.table.QTable`
            Table containing error columns for fitted parameters,
            with NaN values for nonfitted (fixed) parameters.
        """
        # Create error columns for model parameters that were fit
        mapper = self.param_mapper
        fitted_params = mapper.fitted_param_names
        model_param_to_alias = mapper.model_param_to_alias
        err_colnames = mapper.err_colnames

        fitted_aliases = [model_param_to_alias[param]
                          for param in fitted_params]
        fitted_err_cols = [err_colnames[alias] for alias in fitted_aliases]

        table_data = {err_col: fit_param_errs[:, i]
                      for i, err_col in enumerate(fitted_err_cols)}
        table = QTable(table_data)

        # Ensure columns for nonfitted (fixed) params exist
        all_err_cols = list(err_colnames.values())
        for err_col in all_err_cols:
            if err_col not in table.colnames:
                table[err_col] = np.nan

        # Apply data_unit to flux_err column
        if data_unit is not None:
            flux_err_col = err_colnames['flux']
            table[flux_err_col] <<= data_unit

        return table[all_err_cols]

    def create_fit_results(self, fit_model_all_params, fit_param_errs,
                           valid_mask, data_unit):
        """
        Create the table of fitted parameter values and errors.

        Parameters
        ----------
        fit_model_all_params : `~astropy.table.Table`
            Table containing fitted model parameters for all sources.

        fit_param_errs : `~numpy.ndarray`
            2D array of parameter errors with shape (n_sources, n_params).

        valid_mask : `~numpy.ndarray` or None
            Boolean array indicating which sources had valid fits.

        data_unit : `~astropy.units.Unit` or None
            Unit of the input data, applied to the flux error column.

        Returns
        -------
        fit_table : `~astropy.table.QTable`
            Table containing fitted parameter values and their errors,
            with NaN values for invalid sources.
        """
        mapper = self.param_mapper
        alias_to_model = mapper.alias_to_model_param
        model_param_to_alias = mapper.model_param_to_alias
        fit_colnames = mapper.fit_colnames
        err_colnames = mapper.err_colnames

        col_names = ['id', *list(alias_to_model.values())]
        fit_params = fit_model_all_params[col_names]

        # Rename model parameter columns to *_fit
        for col_name in list(fit_params.colnames):
            if col_name == 'id':
                continue
            alias = model_param_to_alias[col_name]
            fit_params.rename_column(col_name, fit_colnames[alias])

        param_errs = self.param_errors_to_table(fit_param_errs, data_unit)
        fit_table = hstack([fit_params, param_errs])

        # Sort columns to match the expected order
        col_order = ['id', *list(fit_colnames.values()),
                     *list(err_colnames.values())]
        fit_table = fit_table[col_order]

        # Overwrite fit and error columns with NaN for invalid sources
        if valid_mask is not None:
            invalid = ~np.array(valid_mask, dtype=bool)
            for col_name in fit_table.colnames:
                if col_name == 'id':
                    continue
                col = fit_table[col_name]
                unit = getattr(col, 'unit', None)
                if unit is not None:
                    col[invalid] = (np.nan * unit)
                else:
                    col[invalid] = np.nan

        return fit_table

    def calc_fit_metrics(self, results_tbl, sum_abs_residuals, cen_residuals,
                         reduced_chi2):
        """
        Calculate the qfit and cfit fit quality metrics.

        The input ``reduced_chi2`` values are returned unchanged.

        Parameters
        ----------
        results_tbl : `~astropy.table.QTable`
            Results table containing fitted flux values.

        sum_abs_residuals : array-like
            Array of sum of absolute residuals for each source.

        cen_residuals : array-like
            Array of central pixel residuals for each source.

        reduced_chi2 : array-like
            Array of reduced chi-squared values for each source.

        Returns
        -------
        qfit : `~numpy.ndarray`
            Array of qfit quality metrics (sum of absolute residuals
            divided by flux).

        cfit : `~numpy.ndarray`
            Array of cfit quality metrics (central pixel residual
            divided by flux).

        reduced_chi2 : array-like
            The input reduced chi-squared values, unchanged.
        """
        flux_col = self.param_mapper.fit_colnames['flux']
        flux_vals = results_tbl[flux_col]
        if isinstance(flux_vals, u.Quantity):
            flux_vals = flux_vals.value

        n_sources = len(sum_abs_residuals)
        qfit = np.full(n_sources, np.nan, dtype=float)
        cfit = np.full(n_sources, np.nan, dtype=float)

        with warnings.catch_warnings():
            warnings.simplefilter('ignore', RuntimeWarning)

            # Create masks for valid data
            valid_sa = np.isfinite(sum_abs_residuals)
            valid_cr = np.isfinite(cen_residuals)
            nonzero_flux = (flux_vals != 0)

            # qfit: sum of absolute residuals divided by flux
            qfit_mask = valid_sa & nonzero_flux
            qfit[qfit_mask] = (sum_abs_residuals[qfit_mask]
                               / flux_vals[qfit_mask])

            # cfit: central pixel residual divided by flux
            cfit_mask = valid_cr & nonzero_flux
            cfit[cfit_mask] = (cen_residuals[cfit_mask]
                               / flux_vals[cfit_mask])

        # An exact fit has zero residuals, and the sign of the resulting
        # zero depends on the sign convention of the fitter residuals
        # (cfit) and on the sign of the flux (qfit and cfit). Adding
        # zero turns a negative zero (-0.0) into a positive zero and
        # leaves all other values, including NaN, unchanged.
        qfit += 0.0
        cfit += 0.0

        return qfit, cfit, reduced_chi2

    @_update_flags_docstring
    def define_flags(self, results_tbl, shape, fit_error_indices, fit_info,
                     fitted_models_table, valid_mask, invalid_reasons,
                     init_params):
        # numpydoc ignore: RT05
        """
        Define per-source bitwise flags summarizing fit conditions.

        Parameters
        ----------
        results_tbl : `~astropy.table.QTable`
            Results table containing fitted parameters and metrics.

        shape : tuple of int
            Shape of the input data array as (ny, nx).

        fit_error_indices : `~numpy.ndarray` or None
            Array of indices for sources with convergence issues.

        fit_info : list of dict
            List of fit information dictionaries.

        fitted_models_table : `~astropy.table.Table`
            Table containing fitted model parameters with bounds info.

        valid_mask : `~numpy.ndarray` or None
            Boolean array indicating valid sources. Only valid sources
            are checked for parameters near a bound. If `None`, all
            sources are valid.

        invalid_reasons : list or None
            List of reasons why sources were invalid.

        init_params : `~astropy.table.QTable`
            Initial parameter guesses for sources, containing the
            initial positions and local_bkg.

        Returns
        -------
        flags : `~numpy.ndarray`
            Array of integer flags where each bit indicates a specific
            condition. The flags are:
            <flag_descriptions>
        """
        flags = np.zeros(len(results_tbl), dtype=int)
        x_col = self.param_mapper.fit_colnames['x']
        y_col = self.param_mapper.fit_colnames['y']
        flux_col = self.param_mapper.fit_colnames['flux']

        # n_pixels_fit smaller than full fit_shape region
        flag1_mask = (results_tbl['n_pixels_fit']
                      < np.prod(self.fit_shape))
        flags[flag1_mask] |= PSF_FLAGS.N_PIXELS_FIT_PARTIAL

        # Fitted position outside input image bounds
        ny, nx = shape
        x_fit = results_tbl[x_col]
        y_fit = results_tbl[y_col]
        flag2_mask = ((x_fit < -0.5) | (y_fit < -0.5) | (x_fit > nx - 0.5)
                      | (y_fit > ny - 0.5))
        flags[flag2_mask] |= PSF_FLAGS.POSITION_OUTSIDE_IMAGE

        # Nonpositive flux
        flag4_mask = results_tbl[flux_col] <= 0
        flags[flag4_mask] |= PSF_FLAGS.NON_POSITIVE_FLUX

        # Possible nonconvergence
        if fit_error_indices is not None:
            flags[fit_error_indices] |= PSF_FLAGS.NO_CONVERGENCE

        # Missing parameter covariance
        missing_cov_mask = np.array(['param_cov' not in info
                                     for info in fit_info])
        flags[missing_cov_mask] |= PSF_FLAGS.NO_COVARIANCE

        # Near a fitted-parameter bound. Bounds may come from
        # the xy_bounds keyword or be set directly on the PSF model.
        bound_tol = 0.01
        param_names = [col for col in fitted_models_table.colnames
                       if col != 'id'
                       and not col.endswith(('_fixed', '_bounds'))]
        if valid_mask is None:
            valid_indices = np.arange(len(results_tbl))
        else:
            valid_indices = np.flatnonzero(valid_mask)
        for index in valid_indices:
            row = fitted_models_table[index]
            for param in param_names:
                if row[f'{param}_fixed']:
                    continue
                bounds = np.array([i for i in row[f'{param}_bounds']
                                   if i is not None])
                if bounds.size == 0:
                    continue
                value = row[param]
                if isinstance(value, u.Quantity):
                    value = value.value
                if np.any(np.abs(bounds - value) <= bound_tol):
                    flags[index] |= PSF_FLAGS.PARAMETER_NEAR_BOUND
                    break

        # Invalid source reasons. Sources invalid because of a
        # nonfinite input flux get the nonfinite flux flag below from
        # their NaN fitted flux.
        if invalid_reasons is not None:
            reasons = np.array(invalid_reasons, dtype=object)
            flags[reasons == 'no_overlap'] |= PSF_FLAGS.NO_OVERLAP
            flags[reasons == 'fully_masked'] |= PSF_FLAGS.FULLY_MASKED
            flags[reasons == 'too_few_pixels'] |= PSF_FLAGS.TOO_FEW_PIXELS

        # Nonfinite fitted position
        non_finite_pos_mask = ~np.isfinite(x_fit) | ~np.isfinite(y_fit)
        flags[non_finite_pos_mask] |= PSF_FLAGS.NON_FINITE_POSITION

        # Nonfinite fitted flux
        flux_fit = results_tbl[flux_col]
        non_finite_flux_mask = ~np.isfinite(flux_fit)
        flags[non_finite_flux_mask] |= PSF_FLAGS.NON_FINITE_FLUX

        # Nonfinite local background
        local_bkg_vals = init_params['local_bkg']
        if hasattr(local_bkg_vals, 'value'):
            # Handle Quantity
            local_bkg_vals = local_bkg_vals.value
        non_finite_bkg_mask = ~np.isfinite(local_bkg_vals)
        flags[non_finite_bkg_mask] |= PSF_FLAGS.NON_FINITE_LOCAL_BKG

        # Flag=4096: fitted position outside the fitted data region.
        # The region is the fit_shape box around the initial position,
        # trimmed to the image, matching the overlap_slices cutout in
        # get_source_cutout_data. Its edges are the outer pixel edges.
        # Nonfinite positions compare as False and are not flagged.
        fit_ny, fit_nx = self.fit_shape
        x_init = np.asarray(
            init_params[self.param_mapper.init_colnames['x']], dtype=float)
        y_init = np.asarray(
            init_params[self.param_mapper.init_colnames['y']], dtype=float)
        x_start = np.ceil(x_init - fit_nx / 2.0)
        y_start = np.ceil(y_init - fit_ny / 2.0)
        x_min = np.maximum(x_start, 0) - 0.5
        y_min = np.maximum(y_start, 0) - 0.5
        x_max = np.minimum(x_start + fit_nx, nx) - 0.5
        y_max = np.minimum(y_start + fit_ny, ny) - 0.5
        flag4096_mask = ((x_fit < x_min) | (x_fit > x_max)
                         | (y_fit < y_min) | (y_fit > y_max))
        flags[flag4096_mask] |= PSF_FLAGS.POSITION_OUTSIDE_FIT_REGION

        return flags

    def assemble_results_table(self, init_params, fit_params, data_shape,
                               state, calc_fit_metrics_func, define_flags_func,
                               class_name, metadata_attrs, *,
                               warn_no_convergence=True):
        """
        Assemble the final results table.

        The final results table is built by merging the input
        ``init_params`` table with the ``fit_params`` table. Additional
        columns are added for ``n_pixels_fit``, ``group_size``, ``qfit``,
        ``cfit``, ``reduced_chi2``, and ``flags``.

        This method also cleans up the state dictionary as data is
        consumed to reduce memory usage.

        Parameters
        ----------
        init_params : `~astropy.table.QTable`
            Initial parameter guesses for sources.

        fit_params : `~astropy.table.QTable`
            Fitted parameters with uncertainties.

        data_shape : tuple of int
            Shape of the input data array as (ny, nx).

        state : dict
            State dictionary containing fitting data and metadata.

        calc_fit_metrics_func : callable
            Function to calculate fit quality metrics (qfit, cfit,
            reduced_chi2).

        define_flags_func : callable
            Function to define per-source bitwise flags.

        class_name : str
            Name of the calling class, stored in the ``'psf_class'``
            entry of the table metadata.

        metadata_attrs : dict
            Dictionary of metadata attributes to add to the table.

        warn_no_convergence : bool, optional
            Whether to emit a warning if one or more fits may not have
            converged.

        Returns
        -------
        results_tbl : `~astropy.table.QTable`
            Results table containing:

            - Source ID and group ID
            - Initial parameter estimates
            - Fitted parameters with uncertainties
            - Quality metrics (qfit, cfit, reduced_chi2)
            - Bitwise flags indicating fit conditions
            - Fit statistics (n_pixels_fit, group_size)
        """
        # Add metrics and flags column to fit_params. The results in the
        # state container match the order of the fit_params results,
        # which are in the same source ID order as the init_params.

        # State keys consumed here, each removed after use to reduce
        # memory usage:
        # - 'n_pixels_fit', 'group_size': added as columns
        # - 'sum_abs_residuals', 'cen_residuals', 'reduced_chi2':
        #   consumed by calc_fit_metrics_func
        # - 'fit_error_indices', 'fitted_models_table',
        #   'valid_mask_by_id': consumed by define_flags_func

        # Consume n_pixels_fit and group_size data, removing from state
        fit_params['n_pixels_fit'] = state.pop('n_pixels_fit')
        fit_params['group_size'] = state.pop('group_size')

        # Calculate fit metrics and remove the underlying data
        qfit, cfit, reduced_chi2 = calc_fit_metrics_func(fit_params)
        fit_params['qfit'] = qfit
        fit_params['cfit'] = cfit
        fit_params['reduced_chi2'] = reduced_chi2

        # Clean up residual data after metrics calculation
        state.pop('sum_abs_residuals', None)
        state.pop('cen_residuals', None)
        state.pop('reduced_chi2', None)

        # Calculate flags and check for convergence warnings before cleanup
        fit_params['flags'] = define_flags_func(
            fit_params, data_shape, init_params)

        # Join the fit_params table (with metrics and flags) to the
        # init_params table. By default, join will sort the rows by the
        # 'id' column.
        results_tbl = join(init_params, fit_params, keys='id',
                           join_type='left')

        # Reorder columns to place group_size after group_id
        # (both columns should always be present).
        group_size = results_tbl['group_size']
        results_tbl.remove_column('group_size')
        index = results_tbl.colnames.index('group_id') + 1
        results_tbl.add_column(group_size, index=index)

        # Check for fit convergence warnings before cleaning up state
        fit_error_indices = state.get('fit_error_indices')
        if (warn_no_convergence and fit_error_indices is not None
                and len(fit_error_indices) > 0):
            msg = ('One or more fit(s) may not have converged. Please '
                   'check the "flags" column in the output table.')
            warnings.warn(msg, AstropyUserWarning)

        # Clean up flag-related state data after use
        state.pop('fit_error_indices', None)
        state.pop('fitted_models_table', None)
        state.pop('valid_mask_by_id', None)

        meta = _get_meta()
        meta['psf_class'] = class_name

        # Add attribute metadata
        meta.update(metadata_attrs)

        # Replace with QTable in 4.0
        psf_deprecation_map = {'npixfit': 'n_pixels_fit'}
        result = DeprecatedColumnQTable(results_tbl, meta=meta)
        result.deprecation_map = psf_deprecation_map
        result._deprecation_since = '3.0'
        result._deprecation_until = '4.0'
        return result


def _make_model_image_docstring(func):
    func.__doc__ = """
        Create a 2D image from the fit PSF models and optional local
        background.

        Parameters
        ----------
        shape : 2-tuple of int
            The shape of the output array.

        psf_shape : int, 2-tuple of int, or `None`, optional
            The shape of the region around the center of the fit model
            to render in the output image. If ``psf_shape`` is a scalar
            integer, then a square shape of size ``psf_shape`` will be
            used. If `None`, then the bounding box of the model will be
            used. This keyword must be specified if the model does not
            have a ``bounding_box`` attribute.

        include_local_bkg : bool, optional
            Whether to include the local background in the rendered
            output image. Note that the local background level is
            included around each source over the region defined by
            ``psf_shape``. Thus, regions where the ``psf_shape`` of
            sources overlap will have the local background added
            multiple times. Nonfinite local background values (NaN or
            inf) are treated as zero and not included in the output
            image.

        Returns
        -------
        array : 2D `~numpy.ndarray`
            The rendered image from the fit PSF models. If the fit
            was performed on data with units, the image will be a
            `~astropy.units.Quantity` with the same units.

        Raises
        ------
        ValueError
            If no results are available because the instance has not
            been run or no sources were found.
        """
    return func


def _make_residual_image_docstring(func):
    func.__doc__ = """
        Create a 2D residual image from the fit PSF models and local
        background.

        Parameters
        ----------
        data : 2D `~numpy.ndarray`, `~astropy.units.Quantity`, or \
`~astropy.nddata.NDData`
            The 2D array on which photometry was performed. This should
            be the same array input when calling the PSF-photometry
            class.

        psf_shape : int, 2-tuple of int, or `None`, optional
            The shape of the region around the center of the fit model
            to subtract. If ``psf_shape`` is a scalar integer, then
            a square shape of size ``psf_shape`` will be used. If
            `None`, then the bounding box of the model will be used.
            This keyword must be specified if the model does not have a
            ``bounding_box`` attribute.

        include_local_bkg : bool, optional
            Whether to include the local background in the subtracted
            model. Note that the local background level is subtracted
            around each source over the region defined by ``psf_shape``.
            Thus, regions where the ``psf_shape`` of sources overlap
            will have the local background subtracted multiple times.
            Nonfinite local background values (NaN or inf) are not
            subtracted from the residual image.

        Returns
        -------
        array : 2D `~numpy.ndarray`, `~astropy.units.Quantity`, or \
`~astropy.nddata.NDData`
            The residual image of the ``data`` minus the fit PSF models
            minus the optional ``local_bkg``. The output has the same
            type as the input ``data``. If ``data`` is an
            `~astropy.nddata.NDData` object, a copy is returned with
            the residual image as its data.

        Raises
        ------
        ValueError
            If no results are available because the instance has not
            been run or no sources were found.
        """
    return func


class _ModelImageMaker:
    """
    Class to create model and residual images from fit PSF models.

    Parameters
    ----------
    psf_model : `~astropy.modeling.Model`
        The PSF model.

    model_params : `~astropy.table.Table`
        The model parameters.

    local_bkg : `~astropy.table.Column` or `~astropy.units.Quantity`, \
optional
        The local background values.

    progress_bar : bool, optional
        Whether to display a progress bar.
    """

    def __init__(self, psf_model, model_params, *, local_bkg=None,
                 progress_bar=False):
        self.psf_model = psf_model
        self.model_params = model_params
        self.local_bkg = local_bkg
        self.progress_bar = progress_bar

    @_make_model_image_docstring
    def make_model_image(self, shape, *, psf_shape=None,
                         include_local_bkg=False):
        psf_model = self.psf_model
        model_params = self.model_params
        local_bkgs = self.local_bkg
        progress_bar = self.progress_bar

        if include_local_bkg:
            # Add local_bkg, but set nonfinite values to 0 to avoid
            # corrupting the model image
            model_params = model_params.copy()
            if local_bkgs is None:
                local_bkgs_clean = np.zeros(len(model_params))
            else:
                local_bkgs_clean = local_bkgs.copy()
                # Replace nonfinite values with 0
                nonfinite_mask = ~np.isfinite(local_bkgs_clean)
                if np.any(nonfinite_mask):
                    local_bkgs_clean[nonfinite_mask] = 0
            model_params['local_bkg'] = local_bkgs_clean

        try:
            x_name = psf_model.x_name
            y_name = psf_model.y_name
        except AttributeError:
            x_name = 'x_0'
            y_name = 'y_0'

        return _make_model_image(shape, psf_model, model_params,
                                 model_shape=psf_shape,
                                 x_name=x_name, y_name=y_name,
                                 progress_bar=progress_bar)

    @_make_residual_image_docstring
    def make_residual_image(self, data, *, psf_shape=None,
                            include_local_bkg=False):
        if isinstance(data, NDData):
            residual = deepcopy(data)
            data_arr = data.data
            if data.unit is not None:
                data_arr <<= data.unit
            residual.data[:] = self.make_residual_image(
                data_arr, psf_shape=psf_shape,
                include_local_bkg=include_local_bkg)
        else:
            residual = self.make_model_image(
                data.shape, psf_shape=psf_shape,
                include_local_bkg=include_local_bkg)
            np.subtract(data, residual, out=residual)

        return residual
