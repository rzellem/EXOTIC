# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Tools for plotting gridded PSF models.
"""

import numpy as np

__all__ = []


def _plot_grid_docstring(func):
    func.__doc__ = """
        Plot the grid of ePSF models.

        Parameters
        ----------
        ax : `matplotlib.axes.Axes` or `None`, optional
            The matplotlib axes on which to plot. If `None`, a new
            figure and axes are created.

        vmax_scale : float or `None`, optional
            Scale factor to apply to the image stretch limits. This
            value is multiplied by the maximum of the plotted data (the
            ePSF data, or the ePSF differences if ``deltas=True``) to
            determine the plotting ``vmax``. If `None`, the value is 1.0
            for the ePSF data and 0.03 for the ePSF differences. If
            ``deltas=True``, ``vmin`` is set to ``-vmax``. Otherwise
            ``vmin`` is set to ``vmax / 1e4``.

        peak_norm : bool, optional
            Whether to normalize the ePSF data by the peak value. The
            default shows the ePSF flux per pixel. If ``deltas=True``,
            the differences are divided by the peak of the average
            ePSF.

        deltas : bool, optional
            Set to `True` to show the differences between each ePSF
            and the average ePSF.

        cmap : str or `matplotlib.colors.Colormap`, optional
            The colormap to use. The default is 'viridis'.

        dividers : bool, optional
            Whether to show divider lines between the ePSFs.

        divider_color, divider_ls : str, optional
            Matplotlib color and linestyle options for the divider
            lines between ePSFs. These keywords have no effect unless
            ``dividers=True``.

        figsize : (float, float), optional
            The figure (width, height) in inches. It is used only if
            ``ax`` is `None`.

        Returns
        -------
        fig : `matplotlib.figure.Figure`
            The matplotlib figure object. This is a new figure if
            ``ax=None``, otherwise the figure of ``ax``. Use
            ``fig.savefig()`` to save the figure to a file.

        Raises
        ------
        ValueError
            If ``deltas=True`` and all ePSFs in the grid are blank (all
            pixels are zero).

        Notes
        -----
        This method returns a figure object. If you are using this
        method in a script, you will need to call ``fig.show()`` to
        display the figure. If you are using this method in a Jupyter
        notebook, the figure will be displayed automatically.

        When in a notebook, if you do not store the return value of this
        function, the figure will be displayed twice due to the REPL
        automatically displaying the return value of the last function
        call. Alternatively, you can append a semicolon to the end of
        the function call to suppress the display of the return value.
        """
    return func


class _ModelGridPlotter:
    """
    Class to plot a grid of ePSF models.
    """

    def __init__(self, model):
        self.model = model

    def _reshape_grid(self, data):
        """
        Reshape the 3D ePSF grid as a 2D array of horizontally and
        vertically stacked ePSFs.

        Parameters
        ----------
        data : `numpy.ndarray`
            The 3D array of ePSF data.

        Returns
        -------
        reshaped_data : `numpy.ndarray`
            The 2D array of ePSF data.
        """
        ny_grid = self.model._ygrid.shape[0]
        nx_grid = self.model._xgrid.shape[0]
        ny, nx = self.model.data.shape[1:]
        return (data.reshape(ny_grid, nx_grid, ny, nx)
                .transpose([0, 2, 1, 3])
                .reshape(ny_grid * ny, nx_grid * nx))

    @_plot_grid_docstring
    def plot_grid(self, *, ax=None, vmax_scale=None, peak_norm=False,
                  deltas=False, cmap='viridis', dividers=True,
                  divider_color='darkgray', divider_ls='-', figsize=None):
        import matplotlib.pyplot as plt
        from astropy.visualization import simple_norm
        from mpl_toolkits.axes_grid1 import make_axes_locatable

        data = self.model.data.astype(float)
        if deltas:
            # Compute mean ignoring any blank (all zeros) ePSFs.
            # This is the case for MIRI with its nonsquare FOV.
            mask = np.zeros(data.shape[0], dtype=bool)
            for i, arr in enumerate(data):
                if np.count_nonzero(arr) == 0:
                    mask[i] = True
            if mask.all():
                msg = ('deltas cannot be computed because all ePSFs '
                       'in the grid are blank (all pixels are zero)')
                raise ValueError(msg)
            mean_epsf = np.mean(data[~mask], axis=0)
            data -= mean_epsf
            data[mask] = 0.0
            # For peak normalization, use the peak of the mean ePSF so
            # that the differences are relative to the average ePSF
            # peak
            peak = mean_epsf.max()
        else:
            peak = data.max()

        data = self._reshape_grid(data)

        if ax is None:
            if (figsize is None
                    and self.model.meta.get('detector', '') == 'NRCSW'):
                figsize = (20, 8)
            fig, ax = plt.subplots(figsize=figsize)
        else:
            fig = ax.get_figure()

        if peak_norm and peak != 0:
            # Normalize relative to peak
            data /= peak

        if deltas:
            if vmax_scale is None:
                vmax_scale = 0.03
            vmax = data.max() * vmax_scale
            vmin = -vmax
            norm = simple_norm(data, 'linear', vmin=vmin, vmax=vmax)
        else:
            if vmax_scale is None:
                vmax_scale = 1.0
            vmax = data.max() * vmax_scale
            vmin = vmax / 1.0e4
            norm = simple_norm(data, 'log', vmin=vmin, vmax=vmax, log_a=1.0e4)

        # Set up the coordinate axes to later set tick labels based on
        # detector ePSF coordinates. This sets up axes to have, behind the
        # scenes, the ePSFs centered at integer coords 0, 1, 2, 3 etc.
        # Extent order: left, right, bottom, top
        ny_grid = self.model._ygrid.shape[0]
        nx_grid = self.model._xgrid.shape[0]
        extent = [-0.5, nx_grid - 0.5, -0.5, ny_grid - 0.5]

        axim = ax.imshow(data, extent=extent, norm=norm, cmap=cmap,
                         origin='lower')

        # Use the axes set up above to set appropriate tick labels
        xticklabels = self.model._xgrid.astype(int)
        yticklabels = self.model._ygrid.astype(int)
        if self.model.meta.get('detector', '') == 'NRCSW':
            xticklabels = list(xticklabels[0:5]) * 4
            yticklabels = list(yticklabels[0:5]) * 2
        ax.set_xticks(np.arange(nx_grid))
        ax.set_xticklabels(xticklabels)
        ax.set_xlabel('ePSF location in detector X pixels')
        ax.set_yticks(np.arange(ny_grid))
        ax.set_yticklabels(yticklabels)
        ax.set_ylabel('ePSF location in detector Y pixels')

        if dividers:
            for ix in range(nx_grid - 1):
                ax.axvline(ix + 0.5, color=divider_color, ls=divider_ls)
            for iy in range(ny_grid - 1):
                ax.axhline(iy + 0.5, color=divider_color, ls=divider_ls)

        instrument = self.model.meta.get('instrument', '')
        if not instrument:
            # WebbPSF output
            instrument = self.model.meta.get('instrume', '')
        detector = self.model.meta.get('detector', '')
        filtername = self.model.meta.get('filter', '')

        # WebbPSF outputs a tuple with the comment in the second element
        if isinstance(instrument, (tuple, list, np.ndarray)):
            instrument = instrument[0]
        if isinstance(detector, (tuple, list, np.ndarray)):
            detector = detector[0]
        if isinstance(filtername, (tuple, list, np.ndarray)):
            filtername = filtername[0]

        # Join only the metadata values that are present so that
        # missing values do not leave stray spaces in the title
        title = ' '.join(str(value) for value in
                         (instrument, detector, filtername) if value)
        if title:
            # Add extra space at end
            title += ' '

        if deltas:
            minus = '\u2212'
            ax.set_title(f'{title}(ePSFs {minus} <ePSF>)')
            if peak_norm:
                label = 'Difference relative to average ePSF peak'
            else:
                label = 'Difference relative to average ePSF values'
        else:
            ax.set_title(f'{title}ePSFs')
            if peak_norm:
                label = 'Scale relative to ePSF peak pixel'
            else:
                label = 'ePSF flux per pixel'

        divider = make_axes_locatable(ax)
        cax_cbar = divider.append_axes('right', size='3%', pad='3%')
        cbar = fig.colorbar(axim, cax=cax_cbar, label=label)

        if not deltas:
            cbar.ax.set_yscale('log')

        if self.model.meta.get('detector', '') == 'NRCSW':
            # NIRCam NRCSW STDPSF files contain all detectors.
            # The plot gets extra divider lines and SCA name labels.
            nx_grid = len(self.model._xgrid)
            ny_grid = len(self.model._ygrid)
            ax.axhline(ny_grid / 2 - 0.5, color='orange')
            for i in range(1, 4):
                ax.axvline(nx_grid / 4 * i - 0.5, color='orange')

            det_labels = [['A1', 'A3', 'B4', 'B2'], ['A2', 'A4', 'B3', 'B1']]
            for i in range(2):
                for j in range(4):
                    ax.text(j * nx_grid / 4 - 0.45,
                            (i + 1) * ny_grid / 2 - 0.55,
                            det_labels[i][j], color='orange',
                            verticalalignment='top', fontsize=12)

        fig.tight_layout()

        return fig
